function clamp(x, l, r) {
  return Math.min(Math.max(x, l), r);
}
function pageWidth() {
  return document.body.getBoundingClientRect().width;
}
function pageOffset() {
  return window.pageXOffset;
}
function scrollWidth() {
  var range = document.createRange()
  range.selectNode(document.body)
  return range.getBoundingClientRect().width;
}
function pageCount() {
  return Math.round(scrollWidth() / pageWidth());
}
function pageTo(index) {
  index = clamp(index, 0, pageCount() - 1);
  window.scrollTo({ left: index * pageWidth(), top: 0, behavior: "instant" });
  return index;
}
function currentPageIndex() {
  return Math.round(pageOffset() / pageWidth());
}

window.onresize = function(e) {
  pageTo(currentPageIndex())
}

window.pageTo = pageTo;
window.pageCount = pageCount;

var injectStyleId = '___inject_style';
function injectCSS(cssBase64) {
  css = atob(cssBase64);
  var style = document.getElementById(injectStyleId);
  if (!style) {
    style = document.createElement('style');
    style.id = injectStyleId;
    document.head.appendChild(style);
  }
  style.innerHTML = css;
}

window.injectCSS = injectCSS;