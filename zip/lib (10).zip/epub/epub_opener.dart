import 'dart:typed_data';

import 'package:archive/archive.dart';

import 'accessor/epub_archive.dart';
import 'model/epub.dart';
import 'model/bundle/epub_bundle.dart';
import 'parsers/epub_parser.dart';

class EpubOpener {
  static Future<Epub> openBytes(Uint8List bytes) async {
    final accessor = EpubArchiveAccessor.fromBytes(bytes);
    return await EpubParser.parse(accessor);
  }

  static Future<Epub> openBytesWithBundle(
      Uint8List bytes, EpubBundle bundle) async {
    final accessor = EpubArchiveAccessor.fromBytes(bytes);
    return bundle.toEpub(accessor);
  }

  static Future<Epub> openStream(InputStream stream) async {
    final accessor = EpubArchiveAccessor.fromStream(stream);
    return await EpubParser.parse(accessor);
  }

  static Future<Epub> openStreamWithBundle(
      InputStream stream, EpubBundle bundle) async {
    final accessor = EpubArchiveAccessor.fromStream(stream);
    return bundle.toEpub(accessor);
  }
}
