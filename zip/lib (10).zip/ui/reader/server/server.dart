import 'dart:io';

import 'service.dart';

class Server {
  final Map<String, Service> services = {};

  HttpServer? _server;

  Future<void> handleRequest(HttpRequest request) async {
    final uri = request.uri;
    final segments = uri.pathSegments;
    final part = segments[0];
    final pathWithoutPart = uri.pathSegments.skip(1).join('/');

    try {
      final service = services[part]!;
      await service.handleRequest(pathWithoutPart, request);
    } catch (e) {
      request.response.statusCode = 404;
      request.response.write('Not found');
      request.response.close();
    }
  }

  void registerService(Service service) {
    services[service.part] = service;
  }

  Future<int> startServer() async {
    _server = await HttpServer.bind(InternetAddress.loopbackIPv4, 0);
    _server!.listen(handleRequest);

    return _server!.port;
  }

  void stopServer() {
    _server?.close();
  }
}
