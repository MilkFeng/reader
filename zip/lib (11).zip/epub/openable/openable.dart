import 'dart:isolate';

import '../model/epub.dart';

abstract class Openable {
  Future<Epub> open();
}