import 'dart:io';

import 'package:flutter/material.dart';
import 'package:webview_flutter/webview_flutter.dart';

import '../../../epub/epub.dart';
import '../../../managers/meta/models.dart';

import 'package:webview_flutter_android/webview_flutter_android.dart';
import 'package:webview_flutter_wkwebview/webview_flutter_wkwebview.dart';

class PageReadyDetail {
  PageReadyDetail({
    required this.id,
    required this.pageCount,
  });

  final int id;
  final int pageCount;
}

class PageRendererController extends ChangeNotifier {
  PageRendererController({
    this.pageLocation,
  });

  PageLocation? pageLocation;

  void load(PageLocation? pageLocation) {
    this.pageLocation = pageLocation;
    notifyListeners();
  }
}

class PageRenderer extends StatefulWidget {
  const PageRenderer({
    super.key,
    required this.serverPort,
    required this.navigation,
    required this.onPageReady,
    required this.controller,
    required this.id,
  });

  final int serverPort;
  final Navigation navigation;
  final int id;

  final Function(int, PageReadyDetail) onPageReady;

  final PageRendererController controller;

  @override
  State<StatefulWidget> createState() => PageRendererState();
}

class PageRendererState extends State<PageRenderer> {
  late final WebViewController _webViewController;

  String? _currentPageUrl;
  int? _currentPageIndex;

  @override
  void initState() {
    super.initState();

    _webViewController = WebViewController()
      ..setJavaScriptMode(JavaScriptMode.unrestricted)
      ..setBackgroundColor(Colors.transparent)
      ..setNavigationDelegate(NavigationDelegate(
        onPageFinished: (url) async {
          if (_currentPageUrl == null || url != _currentPageUrl) {
            return;
          }

          if (widget.controller.pageLocation != null) {
            final index = widget.controller.pageLocation!.pageIndex;
            _currentPageIndex = index;
            await setFontColor(Theme.of(context).colorScheme.onSurface);
            await pageTo(index);
            setState(() {});
          }

          widget.onPageReady(
            widget.id,
            PageReadyDetail(
              id: widget.id,
              pageCount: await pageCount(),
            ),
          );
        },
      ))
      ..setUserAgent(_userAgent);

    widget.controller.addListener(() {
      load(widget.controller.pageLocation);
    });

    load(widget.controller.pageLocation);
  }

  String getUrl(PageLocation pageLocation) {
    final href =
        widget.navigation.getHrefByLocation(pageLocation.contentLocation);
    return "http://localhost:${widget.serverPort}/epub/$href";
  }

  Future<void> load(PageLocation? pageLocation) async {
    if (pageLocation == null) {
      return;
    }

    final url = getUrl(pageLocation);
    final index = pageLocation.pageIndex;

    if (url == _currentPageUrl) {
      if (_currentPageIndex != index) {
        _currentPageIndex = index;
        await pageTo(index);
        setState(() {});
      }

      await setFontColor(Theme.of(context).colorScheme.onSurface);
      widget.onPageReady(
        widget.id,
        PageReadyDetail(
          id: widget.id,
          pageCount: await pageCount(),
        ),
      );
      return;
    }

    _currentPageUrl = url;
    _webViewController.loadRequest(Uri.parse(url));

    setState(() {});
  }

  Future<int> pageTo(int index) async {
    return await _webViewController.runJavaScriptReturningResult(
      'window.pageTo($index)',
    ) as int;
  }

  Future<int> pageCount() async {
    return await _webViewController.runJavaScriptReturningResult(
      'window.pageCount()',
    ) as int;
  }

  Future<void> setFontColor(Color color) async {
    await _webViewController.runJavaScript(
      'window.setFontColor(${color.r * 255}, ${color.g * 255}, ${color.b * 255}, ${color.a})',
    );
  }

  static const _userAgent =
      "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.3";

  Widget _buildWebview() {
    if (WebViewPlatform.instance is AndroidWebViewPlatform) {
      final params = AndroidWebViewWidgetCreationParams(
        displayWithHybridComposition: false,
        controller: _webViewController.platform,
      );
      final androidWebViewWidget = AndroidWebViewWidget(params);
      return WebViewWidget.fromPlatform(platform: androidWebViewWidget);
    }

    return WebViewWidget(
      key: ValueKey(widget.id),
      controller: _webViewController,
    );
  }

  @override
  Widget build(BuildContext context) {
    print('PageRenderer build');

    setFontColor(Theme.of(context).colorScheme.onSurface);

    return RepaintBoundary(
      key: ValueKey(widget.id),
      child: _buildWebview(),
    );
  }
}
