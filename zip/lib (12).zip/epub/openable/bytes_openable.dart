import 'dart:typed_data';

import 'package:reader/epub/model/epub.dart';

import '../accessor/epub_archive.dart';
import '../parsers/epub_parser.dart';
import 'openable.dart';

class BytesOpenable extends Openable {
  final Uint8List bytes;

  BytesOpenable(this.bytes);

  @override
  Future<Epub> open() async {
    final accessor = EpubArchiveAccessor.fromBytes(bytes);
    return await EpubParser.parse(accessor);
  }
}
