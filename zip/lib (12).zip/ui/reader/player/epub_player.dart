import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../../epub/epub.dart';
import '../../../global_state/books_state.dart';
import '../../../managers/meta/models.dart';
import 'pages_renderer.dart';
import 'panel.dart';
import 'toc_drawer.dart';

class EpubPlayer extends StatefulWidget {
  const EpubPlayer({
    super.key,
    required this.navigation,
    required this.metadata,
    required this.bookInfo,
    required this.relativePath,
    required this.serverPort,
    required this.initialLocation,
  });

  final Navigation navigation;
  final Metadata metadata;
  final ExtendedBookInfo bookInfo;

  final String relativePath;
  final int serverPort;
  final PageLocation initialLocation;

  @override
  State<EpubPlayer> createState() => _EpubPlayerState();
}

class _EpubPlayerState extends State<EpubPlayer> {
  late final PagesRendererController pagesRendererController;
  late final PanelController panelController;
  late final TOCDrawerController tocDrawerController;

  Navigation get navigation => widget.navigation;

  @override
  void initState() {
    super.initState();

    pagesRendererController = PagesRendererController(
      onPageChanged: onPageChanged,
      initialLocation: widget.initialLocation,
    );
    panelController = PanelController();
    tocDrawerController = TOCDrawerController(
      onNavigate: onNavigate,
      initialLocation: widget.initialLocation,
    );

    panelController.addListener(() {
      setState(() {});
    });
  }

  void onNavigate(NavigationPoint point) {
    final contentLocation = navigation.getFirstContentLocation(point.location)!;
    setState(() {
      final initialLocation = PageLocation.firstPageOf(contentLocation);
      pagesRendererController.resetInitialLocation(initialLocation);
      onPageChanged(initialLocation);
    });
  }

  void onPageChanged(PageLocation pageLocation) {
    tocDrawerController.currentLocation = pageLocation;

    final booksState = context.read<BooksState>();
    final bookInfo = booksState.getBookInfo(widget.relativePath);

    booksState.updateBookInfoTemp(
      bookInfo.copyWith(
        lastReadLocation: pageLocation,
        lastReadTitle: navigation
            .getPointByLocation(pageLocation.contentLocation.pointLocation)!
            .label,
      ),
    );
  }

  @override
  void dispose() {
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {

    print('EpubPlayer build');

    final width = MediaQuery.of(context).size.width;
    return Scaffold(
      resizeToAvoidBottomInset: false,
      body: GestureDetector(
        behavior: HitTestBehavior.opaque,
        onTapUp: (details) {
          // 根据区域判断是打开 panel 还是进行翻页
          if (details.localPosition.dx < width / 4) {
            panelController.closePanel();
            pagesRendererController.onTapToPrevious();
          } else if (details.localPosition.dx > width * 3 / 4) {
            panelController.closePanel();
            pagesRendererController.onTapToNext();
          } else {
            panelController.togglePanel();
          }
          setState(() {});
        },
        onHorizontalDragStart: (details) {
          panelController.closePanel();
          pagesRendererController.onHorizontalDragStart(details);
          setState(() {});
        },
        onHorizontalDragUpdate: (details) {
          pagesRendererController.onHorizontalDragUpdate(details);
        },
        onHorizontalDragEnd: (details) {
          pagesRendererController.onHorizontalDragEnd(details);
          setState(() {});
        },
        onHorizontalDragCancel: () {
          pagesRendererController.onHorizontalDragCancel();
          setState(() {});
        },
        onHorizontalDragDown: (details) {
          pagesRendererController.onHorizontalDragDown(details);
        },
        child: Stack(
          children: [
            PagesRenderer(
              key: ValueKey(pagesRendererController.initialLocation),
              serverPort: widget.serverPort,
              navigation: widget.navigation,
              controller: pagesRendererController,
            ),
            Panel(
              metadata: widget.metadata,
              controller: panelController,
            ),
          ],
        ),
      ),
      drawer: TOCDrawer(
        metadata: widget.metadata,
        navigation: widget.navigation,
        bookInfo: widget.bookInfo,
        controller: tocDrawerController,
      ),
      drawerEnableOpenDragGesture: false,
    );
  }
}
