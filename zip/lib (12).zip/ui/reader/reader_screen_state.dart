import 'dart:convert';

import 'package:flutter/material.dart';

import '../../epub/epub.dart';
import '../../global_state/books_state.dart';
import '../../managers/meta/models.dart';
import 'backend/backend.dart';

class ReaderScreenState extends ChangeNotifier {
  PageLocation? _initialLocation;
  EpubBundle? _epubBundle;
  ExtendedBookInfo? _bookInfo;
  Navigation? _navigation;
  Metadata? _metadata;

  BooksState booksState;
  String relativePath;

  Backend? _backend;

  ReaderScreenState({
    required this.booksState,
    required this.relativePath,
  });

  Future<void> init() async {
    _bookInfo = booksState.getBookInfo(relativePath);

    final epubBundleBytes =
        await booksState.readBytes(_bookInfo!.epubBundleRelativePath);

    _epubBundle = EpubBundle.fromJson(jsonDecode(utf8.decode(epubBundleBytes)));
    _metadata = _epubBundle!.metadataBundle.toMetadata();
    _navigation = _epubBundle!.navigationBundle.toNavigation();

    _initialLocation = _bookInfo!.lastReadLocation;

    final epubBytes = await booksState.readBytes(relativePath);
    _backend = Backend(
      epubOpenable: BytesBundleOpenable(
        bundle: _epubBundle!,
        bytes: epubBytes,
      ),
    );

    await _backend!.start();

    notifyListeners();
  }

  @override
  void dispose() {
    super.dispose();

    booksState.save();
    _backend?.stop();

    _backend = null;
    _epubBundle = null;
    _bookInfo = null;
    _navigation = null;
    _metadata = null;
    _initialLocation = null;
  }

  bool isReady() {
    return _backend != null &&
        _backend!.isReady &&
        _epubBundle != null &&
        _bookInfo != null &&
        _navigation != null &&
        _metadata != null &&
        _initialLocation != null;
  }

  int get serverPort => _backend!.serverPort;
  EpubBundle get epubBundle => _epubBundle!;
  Navigation get navigation => _navigation!;
  Metadata get metadata => _metadata!;
  ExtendedBookInfo get bookInfo => _bookInfo!;
  PageLocation get initialLocation => _initialLocation!;
}
