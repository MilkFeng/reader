import 'prefs.dart';

class SettingsManager {
  static const String rootPathKey = 'root_path';
  static const String isInitialized = 'is_initialized';

  Future<String?> getRootPath() async {
    return await Prefs.get<String>(rootPathKey);
  }

  Future<bool> containsRootPath() async {
    return await Prefs.containsKey(rootPathKey);
  }

  Future<String> checkRootPath() async {
    final rootPath = await getRootPath();
    try {
      if (rootPath == null) {
        throw Exception('Root path is not set');
      } else {}
    } catch (_) {
      setRootPath(null);
      rethrow;
    }
    return rootPath;
  }

  Future<void> setRootPath(String? path) async {
    await Prefs.set(rootPathKey, path);
  }

  Future<void> setIsInitialized(bool value) async {
    await Prefs.set(isInitialized, value);
  }

  Future<bool?> getInitialized() async {
    return await Prefs.get<bool>(isInitialized);
  }
}
