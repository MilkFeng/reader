import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../global_state/books_state.dart';
import 'player/epub_player.dart';
import 'reader_screen_state.dart';

class ReaderScreen extends StatefulWidget {
  const ReaderScreen({super.key, required this.relativePath});

  final String relativePath;

  @override
  State<StatefulWidget> createState() => _ReaderScreenState();
}

class _ReaderScreenState extends State<ReaderScreen> {
  BooksState? booksState;

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    booksState = context.read<BooksState>();
  }

  @override
  void dispose() {
    booksState?.save();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final booksState = context.read<BooksState>();
    final readerScreenState = ReaderScreenState(
      booksState: booksState,
      relativePath: widget.relativePath,
    )..init();

    return ChangeNotifierProvider(
      create: (context) => readerScreenState,
      child: Consumer<ReaderScreenState>(builder: (context, state, _) {
        if (!state.isReady()) {
          return const Scaffold(
            body: Center(
              child: Text('正在加载中...'),
            ),
          );
        }

        return EpubPlayer(
          serverPort: state.serverPort,
          relativePath: state.relativePath,
          metadata: state.metadata,
          bookInfo: state.bookInfo,
          navigation: state.navigation,
          initialLocation: state.initialLocation,
        );
      }),
    );

    // return ChangeNotifierProxyProvider<BooksState, ReaderScreenState?>(
    //   create: (context) => null,
    //   update: (context, booksState, state) {
    //     if (state == null) {
    //       return ReaderScreenState(
    //         booksState: booksState,
    //         relativePath: widget.relativePath,
    //       )..init();
    //     } else {
    //       return state;
    //     }
    //   },
    //   child: Consumer<ReaderScreenState?>(builder: (context, state, _) {
    //     if (state == null || !state.isReady()) {
    //       return const Scaffold(
    //         body: Center(
    //           child: Text('正在加载中...'),
    //         ),
    //       );
    //     }
    //
    //     return EpubPlayer(
    //       serverPort: state.serverPort,
    //       relativePath: state.relativePath,
    //       metadata: state.metadata,
    //       bookInfo: state.bookInfo,
    //       navigation: state.navigation,
    //       initialLocation: state.initialLocation,
    //     );
    //   }),
    // );
  }
}
