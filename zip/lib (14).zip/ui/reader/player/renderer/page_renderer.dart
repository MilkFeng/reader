import 'package:flutter/material.dart';
import 'package:flutter_inappwebview/flutter_inappwebview.dart';

import '../../../../epub/epub.dart';
import '../../../../managers/meta/models.dart';

class PageReadyDetail {
  PageReadyDetail({
    required this.id,
    required this.pageCount,
  });

  final int id;
  final int pageCount;
}

class PageRendererController extends ChangeNotifier {
  PageRendererController({
    this.pageLocation,
  });

  PageLocation? pageLocation;

  void load(PageLocation? pageLocation) {
    this.pageLocation = pageLocation;
    notifyListeners();
  }
}

class PageRenderer extends StatefulWidget {
  const PageRenderer({
    super.key,
    required this.serverPort,
    required this.navigation,
    required this.onPageReady,
    required this.controller,
    required this.id,
  });

  final int serverPort;
  final Navigation navigation;
  final int id;

  final Function(int, PageReadyDetail) onPageReady;

  final PageRendererController controller;

  @override
  State<StatefulWidget> createState() => PageRendererState();
}

class PageRendererState extends State<PageRenderer> {
  InAppWebViewController? _webViewController;

  String? _currentPageUrl;
  int? _currentPageIndex;

  @override
  void initState() {
    super.initState();

    widget.controller.addListener(() {
      load(widget.controller.pageLocation);
    });
  }

  String getUrl(PageLocation pageLocation) {
    final href =
        widget.navigation.getHrefByLocation(pageLocation.contentLocation);
    return "http://localhost:${widget.serverPort}/epub/$href";
  }

  Future<void> load(PageLocation? pageLocation) async {
    if (pageLocation == null) {
      return;
    }

    final url = getUrl(pageLocation);
    final index = pageLocation.pageIndex;

    if (url == _currentPageUrl) {
      if (_currentPageIndex != index) {
        _currentPageIndex = index;
        await pageTo(index);
        setState(() {});
      }

      await setFontColor(Theme.of(context).colorScheme.onSurface);
      widget.onPageReady(
        widget.id,
        PageReadyDetail(
          id: widget.id,
          pageCount: await pageCount(),
        ),
      );
      return;
    }

    _currentPageUrl = url;
    final urlRequest = URLRequest(url: WebUri.uri(Uri.parse(url)));
    _webViewController?.loadUrl(urlRequest: urlRequest);
  }

  Future<int> pageTo(int index) async {
    return await _webViewController?.evaluateJavascript(
      source: 'window.pageTo($index)',
    ) as int;
  }

  Future<int> pageCount() async {
    return await _webViewController?.evaluateJavascript(
      source: 'window.pageCount()',
    ) as int;
  }

  Future<void> setFontColor(Color color) async {
    await _webViewController?.evaluateJavascript(
      source:
          'window.setFontColor(${color.r * 255}, ${color.g * 255}, ${color.b * 255}, ${color.a})',
    );
  }

  static const _userAgent =
      "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.3";

  Widget _buildWebView() {
    if (_webViewController != null) {
      setFontColor(Theme.of(context).colorScheme.onSurface);
    }

    URLRequest? initialUrlRequest;
    if (widget.controller.pageLocation != null) {
      final url = getUrl(widget.controller.pageLocation!);
      _currentPageUrl = url;
      initialUrlRequest = URLRequest(url: WebUri.uri(Uri.parse(url)));
    }

    return InAppWebView(
      key: ValueKey(widget.id),
      initialUrlRequest: initialUrlRequest,
      onWebViewCreated: (controller) {
        _webViewController = controller;
      },
      initialSettings: InAppWebViewSettings(
        disableVerticalScroll: true,
        disableHorizontalScroll: true,
        disallowOverScroll: true,
        supportZoom: false,
        useHybridComposition: false,
        verticalScrollBarEnabled: false,
        horizontalScrollBarEnabled: false,
        transparentBackground: true,
        isInspectable: false,
        supportMultipleWindows: false,
        allowsLinkPreview: false,
        userAgent: _userAgent,
        cacheEnabled: true,
        cacheMode: CacheMode.LOAD_CACHE_ELSE_NETWORK,
      ),
      onLoadStop: (controller, url) async {
        print("onLoadStop: $url");
        if (_currentPageUrl == null || url?.uriValue != Uri.parse(_currentPageUrl!)) {
          return;
        }

        if (widget.controller.pageLocation != null) {
          final index = widget.controller.pageLocation!.pageIndex;
          _currentPageIndex = index;
          await setFontColor(Theme.of(context).colorScheme.onSurface);
          await pageTo(index);
        }

        widget.onPageReady(
          widget.id,
          PageReadyDetail(
            id: widget.id,
            pageCount: await pageCount(),
          ),
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    return RepaintBoundary(
      key: ValueKey(widget.id),
      child: _buildWebView(),
    );
  }
}
