// import 'dart:math';
//
// import 'package:flutter/material.dart';
// import 'package:flutter/physics.dart';
// import 'package:provider/provider.dart';
// import 'package:reader/ui/reader/player/renderer/constant.dart';
//
// import '../../../../managers/meta/models.dart';
// import '../../reader_screen_state.dart';
// import '../common/gesture_consumer.dart';
// import 'page_renderer.dart';
// import 'transition/cover_reader_page_transition.dart';
//
// class PagesRendererController extends ChangeNotifier {
//   PagesRendererController({
//     required this.onPageChanged,
//     required PageLocation initialLocation,
//   }) : _initialLocation = initialLocation;
//
//   GestureConsumer _gestureConsumer = GestureConsumer();
//   final Function(PageLocation) onPageChanged;
//   PageLocation _initialLocation;
//
//   void _registerGestureConsumer(GestureConsumer consumer) {
//     _gestureConsumer = consumer;
//   }
//
//   void resetInitialLocation(PageLocation location) {
//     _initialLocation = location;
//     notifyListeners();
//   }
//
//   PageLocation get initialLocation => _initialLocation;
//
//   GestureConsumer get gestureConsumer => _gestureConsumer;
// }
//
// enum _FlingDirection {
//   previous,
//   current,
//   next,
//   none,
// }
//
// class _PageMeta {
//   final Widget page;
//   final int id;
//   final PageRendererController controller;
//   int pageCount;
//   bool ready;
//
//   _PageMeta({
//     required this.page,
//     required this.id,
//     required this.controller,
//     required this.pageCount,
//     required this.ready,
//   });
// }
//
// class PagesRenderer extends StatefulWidget {
//   const PagesRenderer({super.key, required this.controller});
//
//   final PagesRendererController controller;
//
//   @override
//   State<PagesRenderer> createState() => _PagesRendererState();
// }
//
// class _PagesRendererState extends State<PagesRenderer>
//     with TickerProviderStateMixin {
//   static final springDescription = SpringDescription.withDampingRatio(
//     mass: 1,
//     stiffness: 200,
//     ratio: 1.0,
//   );
//
//   late List<_PageMeta> pages;
//
//   late bool isDragging;
//   late final ValueNotifier<double> dragProgress;
//
//   late AnimationController animationController;
//   late _FlingDirection flingDirection;
//
//   PagesRendererController get controller => widget.controller;
//
//   @override
//   void initState() {
//     super.initState();
//     pages = List.generate(2 * kSymmetricPageCount + 1, (i) {
//       final controller = PageRendererController();
//       return _PageMeta(
//         page: buildPage(i, controller),
//         id: i,
//         controller: controller,
//         pageCount: 0,
//         ready: false,
//       );
//     });
//
//     isDragging = false;
//     dragProgress = ValueNotifier(0.0);
//
//     animationController = AnimationController(
//       vsync: this,
//       duration: Duration(milliseconds: 300),
//     );
//     flingDirection = _FlingDirection.none;
//
//     controller._registerGestureConsumer(
//       GestureConsumer(
//         consumeHorizontalDragStart: consumeHorizontalDragStart,
//         consumeHorizontalDragUpdate: consumeHorizontalDragUpdate,
//         consumeHorizontalDragEnd: consumeHorizontalDragEnd,
//         consumeHorizontalDragDown: consumeHorizontalDragDown,
//         consumeHorizontalDragCancel: consumeHorizontalDragCancel,
//         consumeTapUp: consumeTapUp,
//       ),
//     );
//
//     controller.addListener(() {
//       loadPage(controller.initialLocation);
//     });
//
//     loadPage(controller.initialLocation);
//   }
//
//   _PageMeta getPage(int index) {
//     return pages[getSwitchedIndex(index)];
//   }
//
//   int getSwitchedIndex(int index) {
//     return kSymmetricPageCount - index;
//   }
//
//   void loadPage(PageLocation location) {
//     loadLocationForPage(-1, getPreviousPageLocation(location));
//     loadLocationForPage(0, location);
//   }
//
//   void loadLocationForPage(int index, PageLocation? location) {
//     getPage(index).controller.load(location);
//     getPage(index).ready = false;
//   }
//
//   Widget buildPage(int index, PageRendererController controller) {
//     final readerScreenState = context.read<ReaderScreenState>();
//
//     return PageRenderer(
//       id: index,
//       serverPort: readerScreenState.serverPort,
//       navigation: readerScreenState.navigation,
//       onPageReady: onPageReady,
//       controller: controller,
//     );
//   }
//
//   void onPageReady(int id, PageReadyDetail detail) {
//     final index = getSwitchedIndex(pages.indexWhere((e) => e.id == id));
//     onPageCountLoaded(index, detail.pageCount);
//     getPage(index).ready = true;
//   }
//
//   void onPageCountLoaded(int index, int pageCount) {
//     pages[index].pageCount = pageCount;
//     // 如果 location 的页数超过总页数，需要重新计算 location
//     if (pages[index].controller.pageLocation != null &&
//         pages[index].controller.pageLocation!.pageIndex >= pageCount) {
//       final newLocation = PageLocation(
//         contentLocation: pages[index].controller.pageLocation!.contentLocation,
//         pageIndex: pageCount - 1,
//       );
//       loadLocationForPage(index, newLocation);
//     }
//
//     if (index == kSymmetricPageCount - 0 &&
//         pages[index].controller.pageLocation != null) {
//       // 如果是当前页，可以获得下一页的 location
//       // 上一页不需要在这里更新
//       final nextPageLocation = getNextPageLocation(
//         pages[index].controller.pageLocation!,
//         pageCount,
//       );
//       if (nextPageLocation != null) {
//         loadLocationForPage(nextPageIndex, nextPageLocation);
//       }
//     }
//     setState(() {});
//   }
//
//   bool isFirstPage(PageLocation pageLocation) {
//     final readerScreenState = context.read<ReaderScreenState>();
//
//     return pageLocation.pageIndex == 0 &&
//         readerScreenState.navigation.firstLocation ==
//             pageLocation.contentLocation;
//   }
//
//   bool isLastPage(PageLocation pageLocation, int pageCount) {
//     final readerScreenState = context.read<ReaderScreenState>();
//
//     return pageLocation.pageIndex == pageCount - 1 &&
//         readerScreenState.navigation.lastLocation ==
//             pageLocation.contentLocation;
//   }
//
//   PageLocation? getNextPageLocation(PageLocation pageLocation, int pageCount) {
//     final readerScreenState = context.read<ReaderScreenState>();
//
//     if (pageLocation.pageIndex + 1 < pageCount) {
//       return PageLocation(
//         contentLocation: pageLocation.contentLocation,
//         pageIndex: pageLocation.pageIndex + 1,
//       );
//     } else {
//       final nextContentLocation = readerScreenState.navigation
//           .getNextContentLocation(pageLocation.contentLocation);
//       if (nextContentLocation != null) {
//         return PageLocation(
//           contentLocation: nextContentLocation,
//           pageIndex: 0,
//         );
//       }
//     }
//     return null;
//   }
//
//   PageLocation? getPreviousPageLocation(PageLocation pageLocation) {
//     final readerScreenState = context.read<ReaderScreenState>();
//
//     if (pageLocation.pageIndex > 0) {
//       return PageLocation(
//         contentLocation: pageLocation.contentLocation.clone(),
//         pageIndex: pageLocation.pageIndex - 1,
//       );
//     } else {
//       final previousContentLocation = readerScreenState.navigation
//           .getPreviousContentLocation(pageLocation.contentLocation);
//       if (previousContentLocation != null) {
//         return PageLocation(
//           contentLocation: previousContentLocation,
//           pageIndex: 100000000,
//         );
//       }
//     }
//     return null;
//   }
//
//   void _cycleLeft<T>(List<T> list, int i, int j, int k) {
//     final temp = list[i];
//     list[i] = list[j];
//     list[j] = list[k];
//     list[k] = temp;
//   }
//
//   void _cycleRight<T>(List<T> list, int i, int j, int k) {
//     final temp = list[k];
//     list[k] = list[j];
//     list[j] = list[i];
//     list[i] = temp;
//   }
//
//   void cycleLeft() {
//     final tempPage = pages[0];
//     for (var i = 0; i < 2 * kSymmetricPageCount - 1 - 1; i++) {
//       pages[i] = pages[i + 1];
//     }
//     pages[2 * kSymmetricPageCount - 1 - 1] = tempPage;
//   }
//
//   void cycleRight() {
//     final tempPage = pages[2 * kSymmetricPageCount - 1 - 1];
//     for (var i = 2 * kSymmetricPageCount - 1 - 1; i > 0; i--) {
//       pages[i] = pages[i - 1];
//     }
//     pages[0] = tempPage;
//   }
//
//   void paginateToNext() {
//     cycleLeft();
//
//     final nextPageLocation = getNextPageLocation(
//       pages[currentPageIndex].controller.pageLocation!,
//       pages[currentPageIndex].pageCount,
//     );
//     loadLocationForPage(nextPageIndex, nextPageLocation);
//     controller.onPageChanged(
//       pages[currentPageIndex].controller.pageLocation!,
//     );
//     setState(() {});
//   }
//
//   void paginateToPrevious() {
//     cycleRight();
//     final previousPageLocation = getPreviousPageLocation(
//       pages[currentPageIndex].controller.pageLocation!,
//     );
//     loadLocationForPage(previousPageIndex, previousPageLocation);
//     controller.onPageChanged(
//       pages[currentPageIndex].controller.pageLocation!,
//     );
//     setState(() {});
//   }
//
//   void removeAllAnimationListeners() {
//     animationController
//         .removeListener(_changeDragProgressForAnimatedPaginateToNext);
//     animationController
//         .removeListener(_changeDragProgressForAnimatedPaginateToPrevious);
//     animationController
//         .removeListener(_changeDragProgressForAnimatedToCurrentPage);
//   }
//
//   void _changeDragProgressForAnimatedPaginateToNext() {
//     dragProgress.value = -animationController.value;
//   }
//
//   void animatedPaginateToNext(double velocity) async {
//     // dragProgress 从当前值到 -1
//     flingDirection = _FlingDirection.next;
//     final spring =
//         SpringSimulation(springDescription, -dragProgress.value, 1, -velocity);
//
//     animationController.reset();
//     removeAllAnimationListeners();
//     animationController
//         .addListener(_changeDragProgressForAnimatedPaginateToNext);
//     await animationController.animateWith(spring);
//     dragProgress.value = 0.0;
//     paginateToNext();
//
//     flingDirection = _FlingDirection.none;
//   }
//
//   void _changeDragProgressForAnimatedPaginateToPrevious() {
//     dragProgress.value = animationController.value;
//   }
//
//   void animatedPaginateToPrevious(double velocity) async {
//     flingDirection = _FlingDirection.previous;
//     // dragProgress 从当前值到 1
//     final spring =
//         SpringSimulation(springDescription, dragProgress.value, 1, velocity);
//
//     animationController.reset();
//     removeAllAnimationListeners();
//     animationController
//         .addListener(_changeDragProgressForAnimatedPaginateToPrevious);
//     await animationController.animateWith(spring);
//
//     dragProgress.value = 0.0;
//     paginateToPrevious();
//
//     flingDirection = _FlingDirection.none;
//   }
//
//   void _changeDragProgressForAnimatedToCurrentPage() {
//     dragProgress.value = animationController.value * 2 - 1;
//   }
//
//   void animatedPaginateToCurrent(double velocity) async {
//     flingDirection = _FlingDirection.current;
//     // dragProgress 从当前值到 0
//     final spring = SpringSimulation(
//         springDescription, dragProgress.value / 2 + 0.5, 0.5, velocity);
//
//     animationController.reset();
//     removeAllAnimationListeners();
//     animationController
//         .addListener(_changeDragProgressForAnimatedToCurrentPage);
//     await animationController.animateWith(spring);
//
//     dragProgress.value = 0.0;
//     flingDirection = _FlingDirection.none;
//   }
//
//   bool get hasPreviousPage =>
//       pages[previousPageIndex].controller.pageLocation != null;
//
//   bool get hasNextPage => pages[nextPageIndex].controller.pageLocation != null;
//
//   void forceFlingToNext() {
//     animationController.stop();
//     removeAllAnimationListeners();
//     dragProgress.value = 0.0;
//     paginateToNext();
//
//     flingDirection = _FlingDirection.none;
//   }
//
//   void forceFlingToPrevious() {
//     animationController.stop();
//     removeAllAnimationListeners();
//     dragProgress.value = 0.0;
//     paginateToPrevious();
//
//     flingDirection = _FlingDirection.none;
//   }
//
//   void forceFlingToCurrent() {
//     animationController.stop();
//     removeAllAnimationListeners();
//     dragProgress.value = 0.0;
//
//     flingDirection = _FlingDirection.none;
//   }
//
//   void forceFling() {
//     if (flingDirection == _FlingDirection.next) {
//       forceFlingToNext();
//     } else if (flingDirection == _FlingDirection.previous) {
//       forceFlingToPrevious();
//     } else if (flingDirection == _FlingDirection.current) {
//       forceFlingToCurrent();
//     }
//   }
//
//   bool consumeTapUp(TapUpDetails details) {
//     // 根据点击位置判断是翻前一页还是翻后一页
//     final width = MediaQuery.of(context).size.width;
//     if (details.localPosition.dx < width / 2) {
//       if (hasPreviousPage) {
//         forceFling();
//         animatedPaginateToPrevious(0);
//       }
//     } else {
//       if (hasNextPage) {
//         forceFling();
//         animatedPaginateToNext(0);
//       }
//     }
//
//     return true;
//   }
//
//   bool consumeHorizontalDragStart(DragStartDetails details) {
//     forceFling();
//     isDragging = true;
//     dragProgress.value = 0;
//     return true;
//   }
//
//   bool consumeHorizontalDragUpdate(DragUpdateDetails details) {
//     final width = MediaQuery.of(context).size.width;
//     if (!isDragging || flingDirection != _FlingDirection.none) {
//       return true;
//     }
//
//     var delta = details.primaryDelta! / width;
//     if (delta.abs() > 0.3) {
//       delta = delta.sign * 0.3;
//     }
//     dragProgress.value += delta;
//
//     if (!hasPreviousPage && dragProgress.value > 0) {
//       dragProgress.value = 0;
//     } else if (!hasNextPage && dragProgress.value < 0) {
//       dragProgress.value = 0;
//     }
//
//     return true;
//   }
//
//   bool consumeHorizontalDragEnd(DragEndDetails details) {
//     final width = MediaQuery.of(context).size.width;
//     final velocity = details.primaryVelocity! / width;
//
//     if (!isDragging || flingDirection != _FlingDirection.none) {
//       return true;
//     }
//
//     isDragging = false;
//
//     if (hasPreviousPage &&
//         ((dragProgress.value > 1 / 2 && velocity > -0.2) ||
//             (dragProgress.value > 0 && velocity > 0.2))) {
//       animatedPaginateToPrevious(velocity);
//     } else if (hasNextPage &&
//         ((dragProgress.value < -1 / 2 && velocity < 0.2) ||
//             (dragProgress.value < 0 && velocity < -0.2))) {
//       animatedPaginateToNext(velocity);
//     } else {
//       if (dragProgress.value > 0) {
//         if (hasPreviousPage) {
//           animatedPaginateToCurrent(max(velocity, 0));
//         } else {
//           dragProgress.value = 0;
//         }
//       } else {
//         if (hasNextPage) {
//           animatedPaginateToCurrent(min(velocity, 0));
//         } else {
//           dragProgress.value = 0;
//         }
//       }
//     }
//
//     return true;
//   }
//
//   bool consumeHorizontalDragDown(DragDownDetails details) {
//     return true;
//   }
//
//   bool consumeHorizontalDragCancel() {
//     isDragging = false;
//     forceFling();
//     return true;
//   }
//
//   @override
//   Widget build(BuildContext context) {
//     MediaQuery.of(context).gestureSettings;
//
//     final width = MediaQuery.of(context).size.width;
//     final height = MediaQuery.of(context).size.height;
//
//     final top = MediaQuery.of(context).viewPadding.top;
//     final bottom = MediaQuery.of(context).viewPadding.bottom;
//     final padding = 16.0;
//
//     final pageTransition = CoverReaderPageTransition();
//
//     print('PagesRenderer build');
//
//     return RepaintBoundary(
//       child: ClipRect(
//         child: Stack(
//           clipBehavior: Clip.hardEdge,
//           children: List.generate(3, (index) {
//             return ValueListenableBuilder<double>(
//               key: ValueKey(pages[index].id),
//               valueListenable: dragProgress,
//               builder: (context, value, child) {
//                 final transform = pageTransition.calculateTransform(
//                   value,
//                   1 - index,
//                   Size(width, height),
//                 );
//
//                 return Transform(
//                   transform: transform,
//                   child: Container(
//                     decoration: BoxDecoration(
//                       color: Theme.of(context).colorScheme.surface,
//                       boxShadow: [
//                         BoxShadow(
//                           color: Colors.black.withValues(alpha: 0.1),
//                           offset: Offset(0, 0),
//                           blurRadius: 10,
//                         ),
//                       ],
//                     ),
//                     child: Stack(
//                       key: ValueKey(pages[index].id),
//                       children: [
//                         Padding(
//                           padding: EdgeInsets.only(
//                             left: padding,
//                             right: padding,
//                             top: top + padding,
//                             bottom: bottom + padding,
//                           ),
//                           child: pages[index].page,
//                         ),
//                         if (!pages[index].ready)
//                           Positioned(
//                             top: 0,
//                             left: 0,
//                             right: 0,
//                             bottom: 0,
//                             child: Container(
//                               color: Theme.of(context).colorScheme.surface,
//                               child: Center(
//                                 child: Text('正在加载中...'),
//                               ),
//                             ),
//                           ),
//                       ],
//                     ),
//                   ),
//                 );
//               },
//             );
//           }).toList(),
//         ),
//       ),
//     );
//   }
// }


import 'dart:math';

import 'package:flutter/material.dart';
import 'package:flutter/physics.dart';
import 'package:provider/provider.dart';
import 'transition/linear_reader_page_transition.dart';

import '../../../../managers/meta/models.dart';
import '../../reader_screen_state.dart';
import '../common/gesture_consumer.dart';
import 'page_renderer.dart';
import 'transition/cover_reader_page_transition.dart';

class PagesRendererController extends ChangeNotifier {
  PagesRendererController({
    required this.onPageChanged,
    required PageLocation initialLocation,
  }) : _initialLocation = initialLocation;

  GestureConsumer _gestureConsumer = GestureConsumer();
  final Function(PageLocation) onPageChanged;
  PageLocation _initialLocation;

  void _registerGestureConsumer(GestureConsumer consumer) {
    _gestureConsumer = consumer;
  }

  void resetInitialLocation(PageLocation location) {
    _initialLocation = location;
    notifyListeners();
  }

  PageLocation get initialLocation => _initialLocation;

  GestureConsumer get gestureConsumer => _gestureConsumer;
}

enum _FlingDirection {
  previous,
  current,
  next,
  none,
}

class _PageMeta {
  final Widget page;
  final int id;
  final PageRendererController controller;
  int pageCount;
  bool ready;

  _PageMeta({
    required this.page,
    required this.id,
    required this.controller,
    required this.pageCount,
    required this.ready,
  });
}

class PagesRenderer extends StatefulWidget {
  const PagesRenderer({
    super.key,
    required this.controller,
  });

  final PagesRendererController controller;

  @override
  State<PagesRenderer> createState() => _PagesRendererState();
}

class _PagesRendererState extends State<PagesRenderer>
    with TickerProviderStateMixin {
  static const previousPageIndex = 2;
  static const currentPageIndex = 1;
  static const nextPageIndex = 0;
  static final springDescription = SpringDescription.withDampingRatio(
    mass: 1,
    stiffness: 200,
    ratio: 1.0,
  );

  late List<_PageMeta> pages;

  late bool isDragging;
  late final ValueNotifier<double> dragProgress;

  late AnimationController animationController;
  late _FlingDirection flingDirection;

  PagesRendererController get controller => widget.controller;

  @override
  void initState() {
    super.initState();
    pages = List.generate(3, (i) {
      final controller = PageRendererController();
      return _PageMeta(
        page: buildPage(i, controller),
        id: i,
        controller: controller,
        pageCount: 0,
        ready: false,
      );
    });

    isDragging = false;
    dragProgress = ValueNotifier(0.0);

    animationController = AnimationController(
      vsync: this,
      duration: Duration(milliseconds: 300),
    );
    flingDirection = _FlingDirection.none;

    controller._registerGestureConsumer(
      GestureConsumer(
        consumeHorizontalDragStart: consumeHorizontalDragStart,
        consumeHorizontalDragUpdate: consumeHorizontalDragUpdate,
        consumeHorizontalDragEnd: consumeHorizontalDragEnd,
        consumeHorizontalDragDown: consumeHorizontalDragDown,
        consumeHorizontalDragCancel: consumeHorizontalDragCancel,
        consumeTapUp: consumeTapUp,
      ),
    );

    controller.addListener(() {
      loadPage(controller.initialLocation);
    });

    loadPage(controller.initialLocation);
  }

  void loadPage(PageLocation location) {
    loadLocationForPage(previousPageIndex, getPreviousPageLocation(location));
    loadLocationForPage(currentPageIndex, location);
  }

  void loadLocationForPage(int index, PageLocation? location) {
    pages[index].controller.load(location);
    pages[index].ready = false;
  }

  Widget buildPage(int index, PageRendererController controller) {
    final readerScreenState = context.read<ReaderScreenState>();

    return PageRenderer(
      id: index,
      serverPort: readerScreenState.serverPort,
      navigation: readerScreenState.navigation,
      onPageReady: onPageReady,
      controller: controller,
    );
  }

  void onPageReady(int id, PageReadyDetail detail) {
    final index = pages.indexWhere((e) => e.id == id);
    onPageCountLoaded(index, detail.pageCount);
    pages[index].ready = true;
  }

  void onPageCountLoaded(int index, int pageCount) {
    pages[index].pageCount = pageCount;
    // 如果 location 的页数超过总页数，需要重新计算 location
    if (pages[index].controller.pageLocation != null &&
        pages[index].controller.pageLocation!.pageIndex >= pageCount) {
      final newLocation = PageLocation(
        contentLocation: pages[index].controller.pageLocation!.contentLocation,
        pageIndex: pageCount - 1,
      );
      loadLocationForPage(index, newLocation);
    }

    if (index == currentPageIndex &&
        pages[index].controller.pageLocation != null) {
      // 如果是当前页，可以获得下一页的 location
      // 上一页不需要在这里更新
      final nextPageLocation = getNextPageLocation(
        pages[index].controller.pageLocation!,
        pageCount,
      );
      if (nextPageLocation != null) {
        loadLocationForPage(nextPageIndex, nextPageLocation);
      }
    }
    setState(() {});
  }

  bool isFirstPage(PageLocation pageLocation) {
    final readerScreenState = context.read<ReaderScreenState>();

    return pageLocation.pageIndex == 0 &&
        readerScreenState.navigation.firstLocation ==
            pageLocation.contentLocation;
  }

  bool isLastPage(PageLocation pageLocation, int pageCount) {
    final readerScreenState = context.read<ReaderScreenState>();

    return pageLocation.pageIndex == pageCount - 1 &&
        readerScreenState.navigation.lastLocation ==
            pageLocation.contentLocation;
  }

  PageLocation? getNextPageLocation(PageLocation pageLocation, int pageCount) {
    final readerScreenState = context.read<ReaderScreenState>();

    if (pageLocation.pageIndex + 1 < pageCount) {
      return PageLocation(
        contentLocation: pageLocation.contentLocation,
        pageIndex: pageLocation.pageIndex + 1,
      );
    } else {
      final nextContentLocation = readerScreenState.navigation
          .getNextContentLocation(pageLocation.contentLocation);
      if (nextContentLocation != null) {
        return PageLocation(
          contentLocation: nextContentLocation,
          pageIndex: 0,
        );
      }
    }
    return null;
  }

  PageLocation? getPreviousPageLocation(PageLocation pageLocation) {
    final readerScreenState = context.read<ReaderScreenState>();

    if (pageLocation.pageIndex > 0) {
      return PageLocation(
        contentLocation: pageLocation.contentLocation.clone(),
        pageIndex: pageLocation.pageIndex - 1,
      );
    } else {
      final previousContentLocation = readerScreenState.navigation
          .getPreviousContentLocation(pageLocation.contentLocation);
      if (previousContentLocation != null) {
        return PageLocation(
          contentLocation: previousContentLocation,
          pageIndex: 100000000,
        );
      }
    }
    return null;
  }

  void _cycleLeft<T>(List<T> list, int i, int j, int k) {
    final temp = list[i];
    list[i] = list[j];
    list[j] = list[k];
    list[k] = temp;
  }

  void _cycleRight<T>(List<T> list, int i, int j, int k) {
    final temp = list[k];
    list[k] = list[j];
    list[j] = list[i];
    list[i] = temp;
  }

  void cycleLeft() {
    // previous current next   ->   current next previous
    _cycleLeft(pages, previousPageIndex, currentPageIndex, nextPageIndex);
  }

  void cycleRight() {
    // previous current next   ->   next previous current
    _cycleRight(pages, previousPageIndex, currentPageIndex, nextPageIndex);
  }

  void paginateToNext() {
    cycleLeft();

    final nextPageLocation = getNextPageLocation(
      pages[currentPageIndex].controller.pageLocation!,
      pages[currentPageIndex].pageCount,
    );
    loadLocationForPage(nextPageIndex, nextPageLocation);
    controller.onPageChanged(
      pages[currentPageIndex].controller.pageLocation!,
    );
    setState(() {});
  }

  void paginateToPrevious() {
    cycleRight();
    final previousPageLocation = getPreviousPageLocation(
      pages[currentPageIndex].controller.pageLocation!,
    );
    loadLocationForPage(previousPageIndex, previousPageLocation);
    controller.onPageChanged(
      pages[currentPageIndex].controller.pageLocation!,
    );
    setState(() {});
  }

  void removeAllAnimationListeners() {
    animationController
        .removeListener(_changeDragProgressForAnimatedPaginateToNext);
    animationController
        .removeListener(_changeDragProgressForAnimatedPaginateToPrevious);
    animationController
        .removeListener(_changeDragProgressForAnimatedToCurrentPage);
  }

  void _changeDragProgressForAnimatedPaginateToNext() {
    dragProgress.value = -animationController.value;
  }

  void animatedPaginateToNext(double velocity) async {
    // dragProgress 从当前值到 -1
    flingDirection = _FlingDirection.next;
    final spring =
    SpringSimulation(springDescription, -dragProgress.value, 1, -velocity);

    animationController.reset();
    removeAllAnimationListeners();
    animationController
        .addListener(_changeDragProgressForAnimatedPaginateToNext);
    await animationController.animateWith(spring);
    dragProgress.value = 0.0;
    paginateToNext();

    flingDirection = _FlingDirection.none;
  }

  void _changeDragProgressForAnimatedPaginateToPrevious() {
    dragProgress.value = animationController.value;
  }

  void animatedPaginateToPrevious(double velocity) async {
    flingDirection = _FlingDirection.previous;
    // dragProgress 从当前值到 1
    final spring =
    SpringSimulation(springDescription, dragProgress.value, 1, velocity);

    animationController.reset();
    removeAllAnimationListeners();
    animationController
        .addListener(_changeDragProgressForAnimatedPaginateToPrevious);
    await animationController.animateWith(spring);

    dragProgress.value = 0.0;
    paginateToPrevious();

    flingDirection = _FlingDirection.none;
  }

  void _changeDragProgressForAnimatedToCurrentPage() {
    dragProgress.value = animationController.value * 2 - 1;
  }

  void animatedPaginateToCurrent(double velocity) async {
    flingDirection = _FlingDirection.current;
    // dragProgress 从当前值到 0
    final spring = SpringSimulation(
        springDescription, dragProgress.value / 2 + 0.5, 0.5, velocity);

    animationController.reset();
    removeAllAnimationListeners();
    animationController
        .addListener(_changeDragProgressForAnimatedToCurrentPage);
    await animationController.animateWith(spring);

    dragProgress.value = 0.0;
    flingDirection = _FlingDirection.none;
  }

  bool get hasPreviousPage =>
      pages[previousPageIndex].controller.pageLocation != null;

  bool get hasNextPage => pages[nextPageIndex].controller.pageLocation != null;

  void forceFlingToNext() {
    animationController.stop();
    removeAllAnimationListeners();
    dragProgress.value = 0.0;
    paginateToNext();

    flingDirection = _FlingDirection.none;
  }

  void forceFlingToPrevious() {
    animationController.stop();
    removeAllAnimationListeners();
    dragProgress.value = 0.0;
    paginateToPrevious();

    flingDirection = _FlingDirection.none;
  }

  void forceFlingToCurrent() {
    animationController.stop();
    removeAllAnimationListeners();
    dragProgress.value = 0.0;

    flingDirection = _FlingDirection.none;
  }

  void forceFling() {
    if (flingDirection == _FlingDirection.next) {
      forceFlingToNext();
    } else if (flingDirection == _FlingDirection.previous) {
      forceFlingToPrevious();
    } else if (flingDirection == _FlingDirection.current) {
      forceFlingToCurrent();
    }
  }

  bool consumeTapUp(TapUpDetails details) {
    // 根据点击位置判断是翻前一页还是翻后一页
    final width = MediaQuery.of(context).size.width;
    if (details.localPosition.dx < width / 2) {
      if (hasPreviousPage) {
        forceFling();
        animatedPaginateToPrevious(0);
      }
    } else {
      if (hasNextPage) {
        forceFling();
        animatedPaginateToNext(0);
      }
    }

    return true;
  }

  bool consumeHorizontalDragStart(DragStartDetails details) {
    forceFling();
    isDragging = true;
    dragProgress.value = 0;
    return true;
  }

  bool consumeHorizontalDragUpdate(DragUpdateDetails details) {
    final width = MediaQuery.of(context).size.width;
    if (!isDragging || flingDirection != _FlingDirection.none) {
      return true;
    }

    var delta = details.primaryDelta! / width;
    if (delta.abs() > 0.3) {
      delta = delta.sign * 0.3;
    }
    dragProgress.value += delta;

    if (!hasPreviousPage && dragProgress.value > 0) {
      dragProgress.value = 0;
    } else if (!hasNextPage && dragProgress.value < 0) {
      dragProgress.value = 0;
    }

    return true;
  }

  bool consumeHorizontalDragEnd(DragEndDetails details) {
    final width = MediaQuery.of(context).size.width;
    final velocity = details.primaryVelocity! / width;

    if (!isDragging || flingDirection != _FlingDirection.none) {
      return true;
    }

    isDragging = false;

    if (hasPreviousPage &&
        ((dragProgress.value > 1 / 2 && velocity > -0.2) ||
            (dragProgress.value > 0 && velocity > 0.2))) {
      animatedPaginateToPrevious(velocity);
    } else if (hasNextPage &&
        ((dragProgress.value < -1 / 2 && velocity < 0.2) ||
            (dragProgress.value < 0 && velocity < -0.2))) {
      animatedPaginateToNext(velocity);
    } else {
      if (dragProgress.value > 0) {
        if (hasPreviousPage) {
          animatedPaginateToCurrent(max(velocity, 0));
        } else {
          dragProgress.value = 0;
        }
      } else {
        if (hasNextPage) {
          animatedPaginateToCurrent(min(velocity, 0));
        } else {
          dragProgress.value = 0;
        }
      }
    }

    return true;
  }

  bool consumeHorizontalDragDown(DragDownDetails details) {
    return true;
  }

  bool consumeHorizontalDragCancel() {
    isDragging = false;
    forceFling();
    return true;
  }

  @override
  Widget build(BuildContext context) {
    MediaQuery.of(context).gestureSettings;

    final width = MediaQuery.of(context).size.width;
    final height = MediaQuery.of(context).size.height;

    final top = MediaQuery.of(context).viewPadding.top;
    final bottom = MediaQuery.of(context).viewPadding.bottom;
    final padding = 16.0;

    final pageTransition = CoverReaderPageTransition();

    print('PagesRenderer build');

    return RepaintBoundary(
      child: ClipRect(
        child: Stack(
          clipBehavior: Clip.hardEdge,
          children: List.generate(3, (index) {
            return ValueListenableBuilder<double>(
              key: ValueKey(pages[index].id),
              valueListenable: dragProgress,
              builder: (context, value, child) {
                final transform = pageTransition.calculateTransform(
                  value,
                  1 - index,
                  Size(width, height),
                );

                return Transform(
                  transform: transform,
                  child: Container(
                    decoration: BoxDecoration(
                      color: Theme.of(context).colorScheme.surface,
                      boxShadow: [
                        BoxShadow(
                          color: Colors.black.withValues(alpha: 0.1),
                          offset: Offset(0, 0),
                          blurRadius: 10,
                        ),
                      ],
                    ),
                    child: Stack(
                      key: ValueKey(pages[index].id),
                      children: [
                        Padding(
                          padding: EdgeInsets.only(
                            left: padding,
                            right: padding,
                            top: top + padding,
                            bottom: bottom + padding,
                          ),
                          child: pages[index].page,
                        ),
                        if (!pages[index].ready)
                          Positioned(
                            top: 0,
                            left: 0,
                            right: 0,
                            bottom: 0,
                            child: Container(
                              color: Theme.of(context).colorScheme.surface,
                              child: Center(
                                child: Text('正在加载中...'),
                              ),
                            ),
                          ),
                      ],
                    ),
                  ),
                );
              },
            );
          }).toList(),
        ),
      ),
    );
  }
}
