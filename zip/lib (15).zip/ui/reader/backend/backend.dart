import 'dart:isolate';

import 'package:flutter/services.dart';

import '../../../epub/epub.dart';
import 'assets_service.dart';
import 'epub_service.dart';
import 'interceptor.dart';
import 'server.dart';

class _ServerParams {
  final SendPort sendPort;
  final Openable epubOpenable;
  final String style;
  final String script;

  _ServerParams({
    required this.sendPort,
    required this.epubOpenable,
    required this.style,
    required this.script,
  });
}

class Backend {
  final Openable epubOpenable;

  Isolate? _serverIsolate;
  ReceivePort? _receivePort;
  int? _serverPort;

  bool _interceptorPrepared = false;
  final Interceptor interceptor = Interceptor();

  Backend({
    required this.epubOpenable,
  });

  static Future<void> _startServer(_ServerParams params) async {
    final server = Server();
    final port = await server.startServer();

    final epub = await EpubOpener.open(params.epubOpenable);

    server.registerService(EpubService(
      epub,
      style: params.style,
      script: params.script,
    ));

    params.sendPort.send(port);
  }

  void _prepareInterceptor() {
    interceptor.registerService(AssetsService());
    _interceptorPrepared = true;
  }

  Future<void> start() async {
    final style = await rootBundle.loadString('assets/webview/style.css');
    final script = await rootBundle.loadString('assets/webview/javascript.js');

    _receivePort = ReceivePort();
    _serverIsolate = await Isolate.spawn(
      _startServer,
      _ServerParams(
        sendPort: _receivePort!.sendPort,
        epubOpenable: epubOpenable,
        style: style,
        script: script,
      ),
    );
    _serverPort = await _receivePort!.first as int;

    _prepareInterceptor();
  }

  void stop() {
    _serverIsolate?.kill();
    _receivePort?.close();

    _serverIsolate = null;
    _receivePort = null;
    _serverPort = null;

    _interceptorPrepared = false;
    interceptor.clearServices();
  }

  bool get isReady =>
      _serverIsolate != null &&
      _receivePort != null &&
      _serverPort != null &&
      _interceptorPrepared;

  int get serverPort => _serverPort!;
}
