import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../../epub/epub.dart';
import '../../../global_state/books_state.dart';
import '../../../managers/meta/models.dart';
import '../reader_screen_state.dart';
import 'overlay/panel.dart';
import 'overlay/toc_drawer.dart';
import 'renderer/pages_renderer.dart';

class EpubPlayer extends StatefulWidget {
  const EpubPlayer({
    super.key,
  });

  @override
  State<EpubPlayer> createState() => _EpubPlayerState();
}

class _EpubPlayerState extends State<EpubPlayer> {
  late final PagesRendererController pagesRendererController;
  late final PanelController panelController;
  late final TOCDrawerController tocDrawerController;

  @override
  void initState() {
    super.initState();
    final readerScreenState = context.read<ReaderScreenState>();

    pagesRendererController = PagesRendererController(
      onPageChanged: onPageChanged,
      initialLocation: readerScreenState.initialLocation,
    );
    panelController = PanelController();
    tocDrawerController = TOCDrawerController(
      onNavigate: onNavigate,
    );
  }

  @override
  dispose() {
    super.dispose();

    pagesRendererController.dispose();
    panelController.dispose();
    tocDrawerController.dispose();
  }

  void onNavigate(NavigationPoint point) {
    final readerScreenState = context.read<ReaderScreenState>();

    final contentLocation =
        readerScreenState.navigation.getFirstContentLocation(point.location)!;
    setState(() {
      final initialLocation = PageLocation.firstPageOf(contentLocation);
      pagesRendererController.resetInitialLocation(initialLocation);
      onPageChanged(initialLocation);
    });
  }

  void onPageChanged(PageLocation pageLocation) {
    final readerScreenState = context.read<ReaderScreenState>();

    tocDrawerController.currentLocation = pageLocation;

    final booksState = context.read<BooksState>();
    final bookInfo = booksState.getBookInfo(readerScreenState.relativePath);

    booksState.updateBookInfoTemp(
      bookInfo.copyWith(
        lastReadLocation: pageLocation,
        lastReadTitle: readerScreenState.navigation
            .getPointByLocation(pageLocation.contentLocation.pointLocation)!
            .label,
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final width = MediaQuery.of(context).size.width;
    return Scaffold(
      resizeToAvoidBottomInset: false,
      body: GestureDetector(
        behavior: HitTestBehavior.opaque,
        onTapUp: (details) {
          // 根据区域判断是打开 panel 还是进行翻页
          if (details.localPosition.dx < width / 4) {
            panelController.closePanel();
            pagesRendererController.gestureConsumer.consumeTapUp(details);
          } else if (details.localPosition.dx > width * 3 / 4) {
            panelController.closePanel();
            pagesRendererController.gestureConsumer.consumeTapUp(details);
          } else {
            panelController.togglePanel();
          }
          setState(() {});
        },
        onHorizontalDragStart: (details) {
          panelController.closePanel();
          pagesRendererController.gestureConsumer
              .consumeHorizontalDragStart(details);
          setState(() {});
        },
        onHorizontalDragUpdate: (details) {
          pagesRendererController.gestureConsumer
              .consumeHorizontalDragUpdate(details);
        },
        onHorizontalDragEnd: (details) {
          pagesRendererController.gestureConsumer
              .consumeHorizontalDragEnd(details);
          setState(() {});
        },
        onHorizontalDragCancel: () {
          pagesRendererController.gestureConsumer.consumeHorizontalDragCancel();
          setState(() {});
        },
        onHorizontalDragDown: (details) {
          pagesRendererController.gestureConsumer
              .consumeHorizontalDragDown(details);
        },
        child: Stack(
          children: [
            PagesRenderer(
              key: ValueKey(pagesRendererController.initialLocation),
              controller: pagesRendererController,
            ),
            Panel(controller: panelController),
          ],
        ),
      ),
      drawer: TOCDrawer(controller: tocDrawerController),
      drawerEnableOpenDragGesture: false,
    );
  }
}
