
/// 除去当前页，左右两侧的预加载页数，不能为 0
const kSymmetricPageCount = 2;


