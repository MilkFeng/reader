import 'package:flutter_inappwebview/flutter_inappwebview.dart';

class StyleManager {
  String get css {
    throw UnimplementedError();
  }

  Future<void> apply(InAppWebViewController controller) async {
    controller.evaluateJavascript(
      source: '''window.css('$css');''',
    );
  }
}
