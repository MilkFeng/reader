import 'dart:typed_data';

import '../accessor/epub_archive.dart';
import '../model/bundle/epub_bundle.dart';
import '../model/epub.dart';
import 'openable.dart';

class BytesBundleOpenable extends Openable {
  final EpubBundle bundle;
  final Uint8List bytes;

  BytesBundleOpenable({
    required this.bundle,
    required this.bytes,
  });

  @override
  Future<Epub> open() async {
    final accessor = EpubArchiveAccessor.fromBytes(bytes);
    return bundle.toEpub(accessor);
  }
}
