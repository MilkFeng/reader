import 'package:flutter/material.dart';

class StyleState extends ChangeNotifier {

}