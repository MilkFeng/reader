import 'style_section.dart';

enum StyleSectionType {
  p,
  h1,
  h2,
  h3,
  h4,
  h5,
  h6,
  a,
  span,
}

class Style {
  late final Map<StyleSectionType, StyleSection> _sections;

  Map<StyleSectionType, StyleSection> get sections => _sections;

  Style() {
    _sections = {
      for (final type in StyleSectionType.values)
        type: StyleSection(type.name)
    };
  }

  StyleSection operator [](StyleSectionType type) {
    return _sections[type]!;
  }

  void operator []=(StyleSectionType type, StyleSection section) {
    _sections[type] = section;
  }

  String toCss() {
    final buffer = StringBuffer();
    for (final section in _sections.values) {
      section.writeCss(buffer);
    }
    return buffer.toString();
  }

  void writeCss(StringBuffer buffer) {
    for (final section in _sections.values) {
      section.writeCss(buffer);
    }
  }

  void clear() {
    for (final section in _sections.values) {
      section.clear();
    }
  }

  Style copy() {
    final sections = Style();
    sections._sections.addAll(_sections);
    return sections;
  }

  StyleSection get p => _sections[StyleSectionType.p]!;
  StyleSection get h1 => _sections[StyleSectionType.h1]!;
  StyleSection get h2 => _sections[StyleSectionType.h2]!;
  StyleSection get h3 => _sections[StyleSectionType.h3]!;
  StyleSection get h4 => _sections[StyleSectionType.h4]!;
  StyleSection get h5 => _sections[StyleSectionType.h5]!;
  StyleSection get h6 => _sections[StyleSectionType.h6]!;
  StyleSection get a => _sections[StyleSectionType.a]!;
  StyleSection get span => _sections[StyleSectionType.span]!;
}
