import 'style.dart';

class StyleBundle {
  double? fontSize;

  void applyTo(Style style) {
    _applyFontSizeTo(style, fontSize);
  }

  void _applyFontSizeTo(Style style, double? fontSize) {
    if (fontSize == null) {
      return;
    }
    style.p.fontSize = fontSize;
    style.a.fontSize = fontSize;
    style.span.fontSize = fontSize;
    style.h1.fontSize = fontSize * 2;
    style.h2.fontSize = fontSize * 1.5;
    style.h3.fontSize = fontSize * 1.17;
    style.h4.fontSize = fontSize;
    style.h5.fontSize = fontSize * 0.83;
    style.h6.fontSize = fontSize * 0.67;
  }
}