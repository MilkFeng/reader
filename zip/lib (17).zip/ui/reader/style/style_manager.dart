import 'dart:convert';

import 'package:flutter_inappwebview/flutter_inappwebview.dart';

import '../../style_state.dart';
import 'style.dart';

class StyleManager {
  late final Style _style;
  late final StyleBundle _styleBundle;

  StyleManager({
    StyleBundle? styleBundle,
  }) {
    _style = Style();
    _styleBundle = styleBundle ?? StyleBundle();

    _styleBundle.applyTo(_style);
  }

  String get css => _style.toCss();

  String get cssBase64 {
    return base64Encode(utf8.encode(css));
  }

  Future<void> apply(InAppWebViewController controller) async {
    controller.evaluateJavascript(
      source: '''window.injectCSS('$cssBase64');''',
    );
  }
}
