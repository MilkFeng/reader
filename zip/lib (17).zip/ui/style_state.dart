import 'package:flutter/cupertino.dart';

import '../managers/settings/settings_manager.dart';

class StyleBundle {
  double? fontSize;

  StyleBundle({
    this.fontSize,
  });
}

class StyleState extends ChangeNotifier {
  StyleBundle _styleBundle = StyleBundle();

  final SettingsManager _settingsManager = SettingsManager();

  Future<void> init() async {
    _styleBundle = StyleBundle(
      fontSize: await _settingsManager.getFontSize(),
    );
    notifyListeners();
  }

  Future<void> setStyleBundle(StyleBundle styleBundle) async {
    _styleBundle = styleBundle;
    await _settingsManager.setFontSize(styleBundle.fontSize);
    notifyListeners();
  }

  StyleBundle get styleBundle => _styleBundle;
}
