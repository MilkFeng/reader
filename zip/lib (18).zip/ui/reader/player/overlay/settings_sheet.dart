import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../../style_state.dart';

class SettingsSheet extends StatefulWidget {
  const SettingsSheet({super.key});

  @override
  State<StatefulWidget> createState() => _SettingsSheetState();
}

class _SettingsSheetState extends State<SettingsSheet> {
  Widget _buildSectionTitle(String title) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 16, left: 16, right: 16),
      child: Text(
        title,
        style: Theme.of(context).textTheme.titleMedium?.copyWith(
              color: Theme.of(context).colorScheme.primary,
            ),
      ),
    );
  }

  Widget _buildSectionSliderItem(
    String label,
    String valueLabel, {
    double min = 0,
    double max = 1,
    double value = 0.5,
    int? divisions,
    required Function(double) onChanged,
  }) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 8, left: 16),
      child: Row(
        mainAxisSize: MainAxisSize.max,
        children: [
          Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                label,
                style: Theme.of(context).textTheme.titleMedium,
              ),
              Text(
                valueLabel,
                style: Theme.of(context).textTheme.labelMedium,
              ),
            ],
          ),
          Expanded(
            child: Slider(
              label: valueLabel,
              divisions: divisions,
              value: value,
              min: min,
              max: max,
              onChanged: onChanged,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildSectionSwitchItem(
    String label, {
    String? subLabel,
    bool value = false,
    required Function(bool) onChanged,
  }) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 8, left: 16, right: 16),
      child: Row(
        mainAxisSize: MainAxisSize.max,
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                label,
                style: Theme.of(context).textTheme.titleMedium,
              ),
              if (subLabel != null)
                Text(
                  subLabel,
                  style: Theme.of(context).textTheme.labelMedium,
                ),
            ],
          ),
          Switch(
            value: value,
            onChanged: onChanged,
          ),
        ],
      ),
    );
  }

  Widget _buildSectionItemTitle(String title) {
    return Padding(
      padding: const EdgeInsets.only(left: 16, right: 16, bottom: 8),
      child: Text(
        title,
        style: Theme.of(context).textTheme.titleMedium,
      ),
    );
  }

  Widget _buildDivider() {
    return Divider(
      height: 32,
    );
  }

  @override
  Widget build(BuildContext context) {
    final bottom = MediaQuery.of(context).padding.bottom;

    final styleState = context.watch<StyleState>();

    return ListView(
      padding: EdgeInsets.only(top: 0, bottom: bottom, left: 0, right: 0),
      children: [
        _buildSectionTitle("字体和段落"),
        _buildSectionSwitchItem(
          "使用自定义格式",
          subLabel: "开启后将使用自定义字体即段落格式",
          value: styleState.styleBundle.useCustomStyle,
          onChanged: (value) {
            styleState.setStyleBundle(
              styleState.styleBundle.copyWith(useCustomStyle: value),
            );
          },
        ),

        // 字体大小：10 - 40
        _buildSectionSliderItem(
          "字体大小",
          "${styleState.styleBundle.fontSize.round()}px",
          min: 10,
          max: 40,
          divisions: 40 - 10,
          value: styleState.styleBundle.fontSize,
          onChanged: (value) {
            styleState.setStyleBundle(
              styleState.styleBundle.copyWith(fontSize: value),
            );
          },
        ),
        _buildSectionSliderItem(
          "字间距",
          "16px",
          value: 1,
          onChanged: (value) {},
        ),
        _buildSectionSliderItem(
          "行间距",
          "16px",
          value: 1,
          onChanged: (value) {},
        ),
        _buildSectionSliderItem(
          "段间距",
          "16px",
          value: 1,
          onChanged: (value) {},
        ),
        _buildDivider(),
        _buildSectionTitle("背景和颜色"),
        _buildSectionSwitchItem(
          "使用主题颜色",
          subLabel: "开启后将使用所选主题颜色",
          value: false,
          onChanged: (value) {},
        ),
        Container(
          padding: EdgeInsets.only(left: 16, right: 16, bottom: 8),
          child: Wrap(
            spacing: 8,
            children: [
              ActionChip(
                label: Text("预设 1"),
                // avatar: Icon(Icons.check),
                shape: StadiumBorder(),
                onPressed: () {},
              ),
              ActionChip(
                label: Text("预设 1"),
                // avatar: Icon(Icons.check),
                shape: StadiumBorder(),
                onPressed: () {},
              ),
              ActionChip(
                label: Text("预设 1"),
                // avatar: Icon(Icons.check),
                shape: StadiumBorder(),
                onPressed: () {},
              ),
              ActionChip(
                label: Text("预设 1"),
                avatar: Icon(Icons.check),
                shape: StadiumBorder(),
                onPressed: () {},
              ),
              ActionChip(
                label: Text("预设 1"),
                avatar: Icon(Icons.check),
                shape: StadiumBorder(
                  side: BorderSide(
                    color: Theme.of(context).colorScheme.primary,
                  ),
                ),
                onPressed: () {},
              ),
            ],
          ),
        ),
        Padding(
          padding: EdgeInsets.only(left: 16, right: 16, bottom: 8),
          child: Container(
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(12),
              color: Theme.of(context).colorScheme.surfaceContainer,
            ),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.start,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const SizedBox(height: 8),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Expanded(
                      child: TextField(
                        style: Theme.of(context).textTheme.titleLarge,
                        decoration: InputDecoration(
                          hintText: "命名预设",
                          border: InputBorder.none,
                          contentPadding: EdgeInsets.only(left: 16, right: 16),
                        ),
                      ),
                    ),
                    IconButton(
                      onPressed: () {},
                      icon: Icon(Icons.delete),
                    ),
                    IconButton(
                      onPressed: () {},
                      icon: Icon(Icons.add),
                    ),
                  ],
                ),
                const SizedBox(height: 8),
                _buildSectionItemTitle("背景颜色"),
                _buildSectionSliderItem(
                  "红色",
                  "100",
                  value: 0.5,
                  onChanged: (value) {},
                ),
                _buildSectionSliderItem(
                  "绿色",
                  "100",
                  value: 0.5,
                  onChanged: (value) {},
                ),
                _buildSectionSliderItem(
                  "蓝色",
                  "100",
                  value: 0.5,
                  onChanged: (value) {},
                ),
                const SizedBox(height: 8),
                _buildSectionItemTitle("字体颜色"),
                _buildSectionSliderItem(
                  "红色",
                  "100",
                  value: 0.5,
                  onChanged: (value) {},
                ),
                _buildSectionSliderItem(
                  "绿色",
                  "100",
                  value: 0.5,
                  onChanged: (value) {},
                ),
                _buildSectionSliderItem(
                  "蓝色",
                  "100",
                  value: 0.5,
                  onChanged: (value) {},
                ),
                const SizedBox(height: 8),
              ],
            ),
          ),
        ),
        _buildDivider(),
        _buildSectionTitle("页面"),
        _buildSectionSliderItem(
          "页边距",
          "100",
          value: 0.5,
          onChanged: (value) {},
        ),
      ],
    );
  }
}
