import 'package:flutter/material.dart';
import 'package:flutter_inappwebview/flutter_inappwebview.dart';
import 'package:provider/provider.dart';

import '../../../../epub/epub.dart';
import '../../../../managers/meta/models.dart';
import '../../../style_state.dart';
import 'js_bridge.dart';

class PageReadyDetail {
  PageReadyDetail({
    required this.id,
    required this.pageCount,
  });

  final int id;
  final int pageCount;
}

class PageRendererController extends ChangeNotifier {
  PageRendererController({
    this.pageLocation,
  });

  PageLocation? pageLocation;

  void load(PageLocation? pageLocation) {
    this.pageLocation = pageLocation;
    notifyListeners();
  }
}

class PageRenderer extends StatefulWidget {
  const PageRenderer({
    super.key,
    required this.serverPort,
    required this.navigation,
    required this.onPageReady,
    required this.controller,
    required this.id,
  });

  final int serverPort;
  final Navigation navigation;
  final int id;

  final Function(int, PageReadyDetail) onPageReady;

  final PageRendererController controller;

  @override
  State<StatefulWidget> createState() => PageRendererState();
}

class PageRendererState extends State<PageRenderer> {
  InAppWebViewController? _webViewController;

  String? _currentPageUrl;
  int? _currentPageIndex;

  @override
  void initState() {
    super.initState();

    widget.controller.addListener(() {
      load(widget.controller.pageLocation);
    });

    context.read<StyleState>().addListener(applyStyle);
  }

  @override
  void dispose() {
    context.read<StyleState>().removeListener(applyStyle);
    super.dispose();
  }

  Future<void> applyStyle() async {
    final styleState = context.read<StyleState>();
    await _webViewController?.injectCSS(styleState.style);
  }

  String getUrl(PageLocation pageLocation) {
    final href =
        widget.navigation.getHrefByLocation(pageLocation.contentLocation);
    return "http://localhost:${widget.serverPort}/epub/$href";
  }

  Future<void> load(PageLocation? pageLocation) async {
    if (pageLocation == null) {
      return;
    }

    final url = getUrl(pageLocation);
    final index = pageLocation.pageIndex;

    if (url == _currentPageUrl) {
      if (_currentPageIndex != index) {
        _currentPageIndex = index;
        await _webViewController!.pageTo(index);
        setState(() {});
      }

      widget.onPageReady(
        widget.id,
        PageReadyDetail(
          id: widget.id,
          pageCount: await _webViewController!.pageCount(),
        ),
      );
      return;
    }

    _currentPageUrl = url;
    final urlRequest = URLRequest(url: WebUri.uri(Uri.parse(url)));
    _webViewController?.loadUrl(urlRequest: urlRequest);
  }

  Widget _buildWebView() {
    applyStyle();

    URLRequest? initialUrlRequest;
    if (widget.controller.pageLocation != null) {
      final url = getUrl(widget.controller.pageLocation!);
      _currentPageUrl = url;
      initialUrlRequest = URLRequest(url: WebUri.uri(Uri.parse(url)));
    }

    return InAppWebView(
      key: ValueKey(widget.id),
      initialUrlRequest: initialUrlRequest,
      onWebViewCreated: (controller) {
        _webViewController = controller;
      },
      initialSettings: InAppWebViewSettings(
        disableVerticalScroll: true,
        disableHorizontalScroll: true,
        disallowOverScroll: true,
        supportZoom: false,
        useHybridComposition: false,
        verticalScrollBarEnabled: false,
        horizontalScrollBarEnabled: false,
        transparentBackground: true,
        isInspectable: false,
        supportMultipleWindows: false,
        allowsLinkPreview: false,
        cacheEnabled: true,
        cacheMode: CacheMode.LOAD_CACHE_ELSE_NETWORK,
      ),
      onLoadStop: (controller, url) async {
        if (_currentPageUrl == null ||
            url?.uriValue != Uri.parse(_currentPageUrl!)) {
          return;
        }

        await applyStyle();

        if (widget.controller.pageLocation != null) {
          final index = widget.controller.pageLocation!.pageIndex;
          _currentPageIndex = index;
          await _webViewController!.pageTo(index);
          await Future.delayed(const Duration(milliseconds: 50));
        }

        widget.onPageReady(
          widget.id,
          PageReadyDetail(
            id: widget.id,
            pageCount: await _webViewController!.pageCount(),
          ),
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    return RepaintBoundary(
      key: ValueKey(widget.id),
      child: _buildWebView(),
    );
  }
}
