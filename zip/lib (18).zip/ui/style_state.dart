import 'package:flutter/cupertino.dart';
import 'common/style.dart';

import '../managers/settings/settings_manager.dart';

class StyleBundle {
  bool useCustomStyle;
  double fontSize;

  StyleBundle({
    required this.useCustomStyle,
    required this.fontSize,
  });

  StyleBundle copyWith({
    bool? useCustomStyle,
    double? fontSize,
  }) {
    return StyleBundle(
      useCustomStyle: useCustomStyle ?? this.useCustomStyle,
      fontSize: fontSize ?? this.fontSize,
    );
  }
}

class StyleState extends ChangeNotifier {
  late StyleBundle _styleBundle;
  final Style _style = Style();

  final SettingsManager _settingsManager = SettingsManager();

  Future<void> init() async {
    _styleBundle = StyleBundle(
      useCustomStyle: await _settingsManager.getUseCustomStyle() ?? false,
      fontSize: await _settingsManager.getFontSize() ?? 16,
    );
    _style.clear();
    _styleBundle.applyTo(_style);
    notifyListeners();
  }

  Future<void> setStyleBundle(StyleBundle styleBundle) async {
    _styleBundle = styleBundle;
    _style.clear();
    _styleBundle.applyTo(_style);
    notifyListeners();

    await _settingsManager.setUseCustomStyle(styleBundle.useCustomStyle);
    await _settingsManager.setFontSize(styleBundle.fontSize);
  }

  StyleBundle get styleBundle => _styleBundle;
  Style get style => _style;
}
