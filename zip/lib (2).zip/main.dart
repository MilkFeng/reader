import 'package:flutter/gestures.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import 'global_state/global_state.dart';
import 'ui/app.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  // GestureBinding.instance.resamplingEnabled = true;

  final settingsState = SettingsState();
  await settingsState.init();

  runApp(MultiProvider(
    providers: [
      ChangeNotifierProvider.value(value: settingsState),
      ChangeNotifierProxyProvider<SettingsState, BooksState>(
        create: (_) => BooksState(rootPath: settingsState.rootPath!),
        update: (_, config, oldManager) =>
            BooksState(rootPath: settingsState.rootPath!),
      ),
    ],
    child: const App(),
  ));
}