import 'dart:convert';

import '../../common/fs_utils.dart';
import 'models.dart';

class BookCategoriesDao {
  static const String bookCategoriesFileName = 'book_categories.json';
  static const String bookCategoriesFileMIME = 'application/json';

  final String rootPath;
  final String metaDirRelativePath;

  BookCategoriesDao({
    required this.rootPath,
    required this.metaDirRelativePath,
  });

  String get bookCategoriesFileRelativePath =>
      '$metaDirRelativePath/$bookCategoriesFileName';

  static final defaultBookCategories = [
    BookCategory(id: 0, name: 'Uncategorized'),
  ];


  Future<bool> checkBookCategoriesFileExist() async {
    return await FSUtils.checkFileOrDirExist(
        rootPath, bookCategoriesFileRelativePath);
  }

  Future<List<BookCategory>> getBookCategories() async {
    if (!await checkBookCategoriesFileExist()) {
      return defaultBookCategories;
    }
    final jsonBytes = await FSUtils.readFileBytesFromJoinPath(
        rootPath, bookCategoriesFileRelativePath);
    final jsonStr = utf8.decode(jsonBytes);
    return BookCategory.listFromJson(jsonStr);
  }

  Future<void> saveBookCategories(List<BookCategory> bookCategories) async {
    final jsonStr = BookCategory.listToJson(bookCategories);
    final jsonBytes = utf8.encode(jsonStr);
    await FSUtils.writeToFile(rootPath, metaDirRelativePath, bookCategoriesFileName,
        bookCategoriesFileMIME, jsonBytes);
  }
}
