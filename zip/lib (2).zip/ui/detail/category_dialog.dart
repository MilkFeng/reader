// import 'package:flutter/material.dart';
//
// class CategoryDialog extends StatelessWidget {
//
//   CategoryDialog({this.category});
//
//   @override
//   Widget build(BuildContext context) {
//     return AlertDialog(
//       title: Text('Select a category'),
//       content: Container(
//         width: double.maxFinite,
//         child: ListView.builder(
//           shrinkWrap: true,
//           itemCount: Category.values.length,
//           itemBuilder: (context, index) {
//             final category = Category.values[index];
//             return ListTile(
//               title: Text(category.toString().split('.').last),
//               onTap: () {
//                 onCategorySelected(category);
//                 Navigator.pop(context);
//               },
//             );
//           },
//         ),
//       ),
//     );
//   }
// }