import 'package:animated_flip_counter/animated_flip_counter.dart';
import 'package:flutter/material.dart';

import '../../../managers/managers.dart';
import '../../main/shelf/book_tile.dart';

class ShelfPage extends StatefulWidget {
  ShelfPage({
    super.key,
    required this.books,
    required this.categories,
  }) {
    categoryToBooks = {};
    categoriesMap = {};
    for (final category in categories) {
      categoryToBooks[category.id] = [];
      categoriesMap[category.id] = category;
    }
    for (final book in books) {
      categoryToBooks[book.category]!.add(book);
    }
  }

  static NavigationDestination get destination => NavigationDestination(
        selectedIcon: Icon(Icons.local_library),
        icon: Icon(Icons.local_library_outlined),
        label: '书架',
      );

  final List<ExtendedBookInfo> books;
  final List<BookCategory> categories;

  late final Map<int, List<ExtendedBookInfo>> categoryToBooks;
  late final Map<int, BookCategory> categoriesMap;

  @override
  State<ShelfPage> createState() => _ShelfPageState();
}

class _ShelfPageState extends State<ShelfPage>
    with TickerProviderStateMixin, AutomaticKeepAliveClientMixin {
  Map<String, List<BookInfo>> books = {};
  late TabController tabController;

  @override
  void initState() {
    super.initState();
    tabController = TabController(
      length: widget.categoryToBooks.keys.length,
      vsync: this,
    );
  }

  @override
  void didUpdateWidget(covariant ShelfPage oldWidget) {
    super.didUpdateWidget(oldWidget);

    final oldCategoryCount = oldWidget.categoryToBooks.keys.length;
    final newCategoryCount = widget.categoryToBooks.keys.length;

    if (oldCategoryCount != newCategoryCount) {
      final oldIndex = tabController.index;
      final newIndex = oldIndex.clamp(0, newCategoryCount - 1);
      setState(() {
        tabController = TabController(
          length: newCategoryCount,
          vsync: this,
          initialIndex: newIndex,
        );
      });
    }
  }

  void _showDetailBottomSheet(
      BuildContext context, ExtendedBookInfo bookInfo) async {
    Navigator.of(context).pushNamed(
      '/detail',
      arguments: bookInfo.relativePath,
    );
  }

  @override
  Widget build(BuildContext context) {
    super.build(context);
    final tabHeight = 46.0;
    return Scaffold(
      appBar: AppBar(
        title: Row(
          children: [
            Text('书架 '),
            AnimatedFlipCounter(value: widget.books.length),
          ],
        ),
        actions: [
          IconButton(icon: Icon(Icons.more_vert), onPressed: () {}),
        ],
        bottom: TabBar(
          controller: tabController,
          isScrollable: true,
          tabAlignment: TabAlignment.start,
          tabs: widget.categoryToBooks.keys
              .map((e) => SizedBox(
                    height: tabHeight,
                    child: Row(
                      children: [
                        Text('${widget.categoriesMap[e]?.name} '),
                        AnimatedFlipCounter(
                            value: widget.categoryToBooks[e]!.length),
                      ],
                    ),
                  ))
              .toList(),
        ),
      ),
      body: TabBarView(
        controller: tabController,
        physics: const NeverScrollableScrollPhysics(),
        children: widget.categoryToBooks.keys.map((category) {
          final books = widget.categoryToBooks[category]!;
          return ListView.builder(
            itemCount: books.length,
            itemBuilder: (context, index) {
              return BookTile(
                book: books[index],
                onRead: (bookInfo) {
                  Navigator.of(context).pushNamed(
                    '/reader',
                    arguments: bookInfo.relativePath,
                  );
                },
                onDetail: (bookInfo) {
                  _showDetailBottomSheet(context, bookInfo);
                },
              );
            },
          );
        }).toList(),
      ),
    );
  }

  @override
  bool get wantKeepAlive => true;
}
