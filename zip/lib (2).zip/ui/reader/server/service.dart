import 'dart:typed_data';

abstract class Service {
  String get part;
  Future<Uint8List> request(String path);
}