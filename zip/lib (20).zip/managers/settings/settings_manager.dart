import 'prefs.dart';

class SettingsManager {
  // ===========================================================
  static const String rootPathKey = 'root_path';
  static const String isInitializedKey = 'is_initialized';

  Future<String?> getRootPath() async {
    return await Prefs.get<String>(rootPathKey);
  }

  Future<void> setRootPath(String? path) async {
    await Prefs.set(rootPathKey, path);
  }

  Future<bool?> getInitialized() async {
    return await Prefs.get<bool>(isInitializedKey);
  }

  Future<void> setIsInitialized(bool value) async {
    await Prefs.set(isInitializedKey, value);
  }

  // ===========================================================
  static const String useCustomStyleKey = 'use_custom_style';
  static const String fontSizeKey = 'font_size';
  static const String letterSpacingKey = 'letter_spacing';

  Future<bool?> getUseCustomStyle() async {
    return await Prefs.get<bool>(useCustomStyleKey);
  }

  Future<void> setUseCustomStyle(bool value) async {
    await Prefs.set(useCustomStyleKey, value);
  }

  Future<double?> getFontSize() async {
    return await Prefs.get<double>(fontSizeKey);
  }

  Future<void> setFontSize(double value) async {
    await Prefs.set(fontSizeKey, value);
  }

  Future<double?> getLetterSpacing() async {
    return await Prefs.get<double>(letterSpacingKey);
  }

  Future<void> setLetterSpacing(double value) async {
    await Prefs.set(letterSpacingKey, value);
  }

// ===========================================================
}
