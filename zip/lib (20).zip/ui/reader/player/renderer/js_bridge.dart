import 'dart:convert';

import 'package:flutter_inappwebview/flutter_inappwebview.dart';
import 'style/style.dart';

extension JsBridge on InAppWebViewController {
  Future<int> pageTo(int index) async {
    return await evaluateJavascript(
      source: 'window.pageTo($index)',
    ) as int;
  }

  Future<int> pageCount() async {
    return await evaluateJavascript(
      source: 'window.pageCount()',
    ) as int;
  }

  Future<void> injectCSS(Style style) async {
    final css = style.toCss();
    final cssBase64 = base64Encode(utf8.encode(css));
    await evaluateJavascript(
      source: 'window.injectCSS("$cssBase64")',
    );
  }
}
