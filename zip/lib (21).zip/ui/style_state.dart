import 'package:flutter/cupertino.dart';
import 'package:quiver/core.dart';
import 'reader/player/renderer/style/style.dart';

import '../managers/settings/settings_manager.dart';

class StyleBundle {
  bool useCustomStyle;
  double fontSize;
  double letterSpacing;

  StyleBundle({
    required this.useCustomStyle,
    required this.fontSize,
    required this.letterSpacing,
  });

  StyleBundle copyWith({
    bool? useCustomStyle,
    double? fontSize,
    double? letterSpacing,
  }) {
    return StyleBundle(
      useCustomStyle: useCustomStyle ?? this.useCustomStyle,
      fontSize: fontSize ?? this.fontSize,
      letterSpacing: letterSpacing ?? this.letterSpacing,
    );
  }

  @override
  bool operator ==(Object other) {
    if (identical(this, other)) return true;

    return other is StyleBundle &&
      other.useCustomStyle == useCustomStyle &&
      other.fontSize == fontSize &&
      other.letterSpacing == letterSpacing;
  }

  @override
  // TODO: implement hashCode
  int get hashCode => hash3(useCustomStyle, fontSize, letterSpacing);

}

class StyleState extends ChangeNotifier {
  late StyleBundle _styleBundle;
  final Style _style = Style();

  final SettingsManager _settingsManager = SettingsManager();

  Future<void> init() async {
    _styleBundle = StyleBundle(
      useCustomStyle: await _settingsManager.getUseCustomStyle() ?? false,
      fontSize: await _settingsManager.getFontSize() ?? 16,
      letterSpacing: await _settingsManager.getLetterSpacing() ?? -100000000,
    );
    _style.clear();
    _styleBundle.applyTo(_style);
    notifyListeners();
  }

  Future<void> setStyleBundle(StyleBundle styleBundle) async {
    if (styleBundle == _styleBundle) {
      return;
    }

    _styleBundle = styleBundle;
    _style.clear();
    _styleBundle.applyTo(_style);
    notifyListeners();

    await _settingsManager.setUseCustomStyle(styleBundle.useCustomStyle);
    await _settingsManager.setFontSize(styleBundle.fontSize);
    await _settingsManager.setLetterSpacing(styleBundle.letterSpacing);
  }

  StyleBundle get styleBundle => _styleBundle;
  Style get style => _style;
}
