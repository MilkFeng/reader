import 'dart:convert';

import 'package:flutter_inappwebview/flutter_inappwebview.dart';
import '../style/style.dart';

class ViewPortInfo {
  final double pageWidth;
  final double scrollWidth;
  final int pageCount;

  ViewPortInfo({
    required this.pageWidth,
    required this.scrollWidth,
    required this.pageCount,
  });

  @override
  String toString() {
    return 'ViewPortInfo(pageWidth: $pageWidth, scrollWidth: $scrollWidth, pageCount: $pageCount)';
  }
}

class PageInfo {
  final int pageIndex;
  final String firstVisibleElementPath;

  PageInfo({
    required this.pageIndex,
    required this.firstVisibleElementPath,
  });

  @override
  String toString() {
    return 'PageInfo(pageIndex: $pageIndex, firstVisibleElementPath: $firstVisibleElementPath)';
  }
}

extension JsBridge on InAppWebViewController {
  Future<void> paginateTo(int index) async {
    await evaluateJavascript(
      source: 'window.api.paginateTo($index)',
    );
  }

  ViewPortInfo _toViewPortInfo(dynamic result) {
    return ViewPortInfo(
      pageWidth: result['pageWidth'] as double,
      scrollWidth: result['scrollWidth'] as double,
      pageCount: result['pageCount'] as int,
    );
  }

  PageInfo _toPageInfo(dynamic result) {
    return PageInfo(
      pageIndex: result['pageIndex'] as int,
      firstVisibleElementPath: result['firstVisibleElementPath'] as String,
    );
  }

  Future<ViewPortInfo> getViewPortInfo() async {
    final result = await evaluateJavascript(
      source: 'window.api.getViewPortInfo()',
    ) as Map<String, dynamic>;
    return _toViewPortInfo(result);
  }

  Future<PageInfo> getPageInfo() async {
    final result = await evaluateJavascript(
      source: 'window.api.getPageInfo()',
    ) as Map<String, dynamic>;
    return _toPageInfo(result);
  }

  Future<int> pageCount() async {
    final viewPortInfo = await getViewPortInfo();
    return viewPortInfo.pageCount;
  }

  Future<void> injectCSS(Style? style) async {
    final css = style?.toCss() ?? '';
    final cssBase64 = base64Encode(utf8.encode(css));
    await evaluateJavascript(
      source: 'window.api.injectCss("$cssBase64")',
    );
  }

  void addOnViewPortInfoChangedHandler(void Function(ViewPortInfo) handler) {
    addJavaScriptHandler(
      handlerName: 'onViewPortInfoChanged',
      callback: (args) {
        handler(_toViewPortInfo(args.first));
      },
    );
  }
}
