import 'package:flutter/material.dart';
import 'package:flutter_inappwebview/flutter_inappwebview.dart';

import '../../../../epub/epub.dart';
import '../../../../managers/meta/models.dart';
import '../style/style.dart';
import 'js_bridge.dart';

class PageReadyDetail {
  PageReadyDetail({
    required this.id,
    required this.pageCount,
  });

  final int id;
  final int pageCount;
}

class PageRendererController extends ChangeNotifier {
  PageRendererController({
    this.pageLocation,
    this.style,
  });

  PageLocation? pageLocation;
  Style? style;

  void load(
    PageLocation? pageLocation, {
    Style? style,
  }) {
    this.pageLocation = pageLocation;
    this.style = style;
    notifyListeners();
  }
}

class PageRenderer extends StatefulWidget {
  const PageRenderer({
    super.key,
    required this.serverPort,
    required this.navigation,
    required this.onPageReady,
    required this.controller,
    required this.id,
  });

  final int serverPort;
  final Navigation navigation;
  final int id;

  final Function(int, PageReadyDetail) onPageReady;

  final PageRendererController controller;

  @override
  State<StatefulWidget> createState() => PageRendererState();
}

class PageRendererState extends State<PageRenderer> {
  InAppWebViewController? _webViewController;

  String? _currentPageUrl;

  PageRendererController get controller => widget.controller;

  @override
  void initState() {
    super.initState();

    controller.addListener(load);
  }

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
  }

  @override
  void dispose() {
    super.dispose();
  }

  Future<void> applyStyle() async {
    print('Applying style: ${controller.style?.toCss()}');
    await _webViewController?.injectCSS(controller.style);
  }

  String getUrl(PageLocation pageLocation) {
    final href =
        widget.navigation.getHrefByLocation(pageLocation.contentLocation);
    return "http://localhost:${widget.serverPort}/epub/$href";
  }

  Future<void> load() async {
    if (controller.pageLocation == null) return;
    final url = getUrl(controller.pageLocation!);

    if (url == _currentPageUrl) {
      await scrollToPage();
      await applyStyle();

      final viewPortInfo = await _webViewController!.getViewPortInfo();
      widget.onPageReady(
        widget.id,
        PageReadyDetail(
          id: widget.id,
          pageCount: viewPortInfo.pageCount,
        ),
      );
    } else {
      _currentPageUrl = url;
      final urlRequest = URLRequest(url: WebUri.uri(Uri.parse(url)));
      _webViewController?.loadUrl(urlRequest: urlRequest);
    }
  }

  Future<void> scrollToPage() async {
    if (widget.controller.pageLocation != null) {
      final index = widget.controller.pageLocation!.pageIndex;
      await _webViewController!.paginateTo(index);
    }
  }

  Widget _buildWebView() {
    URLRequest? initialUrlRequest;
    if (widget.controller.pageLocation != null) {
      final url = getUrl(widget.controller.pageLocation!);
      _currentPageUrl = url;
      initialUrlRequest = URLRequest(url: WebUri.uri(Uri.parse(url)));
    }

    return InAppWebView(
      key: ValueKey(widget.id),
      initialUrlRequest: initialUrlRequest,
      onWebViewCreated: (controller) {
        _webViewController = controller;

        controller.addOnViewPortInfoChangedHandler((viewPortInfo) async {
          await scrollToPage();

          widget.onPageReady(
            widget.id,
            PageReadyDetail(
              id: widget.id,
              pageCount: viewPortInfo.pageCount,
            ),
          );
        });
      },
      initialSettings: InAppWebViewSettings(
        disableVerticalScroll: true,
        disableHorizontalScroll: true,
        disallowOverScroll: true,
        supportZoom: false,
        useHybridComposition: false,
        verticalScrollBarEnabled: false,
        horizontalScrollBarEnabled: false,
        transparentBackground: true,
        isInspectable: false,
        supportMultipleWindows: false,
        allowsLinkPreview: false,
        cacheEnabled: true,
        cacheMode: CacheMode.LOAD_CACHE_ELSE_NETWORK,
      ),
      onLoadStop: (controller, url) async {
        await applyStyle();
        print('onLoadStop: ${(await controller.getHtml())?.substring(11200)}');
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    return RepaintBoundary(
      key: ValueKey(widget.id),
      child: _buildWebView(),
    );
  }
}
