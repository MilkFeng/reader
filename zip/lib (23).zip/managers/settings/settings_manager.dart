import 'style_bundle.dart';

import 'prefs.dart';

class SettingsManager {
  // ===========================================================
  static const String rootPathKey = 'root_path';
  static const String isInitializedKey = 'is_initialized';

  Future<String?> getRootPath() async {
    return await Prefs.get<String>(rootPathKey);
  }

  Future<void> setRootPath(String? path) async {
    await Prefs.set(rootPathKey, path);
  }

  Future<bool?> getInitialized() async {
    return await Prefs.get<bool>(isInitializedKey);
  }

  Future<void> setIsInitialized(bool value) async {
    await Prefs.set(isInitializedKey, value);
  }

  // ===========================================================
  static const String useCustomStyleKey = 'use_custom_style';
  static const String fontSizeKey = 'font_size';
  static const String letterSpacingKey = 'letter_spacing';
  static const String letterSpacingNormalKey = 'letter_spacing_normal';

  Future<bool?> getUseCustomStyle() async {
    return await Prefs.get<bool>(useCustomStyleKey);
  }

  Future<void> setUseCustomStyle(bool value) async {
    await Prefs.set(useCustomStyleKey, value);
  }

  Future<double?> getFontSize() async {
    return await Prefs.get<double>(fontSizeKey);
  }

  Future<void> setFontSize(double value) async {
    await Prefs.set(fontSizeKey, value);
  }

  Future<double?> getLetterSpacing() async {
    return await Prefs.get<double>(letterSpacingKey);
  }

  Future<void> setLetterSpacing(double value) async {
    await Prefs.set(letterSpacingKey, value);
  }

  Future<void> setLetterSpacingNormal(bool value) async {
    await Prefs.set(letterSpacingKey, value);
  }

  Future<bool?> getLetterSpacingNormal() async {
    return await Prefs.get<bool>(letterSpacingNormalKey);
  }

  Future<StyleBundle?> getStyleBundle() async {
    final useCustomStyle = await getUseCustomStyle();
    final fontSize = await getFontSize();
    final letterSpacing = await getLetterSpacing();

    if (useCustomStyle == null ||
        fontSize == null ||
        letterSpacing == null) {
      return null;
    }

    return StyleBundle(
      useCustomStyle: useCustomStyle,
      fontSize: fontSize,
      letterSpacing: letterSpacing,
    );
  }

  Future<void> setStyleBundle(StyleBundle styleBundle) async {
    await setUseCustomStyle(styleBundle.useCustomStyle);
    await setFontSize(styleBundle.fontSize);
    await setLetterSpacing(styleBundle.letterSpacing);
  }
}
