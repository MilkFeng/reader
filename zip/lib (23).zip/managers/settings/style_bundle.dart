
import 'package:quiver/core.dart';

class StyleBundle {
  bool useCustomStyle;
  double fontSize;
  double letterSpacing;

  StyleBundle({
    required this.useCustomStyle,
    required this.fontSize,
    required this.letterSpacing,
  });

  StyleBundle copyWith({
    bool? useCustomStyle,
    double? fontSize,
    double? letterSpacing,
  }) {
    return StyleBundle(
      useCustomStyle: useCustomStyle ?? this.useCustomStyle,
      fontSize: fontSize ?? this.fontSize,
      letterSpacing: letterSpacing ?? this.letterSpacing,
    );
  }

  @override
  bool operator ==(Object other) {
    if (identical(this, other)) return true;

    return other is StyleBundle &&
        other.useCustomStyle == useCustomStyle &&
        other.fontSize == fontSize &&
        other.letterSpacing == letterSpacing;
  }

  @override
  int get hashCode => hashObjects([
    useCustomStyle,
    fontSize,
    letterSpacing,
  ]);
}