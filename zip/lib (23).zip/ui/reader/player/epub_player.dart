import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../../epub/epub.dart';
import '../../../managers/meta/models.dart';
import '../../books_state.dart';
import '../../style_state.dart';
import '../reader_screen_state.dart';
import 'overlay/panel.dart';
import 'overlay/toc_drawer.dart';
import 'viewer/epub_viewer.dart';
import 'viewer/epub_viewer_controller.dart';

class EpubPlayer extends StatefulWidget {
  const EpubPlayer({
    super.key,
  });

  @override
  State<EpubPlayer> createState() => _EpubPlayerState();
}

class _EpubPlayerState extends State<EpubPlayer> {
  late final EpubViewerController epubViewerController;
  late final PanelController panelController;
  late final TOCDrawerController tocDrawerController;

  late StyleState? styleState;

  @override
  void initState() {
    super.initState();
    final readerScreenState = context.read<ReaderScreenState>();
    final styleState = context.read<StyleState>();

    epubViewerController = EpubViewerController(
      onPageChanged: onPageChanged,
      initialLocation: readerScreenState.initialLocation,
      style: styleState.style,
    );
    panelController = PanelController();
    tocDrawerController = TOCDrawerController(
      onNavigate: onNavigate,
    );
  }

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();

    styleState = context.read<StyleState>();
    styleState?.removeListener(_handleStyleChange);
    styleState?.addListener(_handleStyleChange);
  }

  @override
  dispose() {
    super.dispose();

    styleState?.removeListener(_handleStyleChange);

    epubViewerController.dispose();
    panelController.dispose();
    tocDrawerController.dispose();

  }

  void _handleStyleChange() {
    epubViewerController.style = styleState?.style;
  }

  void onNavigate(NavigationPoint point) {
    final readerScreenState = context.read<ReaderScreenState>();

    final contentLocation =
        readerScreenState.navigation.getFirstContentLocation(point.location)!;
    setState(() {
      final initialLocation = PageLocation.firstPageOf(contentLocation);
      epubViewerController.resetInitialLocation(initialLocation);
      onPageChanged(initialLocation);
    });
  }

  void onPageChanged(PageLocation pageLocation) {
    final readerScreenState = context.read<ReaderScreenState>();

    tocDrawerController.currentLocation = pageLocation;

    final booksState = context.read<BooksState>();
    final bookInfo = booksState.getBookInfo(readerScreenState.relativePath);

    booksState.updateBookInfoTemp(
      bookInfo.copyWith(
        lastReadLocation: pageLocation,
        lastReadTitle: readerScreenState.navigation
            .getPointByLocation(pageLocation.contentLocation.pointLocation)!
            .label,
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final width = MediaQuery.of(context).size.width;
    return Scaffold(
      resizeToAvoidBottomInset: false,
      body: GestureDetector(
        behavior: HitTestBehavior.opaque,
        onTapUp: (details) {
          // 根据区域判断是打开 panel 还是进行翻页
          if (details.localPosition.dx < width / 4) {
            panelController.closePanel();
            epubViewerController.gestureConsumer.consumeTapUp(details);
          } else if (details.localPosition.dx > width * 3 / 4) {
            panelController.closePanel();
            epubViewerController.gestureConsumer.consumeTapUp(details);
          } else {
            panelController.togglePanel();
          }
          setState(() {});
        },
        onHorizontalDragStart: (details) {
          panelController.closePanel();
          epubViewerController.gestureConsumer
              .consumeHorizontalDragStart(details);
          setState(() {});
        },
        onHorizontalDragUpdate: (details) {
          epubViewerController.gestureConsumer
              .consumeHorizontalDragUpdate(details);
        },
        onHorizontalDragEnd: (details) {
          epubViewerController.gestureConsumer
              .consumeHorizontalDragEnd(details);
          setState(() {});
        },
        onHorizontalDragCancel: () {
          epubViewerController.gestureConsumer.consumeHorizontalDragCancel();
          setState(() {});
        },
        onHorizontalDragDown: (details) {
          epubViewerController.gestureConsumer
              .consumeHorizontalDragDown(details);
        },
        child: Stack(
          children: [
            EpubViewer(
              key: ValueKey(epubViewerController.initialLocation),
              controller: epubViewerController,
            ),
            Panel(controller: panelController),
          ],
        ),
      ),
      drawer: TOCDrawer(controller: tocDrawerController),
      drawerEnableOpenDragGesture: false,
    );
  }
}
