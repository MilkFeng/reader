
import 'package:flutter/material.dart';

import '../../../../managers/meta/models.dart';
import '../common/gesture_consumer.dart';
import '../style/style.dart';
import 'transition/cover_reader_page_transition.dart';
import 'transition/reader_page_transition.dart';

class EpubViewerController extends ChangeNotifier {
  EpubViewerController({
    required this.onPageChanged,
    required PageLocation initialLocation,
    ReaderPageTransition? pageTransition,
    Style? style,
  }) : _initialLocation = initialLocation {
    this.pageTransition = pageTransition ?? CoverReaderPageTransition();
    _style = style ?? Style.empty;
  }

  GestureConsumer _gestureConsumer = GestureConsumer();
  final Function(PageLocation) onPageChanged;
  PageLocation _initialLocation;

  late ReaderPageTransition pageTransition;
  late Style? _style;

  void registerGestureConsumer(GestureConsumer consumer) {
    _gestureConsumer = consumer;
  }

  void resetInitialLocation(PageLocation location) {
    _initialLocation = location;
    notifyListeners();
  }

  PageLocation get initialLocation => _initialLocation;

  GestureConsumer get gestureConsumer => _gestureConsumer;

  Style? get style => _style;

  set style(Style? value) {
    _style = value;
    notifyListeners();
  }
}