import 'package:flutter/cupertino.dart';

import '../managers/settings/settings_manager.dart';
import '../managers/settings/style_bundle.dart';
import 'reader/player/style/style.dart';

final StyleBundle defaultStyleBundle = StyleBundle(
  useCustomStyle: false,
  fontSize: 16,
  letterSpacing: 0,
);

class StyleState extends ChangeNotifier {
  late StyleBundle _styleBundle;
  final Style _style = Style();

  final SettingsManager _settingsManager = SettingsManager();

  Future<void> init() async {
    _styleBundle = await _settingsManager.getStyleBundle() ?? defaultStyleBundle;

    _style.clear();
    _styleBundle.applyTo(_style);
    notifyListeners();
  }

  Future<void> setStyleBundle(StyleBundle styleBundle) async {
    if (styleBundle == _styleBundle) {
      return;
    }

    _styleBundle = styleBundle;
    _style.clear();
    _styleBundle.applyTo(_style);
    notifyListeners();

    await _settingsManager.setStyleBundle(styleBundle);
  }

  StyleBundle get styleBundle => _styleBundle;

  Style get style => _style;
}
