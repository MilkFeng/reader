import 'style_bundle.dart';

class AppStyle {
  double padding;

  AppStyle({
    required this.padding,
  });
}

extension AppStyleApply on StyleBundle {
  void applyToAppStyle(AppStyle style) {
    style.padding = padding;
  }
}
