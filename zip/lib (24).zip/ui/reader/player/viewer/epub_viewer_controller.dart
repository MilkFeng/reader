
import 'package:flutter/material.dart';

import '../../../../managers/meta/models.dart';
import '../../../../managers/settings/models.dart';
import '../common/gesture_consumer.dart';
import 'transition/cover_reader_page_transition.dart';
import 'transition/reader_page_transition.dart';

class EpubViewerController extends ChangeNotifier {
  EpubViewerController({
    required this.onPageChanged,
    required PageLocation initialLocation,
    ReaderPageTransition? pageTransition,
    Stylesheet? style,
    StyleBundle? styleBundle,
  }) : _initialLocation = initialLocation {
    this.pageTransition = pageTransition ?? CoverReaderPageTransition();
    _style = style ?? Stylesheet.empty;
    _styleBundle = styleBundle ?? StyleBundle.defaultStyleBundle;
  }

  GestureConsumer _gestureConsumer = GestureConsumer();
  final Function(PageLocation) onPageChanged;
  PageLocation _initialLocation;

  late ReaderPageTransition pageTransition;
  late Stylesheet _style;
  late StyleBundle _styleBundle;

  void registerGestureConsumer(GestureConsumer consumer) {
    _gestureConsumer = consumer;
  }

  void resetInitialLocation(PageLocation location) {
    _initialLocation = location;
    notifyListeners();
  }

  PageLocation get initialLocation => _initialLocation;

  GestureConsumer get gestureConsumer => _gestureConsumer;

  Stylesheet get style => _style;
  StyleBundle get styleBundle => _styleBundle;

  void setStyle(StyleBundle styleBundle, Stylesheet style) {
    _styleBundle = styleBundle;
    _style = style;
    notifyListeners();
  }
}