import 'package:flutter/cupertino.dart';

import '../managers/settings/settings_manager.dart';
import '../managers/settings/models.dart';

class StyleState extends ChangeNotifier {
  late StyleBundle _styleBundle;

  final Stylesheet _style = Stylesheet();
  late final AppStyle _appStyle;

  final SettingsManager _settingsManager = SettingsManager();

  Future<void> init() async {
    _styleBundle = await _settingsManager.getStyleBundle() ??
        StyleBundle.defaultStyleBundle;

    _style.clear();
    _styleBundle.applyToStyleSheet(_style);

    _appStyle = AppStyle(padding: 16);
    _styleBundle.applyToAppStyle(_appStyle);

    notifyListeners();
  }

  Future<void> setStyleBundle(StyleBundle styleBundle) async {
    if (_styleBundle == styleBundle) {
      return;
    }
    _styleBundle = styleBundle;
    _style.clear();

    _styleBundle.applyToStyleSheet(_style);
    _styleBundle.applyToAppStyle(_appStyle);

    notifyListeners();

    await _settingsManager.setStyleBundle(styleBundle);
  }

  StyleBundle get styleBundle => _styleBundle;
  AppStyle get appStyle => _appStyle;
  Stylesheet get style => _style;
}
