import 'dart:typed_data';

import 'package:path/path.dart';

import '../accessor/accessor.dart';
import '../accessor/lazy_file.dart';

class Asset {
  final String id;
  final LazyFile file;

  final String mediaType;
  final List<String> properties;

  Asset({
    required this.id,
    required this.file,
    required this.mediaType,
    required this.properties,
  });

  Future<Uint8List> get bytes => file.bytes;
  Future<bool> get loaded => file.loaded;

  String get name => file.name;
  String get path => file.path;
  String get dirPath => file.dirPath;
  String get extension => file.extension;

  @override
  String toString() {
    return 'Asset{id: $id, file: $file, mediaType: $mediaType, properties: $properties}';
  }
}

class AssetRef {
  final String id;
  final String href;
  final String mediaType;
  final List<String> properties;

  AssetRef({
    required this.id,
    required this.href,
    required this.mediaType,
    required this.properties,
  });

  @override
  String toString() {
    return 'AssetRef{id: $id, href: $href, mediaType: $mediaType, properties: $properties}';
  }
}

class Manifest {
  final Accessor _accessor;

  late final List<(AssetRef, Asset?)> _assetRefs;
  late final Map<String, int> _idToAssetIndex;
  late final Map<String, int> _hrefToAssetIndex;

  late final List<int> _assetIndexWithProperties;

  Manifest(this._accessor, List<AssetRef> assetRefs) {
    _assetRefs = [];
    _idToAssetIndex = {};
    _hrefToAssetIndex = {};
    _assetIndexWithProperties = [];
    for (var assetRef in assetRefs) {
      assetRef = AssetRef(
        id: assetRef.id,
        href: _trimHref(assetRef.href),
        mediaType: assetRef.mediaType,
        properties: assetRef.properties,
      );

      _assetRefs.add((assetRef, null));
      _idToAssetIndex[assetRef.id] = _assetRefs.length - 1;
      _hrefToAssetIndex[assetRef.href] = _assetRefs.length - 1;

      if (assetRef.properties.isNotEmpty) {
        _assetIndexWithProperties.add(_assetRefs.length - 1);
      }
    }
  }

  String _trimHref(String href) {
    return normalize(href.split('#')[0]);
  }

  Future<Asset> accessByAssetIndex(int index) async {
    final assetRef = _assetRefs[index].$1;
    if (_assetRefs[index].$2 == null) {
      final Asset asset = Asset(
        id: assetRef.id,
        file: await _accessor.access(assetRef.href),
        mediaType: assetRef.mediaType,
        properties: assetRef.properties,
      );
      _assetRefs[index] = (assetRef, asset);
    }
    return _assetRefs[index].$2!;
  }

  Future<Asset> accessById(String id) async {
    final index = _idToAssetIndex[id]!;
    return await accessByAssetIndex(index);
  }

  Future<Asset> accessByHref(String href) async {
    final index = _hrefToAssetIndex[href]!;
    return await accessByAssetIndex(index);
  }

  String getHrefById(String id) {
    final index = _idToAssetIndex[id]!;
    return _assetRefs[index].$1.href;
  }

  String getIdByHref(String href) {
    final index = _hrefToAssetIndex[href]!;
    return _assetRefs[index].$1.id;
  }

  String getFirstHrefWithProperty(String properties) {
    return getFirstOrNullHrefWithProperty(properties)!;
  }

  String? getFirstOrNullHrefWithProperty(String property) {
    for (final index in _assetIndexWithProperties) {
      if (_assetRefs[index].$1.properties.contains(property)) {
        return _assetRefs[index].$1.href;
      }
    }
    return null;
  }
}
