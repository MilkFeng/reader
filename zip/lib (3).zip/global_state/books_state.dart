import 'package:collection/collection.dart';
import 'package:flutter/material.dart';
import 'package:reader/epub/epub.dart';
import 'package:reader/managers/managers.dart';

class BooksState extends ChangeNotifier {
  final String rootPath;

  late final MetaManager _metaManager;
  late final EpubManager _epubManager;

  late final Map<String, ExtendedBookInfo> _books;
  late final Map<int, BookCategory> _categories;

  Map<String, ExtendedBookInfo> get books => _books;
  Map<int, BookCategory> get categories => _categories;

  BooksState({required this.rootPath}) {
    _metaManager = MetaManager(rootPath: rootPath);
    _epubManager = EpubManager(rootPath: rootPath);

    _categories = {};
    _books = {};
    update();
  }

  ExtendedBookInfo getBookInfo(String relativePath) {
    return _books[relativePath]!;
  }

  Future<void> update() async {
    _books.clear();
    _books.addAll(await _metaManager.getExtendedBookInfos());

    _categories.clear();
    _categories.addAll(await _metaManager.getBookCategories());

    notifyListeners();
  }

  Future<void> addBookInfo(ExtendedBookInfo bookInfo) async {
    _books[bookInfo.relativePath] = bookInfo;
    _metaManager.saveBookInfos(_books);
    notifyListeners();
  }

  Future<void> addCategory(BookCategory category) async {
    _categories[category.id] = category;
    _metaManager.saveBookCategories(_categories);
    notifyListeners();
  }

  Future<void> removeBookInfo(String relativePath) async {
    _books.remove(relativePath);
    _metaManager.saveBookInfos(_books);
    notifyListeners();
  }

  Future<void> removeCategory(int categoryId) async {
    _categories.remove(categoryId);

    for (final relativePath in _books.keys) {
      final bookInfo = _books[relativePath]!;
      if (bookInfo.categoryId == categoryId) {
        _books[relativePath] = bookInfo.copyWith(categoryId: 0);
      }
    }

    _metaManager.saveBookCategories(_categories);
    _metaManager.saveBookInfos(_books);
    notifyListeners();
  }

  Future<void> updateBookInfo(ExtendedBookInfo bookInfo) async {
    _books[bookInfo.relativePath] = bookInfo;
    _metaManager.saveBookInfos(_books);
    notifyListeners();
  }

  Future<void> updateCategory(BookCategory category) async {
    _categories[category.id] = category;
    _metaManager.saveBookCategories(_categories);
    notifyListeners();
  }

  Future<void> clearBookInfos() async {
    _books.clear();
    await _metaManager.saveBookInfos(_books);
    notifyListeners();
  }

  Future<Epub> openEpub(String relativePath) async {
    return await _epubManager.openEpub(relativePath);
  }

  Future<String?> saveCover(Epub epub, String relativePath) async {
    final coverAsset = await epub.coverAsset;
    if (coverAsset != null) {
      final coverExtension = coverAsset.extension;
      final coverBytes = await coverAsset.bytes;
      return await _metaManager.saveCover(
        relativePath,
        coverExtension,
        coverAsset.mediaType,
        coverBytes,
      );
    }
    return null;
  }

  Future<String?> saveDesc(String relativePath, String description) async {
    return await _metaManager.saveDesc(relativePath, description);
  }

  Future<String?> getCoverPath(String relativePath) async {
    final bookInfo = getBookInfo(relativePath);
    if (bookInfo.coverExtension == null) {
      return null;
    }
    return _metaManager.getCoverRelativePath(
        relativePath, bookInfo.coverExtension!);
  }

  Future<String> getDesc(String relativePath) async {
    return await _metaManager.getDesc(relativePath);
  }

  Future<ExtendedBookInfo> uploadBook(String relativePath) async {
    final epub = await openEpub(relativePath);
    final bookInfo = BookInfo(
      titles: epub.metadata.titles,
      authors: epub.metadata.authors,
      relativePath: relativePath,
      coverExtension: (await epub.coverAsset)?.extension,
      categoryId: 0,
    );

    final coverPath = await saveCover(epub, relativePath);
    final descPath =
        await saveDesc(relativePath, epub.metadata.description ?? '');

    final extendedBookInfo = ExtendedBookInfo(
      coverRelativePath: coverPath,
      descRelativePath: descPath,
      titles: bookInfo.titles,
      authors: bookInfo.authors,
      relativePath: bookInfo.relativePath,
      coverExtension: bookInfo.coverExtension,
      categoryId: bookInfo.categoryId,
    );

    await addBookInfo(extendedBookInfo);
    return extendedBookInfo;
  }

  String? getCategoryName(int category) {
    return _categories[category]?.name;
  }

  int get nextCategoryId {
    return _categories.keys.max + 1;
  }
}
