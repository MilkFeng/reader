import 'dart:convert';

class BookInfo {
  final List<String> titles;
  final List<String> authors;
  final String relativePath;
  final String? coverExtension;
  final int categoryId;

  BookInfo({
    required this.titles,
    required this.authors,
    required this.relativePath,
    required this.coverExtension,
    required this.categoryId,
  });

  factory BookInfo.fromJson(Map<String, dynamic> json) {
    return BookInfo(
      titles:
          (json['titles'] as List<dynamic>).map((e) => e as String).toList(),
      authors:
          (json['authors'] as List<dynamic>).map((e) => e as String).toList(),
      relativePath: json['relative_path'],
      coverExtension: json['cover_extension'],
      categoryId: json['category_id'],
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'titles': titles,
      'authors': authors,
      'relative_path': relativePath,
      'cover_extension': coverExtension,
      'category_id': categoryId,
    };
  }

  static Map<String, BookInfo> mapFromJson(String jsonStr) {
    final Map<String, dynamic> jsonMap = json.decode(jsonStr);
    return jsonMap.map((key, value) => MapEntry(key, BookInfo.fromJson(value)));
  }

  static String mapToJson(Map<String, BookInfo> bookInfos) {
    final Map<String, Map<String, dynamic>> jsonMap =
        bookInfos.map((key, value) => MapEntry(key, value.toJson()));
    return json.encode(jsonMap);
  }

  BookInfo copyWith({
    List<String>? titles,
    List<String>? authors,
    String? relativePath,
    String? coverExtension,
    int? categoryId,
  }) {
    return BookInfo(
      titles: titles ?? this.titles,
      authors: authors ?? this.authors,
      relativePath: relativePath ?? this.relativePath,
      coverExtension: coverExtension ?? this.coverExtension,
      categoryId: categoryId ?? this.categoryId,
    );
  }
}

class ExtendedBookInfo extends BookInfo {
  final String? coverRelativePath;
  final String? descRelativePath;

  ExtendedBookInfo({
    required this.coverRelativePath,
    required this.descRelativePath,
    required super.titles,
    required super.authors,
    required super.relativePath,
    required super.coverExtension,
    required super.categoryId,
  });

  ExtendedBookInfo copyWith({
    String? coverRelativePath,
    String? descRelativePath,
    List<String>? titles,
    List<String>? authors,
    String? relativePath,
    String? coverExtension,
    int? categoryId,
  }) {
    return ExtendedBookInfo(
      coverRelativePath: coverRelativePath ?? this.coverRelativePath,
      descRelativePath: descRelativePath ?? this.descRelativePath,
      titles: titles ?? this.titles,
      authors: authors ?? this.authors,
      relativePath: relativePath ?? this.relativePath,
      coverExtension: coverExtension ?? this.coverExtension,
      categoryId: categoryId ?? this.categoryId,
    );
  }
}

class BookCategory {
  final int id;
  final String name;

  BookCategory({
    required this.id,
    required this.name,
  });

  factory BookCategory.fromJson(Map<String, dynamic> json) {
    return BookCategory(
      id: json['id'],
      name: json['name'],
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'name': name,
    };
  }

  static Map<int, BookCategory> mapFromJson(String jsonStr) {
    final Map<String, dynamic> jsonMap = json.decode(jsonStr);
    return jsonMap.map(
        (key, value) => MapEntry(int.parse(key), BookCategory.fromJson(value)));
  }

  static String mapToJson(Map<int, BookCategory> bookCategories) {
    final Map<String, Map<String, dynamic>> jsonMap = bookCategories
        .map((key, value) => MapEntry(key.toString(), value.toJson()));
    return json.encode(jsonMap);
  }

  BookCategory copyWith({
    int? id,
    String? name,
  }) {
    return BookCategory(
      id: id ?? this.id,
      name: name ?? this.name,
    );
  }
}
