import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:reader/managers/meta/models.dart';

class CategoryAddDialog extends StatefulWidget {
  const CategoryAddDialog({
    super.key,
    required this.newCategoryId,
  });

  final int newCategoryId;

  @override
  State<CategoryAddDialog> createState() => _CategoryEditDialogState();
}

class _CategoryEditDialogState extends State<CategoryAddDialog> {
  late BookCategory category;

  @override
  void initState() {
    super.initState();
    category = BookCategory(id: widget.newCategoryId, name: '');
  }

  @override
  Widget build(BuildContext context) {
    return AlertDialog(
      title: const Text('添加分组'),
      content: Column(
        mainAxisSize: MainAxisSize.min,
        children: <Widget>[
          TextField(
            controller: TextEditingController(text: category.name),
            decoration: const InputDecoration(labelText: '名称'),
            autofocus: true,
            onChanged: (value) {
              category = category.copyWith(name: value);
            },
          ),
        ],
      ),
      actions: <Widget>[
        TextButton(
          onPressed: () {
            Navigator.of(context).pop();
          },
          child: const Text('取消'),
        ),
        TextButton(
          onPressed: () {
            Navigator.of(context).pop(category);
          },
          child: const Text('确定'),
        ),
      ],
    );
  }
}

Future<BookCategory?> showCategoryAddDialog(
  BuildContext context,
  int newCategoryId,
) async {
  return showDialog<BookCategory>(
    context: context,
    builder: (context) {
      return CategoryAddDialog(newCategoryId: newCategoryId);
    },
  );
}
