import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:reader/ui/category/category_add_dialog.dart';

import '../../global_state/global_state.dart';
import 'category_edit_dialog.dart';

class CategoryManageScreen extends StatefulWidget {
  const CategoryManageScreen({super.key});

  @override
  State<CategoryManageScreen> createState() => _CategoryManageScreenState();
}

class _CategoryManageScreenState extends State<CategoryManageScreen> {
  void _showDeleteCategoryDialog(BuildContext context, int categoryId) {
    final booksState = context.read<BooksState>();

    showDialog(
      context: context,
      builder: (context) {
        return AlertDialog(
          title: const Text('删除分组'),
          content: const Text('删除分组后，分组内的书籍将会被移动到默认分组。'),
          actions: <Widget>[
            TextButton(
              onPressed: () {
                Navigator.of(context).pop();
              },
              child: const Text('取消'),
            ),
            FilledButton(
              onPressed: () {
                booksState.removeCategory(categoryId);
                Navigator.of(context).pop();
              },
              child: const Text('确定'),
            ),
          ],
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    final booksState = context.watch<BooksState>();

    return Scaffold(
      appBar: AppBar(
        title: const Text('分组管理'),
        actions: [
          IconButton(
            icon: const Icon(Icons.add),
            onPressed: () async {
              final newCategory = await showCategoryAddDialog(
                  context, booksState.nextCategoryId);
              if (newCategory != null) {
                booksState.addCategory(newCategory);
              }
            },
          ),
        ],
      ),
      body: ReorderableListView(
        children: [
          for (var (index, categoryId) in booksState.categories.keys.indexed)
            Builder(
                key: ValueKey(categoryId),
                builder: (context) {
                  final category = booksState.categories[categoryId]!;
                  final errorColor = Theme.of(context).colorScheme.error;

                  return ListTile(
                    title: Text(category.name),
                    leading: ReorderableDragStartListener(
                      index: index,
                      child: IconButton(
                        onPressed: () {},
                        icon: const Icon(Icons.drag_indicator),
                      ),
                    ),
                    trailing: IconButton(
                      onPressed: () {
                        _showDeleteCategoryDialog(context, category.id);
                      },
                      icon: Icon(Icons.delete, color: errorColor),
                    ),
                    onTap: () async {
                      final newCategory =
                          await showCategoryEditDialog(context, category);
                      if (newCategory != null) {
                        booksState.updateCategory(newCategory);
                      }
                    },
                  );
                })
        ],
        onReorder: (oldIndex, newIndex) {},
      ),
    );
  }
}
