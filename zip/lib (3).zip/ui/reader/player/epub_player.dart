import 'package:flutter/material.dart';

import '../../../epub/model/epub.dart';
import '../../../epub/model/navigation.dart';
import '../server/server.dart';
import 'page_location.dart';
import 'pages_renderer.dart';
import 'panel.dart';
import 'toc_drawer.dart';

class EpubPlayer extends StatefulWidget {
  const EpubPlayer({
    super.key,
    required this.epub,
    required this.server,
  });

  final Epub epub;
  final Server server;

  @override
  State<EpubPlayer> createState() => _EpubPlayerState();
}

class _EpubPlayerState extends State<EpubPlayer> {
  late PageLocation currentLocation;

  late final PagesRendererController pagesRendererController;
  late final PanelController panelController;
  late final TOCDrawerController tocDrawerController;

  late final SnapshotController snapshotController;

  Navigation get navigation => widget.epub.navigation;

  @override
  void initState() {
    super.initState();

    pagesRendererController = PagesRendererController(
      onPageChanged: onPageChanged,
      initialLocation: PageLocation.firstPageOf(navigation.firstLocation),
    );
    panelController = PanelController(
      onOpenDrawer: onOpenDrawer,
    );
    tocDrawerController = TOCDrawerController(
      onNavigate: onNavigate,
    );

    snapshotController = SnapshotController();

    panelController.addListener(() {
      setState(() {});
    });

    currentLocation = pagesRendererController.initialLocation;
  }

  void onNavigate(NavigationPoint point) {
    final contentLocation = navigation.getFirstContentLocation(point.location)!;
    setState(() {
      final initialLocation = PageLocation.firstPageOf(contentLocation);
      pagesRendererController.resetInitialLocation(initialLocation);
      currentLocation = initialLocation;
    });
  }

  void onPageChanged(PageLocation pageLocation) {
    setState(() {
      currentLocation = pageLocation;
    });
  }

  void onOpenDrawer() {
    // tocDrawerController.openDrawer();
  }

  @override
  Widget build(BuildContext context) {
    final width = MediaQuery.of(context).size.width;

    return Scaffold(
      body: GestureDetector(
        onTapUp: (details) {
          // 根据区域判断是打开 panel 还是进行翻页
          if (details.localPosition.dx < width / 3) {
            pagesRendererController.onTapToPrevious();
          } else if (details.localPosition.dx > width / 3 * 2) {
            pagesRendererController.onTapToNext();
          } else {
            panelController.togglePanel();
          }
        },
        onHorizontalDragStart: (details) {
          panelController.closePanel();
          pagesRendererController.onHorizontalDragStart(details);
        },
        onHorizontalDragUpdate: (details) {
          pagesRendererController.onHorizontalDragUpdate(details);
        },
        onHorizontalDragEnd: (details) {
          pagesRendererController.onHorizontalDragEnd(details);
        },
        onHorizontalDragCancel: () {
          pagesRendererController.onHorizontalDragCancel();
        },
        child: Stack(
          children: [
            Stack(
              children: [
                PagesRenderer(
                  server: widget.server,
                  navigation: widget.epub.navigation,
                  controller: pagesRendererController,
                ),
              ],
            ),
            Panel(
              epub: widget.epub,
              controller: panelController,
            ),
          ],
        ),
      ),
      drawer: TOCDrawer(
        epub: widget.epub,
        controller: tocDrawerController,
      ),
      drawerEnableOpenDragGesture: false,
    );
  }
}
