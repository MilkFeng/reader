import 'package:flutter/services.dart';

import 'service.dart';

class AssetService extends Service {
  AssetService();

  @override
  String get part => 'asset';

  @override
  Future<Uint8List> request(String path) async {
    if (path.startsWith('/')) {
      path = path.substring(1);
    }
    final byteData = await rootBundle.load("assets/$path");
    return byteData.buffer.asUint8List();
  }
}
