import 'dart:typed_data';

import 'manifest.dart';
import 'metadata.dart';
import 'navigation.dart';

class Epub {
  final Metadata metadata;
  final Manifest manifest;
  final Navigation navigation;

  Epub({
    required this.metadata,
    required this.manifest,
    required this.navigation,
  });

  Future<Asset> getAssetById(String id) async {
    return await manifest.accessById(id);
  }

  Future<Asset> getAssetByHref(String href) async {
    return await manifest.accessByHref(href);
  }

  Future<Asset?> get coverAsset async {
    final coverHref = metadata.coverHref;
    if (coverHref == null) {
      return null;
    }
    return await getAssetByHref(coverHref);
  }

  Future<Uint8List?> get coverBytes async {
    return await (await coverAsset)?.bytes;
  }
}
