import 'package:flutter/foundation.dart';
import 'package:reader/common/fs_utils.dart';
import 'package:reader/epub/epub.dart';

class EpubManager {
  EpubManager({required this.rootPath});

  final String rootPath;

  Future<Epub> openEpub(String relativePath) async {
    final bytes = await FSUtils.readFileBytesFromJoinPath(rootPath, relativePath);
    return await compute(EpubOpener.openBytes, bytes);
  }
}
