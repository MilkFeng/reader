import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../../epub/model/epub.dart';
import '../../../epub/model/navigation.dart';
import '../../../global_state/books_state.dart';
import '../../../managers/meta/models.dart';
import '../server/server.dart';
import 'pages_renderer.dart';
import 'panel.dart';
import 'toc_drawer.dart';

class EpubPlayer extends StatefulWidget {
  const EpubPlayer({
    super.key,
    required this.epub,
    required this.relativePath,
    required this.server,
    required this.initialLocation,
  });

  final Epub epub;
  final String relativePath;
  final Server server;
  final PageLocation initialLocation;

  @override
  State<EpubPlayer> createState() => _EpubPlayerState();
}

class _EpubPlayerState extends State<EpubPlayer> {
  late final PagesRendererController pagesRendererController;
  late final PanelController panelController;
  late final TOCDrawerController tocDrawerController;

  late final SnapshotController snapshotController;

  Navigation get navigation => widget.epub.navigation;

  @override
  void initState() {
    super.initState();

    pagesRendererController = PagesRendererController(
      onPageChanged: onPageChanged,
      initialLocation: widget.initialLocation,
    );
    panelController = PanelController(
      onOpenDrawer: onOpenDrawer,
    );
    tocDrawerController = TOCDrawerController(
      onNavigate: onNavigate,
      initialLocation: widget.initialLocation,
    );

    snapshotController = SnapshotController();

    panelController.addListener(() {
      setState(() {});
    });
  }

  void onNavigate(NavigationPoint point) {
    final contentLocation = navigation.getFirstContentLocation(point.location)!;
    setState(() {
      final initialLocation = PageLocation.firstPageOf(contentLocation);
      pagesRendererController.resetInitialLocation(initialLocation);
      onPageChanged(initialLocation);
    });
  }

  void onPageChanged(PageLocation pageLocation) {
    tocDrawerController.currentLocation = pageLocation;

    final booksState = context.read<BooksState>();
    final bookInfo = booksState.getBookInfo(widget.relativePath);

    booksState.updateBookInfoTemp(
      bookInfo.copyWith(
        lastReadLocation: pageLocation,
        lastReadTitle: navigation
            .getPointByLocation(pageLocation.contentLocation.pointLocation)!
            .label,
      ),
    );
  }

  void onOpenDrawer() {}

  @override
  Widget build(BuildContext context) {
    final width = MediaQuery.of(context).size.width;

    return Scaffold(
      body: GestureDetector(
        onTapUp: (details) {
          // 根据区域判断是打开 panel 还是进行翻页
          if (details.localPosition.dx < width / 3) {
            pagesRendererController.onTapToPrevious();
          } else if (details.localPosition.dx > width / 3 * 2) {
            pagesRendererController.onTapToNext();
          } else {
            panelController.togglePanel();
          }
        },
        onHorizontalDragStart: (details) {
          panelController.closePanel();
          pagesRendererController.onHorizontalDragStart(details);
        },
        onHorizontalDragUpdate: (details) {
          pagesRendererController.onHorizontalDragUpdate(details);
        },
        onHorizontalDragEnd: (details) {
          pagesRendererController.onHorizontalDragEnd(details);
        },
        onHorizontalDragCancel: () {
          pagesRendererController.onHorizontalDragCancel();
        },
        child: Stack(
          children: [
            Stack(
              children: [
                PagesRenderer(
                  server: widget.server,
                  navigation: widget.epub.navigation,
                  controller: pagesRendererController,
                ),
              ],
            ),
            Panel(
              epub: widget.epub,
              controller: panelController,
            ),
          ],
        ),
      ),
      drawer: TOCDrawer(
        epub: widget.epub,
        controller: tocDrawerController,
      ),
      drawerEnableOpenDragGesture: false,
    );
  }
}
