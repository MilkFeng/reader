import 'dart:typed_data';

import 'package:archive/archive.dart';

import 'accessor/epub_archive.dart';
import 'model/epub.dart';
import 'parsers/epub_parser.dart';

class EpubOpener {
  static Future<Epub> openBytes(Uint8List bytes) async {
    final accessor = EpubArchiveAccessor.fromBytes(bytes);
    return await EpubParser.parse(accessor);
  }

  static Future<Epub> openStream(InputStream stream) async {
    final accessor = EpubArchiveAccessor.fromStream(stream);
    return await EpubParser.parse(accessor);
  }
}
