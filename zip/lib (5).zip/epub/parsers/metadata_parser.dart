import 'package:xml/xml.dart';

import '../model/manifest.dart';
import '../model/metadata.dart';

class MetadataParser {
  static Future<Metadata> parse(XmlElement element, Version version,
      Manifest manifest, String rootPath) async {
    List<String> titles = [];
    List<String> authors = [];

    String? description;
    List<String> subjects = [];

    String? coverId;
    String? coverHref;

    for (var itemElement in element.children.whereType<XmlElement>()) {
      final innerText = itemElement.innerText;
      switch (itemElement.name.local.toLowerCase()) {
        case 'title':
          titles.add(innerText);
          break;
        case 'creator':
          authors.add(innerText);
          break;
        case 'subject':
          subjects.add(innerText);
          break;
        case 'description':
          description = innerText;
          break;
        case 'meta':
          if (version.isVersion2()) {
            if (itemElement.getAttribute('name') == 'cover') {
              coverId = itemElement.getAttribute('content');
            }
          }
          break;
      }
    }

    if (coverId != null) {
      coverHref = manifest.getHrefById(coverId);
    } else {
      coverHref = manifest.getFirstOrNullHrefWithProperty('cover-image');
      if (coverHref != null) {
        coverId = manifest.getIdByHref(coverHref);
      } else {
        coverHref = null;
      }
    }

    return Metadata(
      version: version,
      titles: titles,
      authors: authors,
      description: description,
      subjects: subjects,
      coverHref: coverHref,
    );
  }
}
