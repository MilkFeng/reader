import 'dart:convert';
import 'dart:typed_data';

import 'package:crypto/crypto.dart';
import 'package:reader/managers/meta/models.dart';

import '../../common/fs_utils.dart';

class BookCacheDao {
  static const String cacheDirName = 'cache';

  final String rootPath;
  final String metaDirRelativePath;

  BookCacheDao({
    required this.rootPath,
    required this.metaDirRelativePath,
  });

  String get cacheRelativeDirPath => '$metaDirRelativePath/$cacheDirName';

  String getBookDirName(String relativePath) {
    final bytes = utf8.encode(relativePath);
    final md5Digest = md5.convert(bytes);
    return md5Digest.toString();
  }

  String getBookDirRelativePath(String relativePath) {
    return '$cacheRelativeDirPath/${getBookDirName(relativePath)}';
  }

  Future<bool> checkBookDirExist(String relativePath) async {
    final bookDirRelativePath = getBookDirRelativePath(relativePath);
    return await FSUtils.checkFileOrDirExist(rootPath, bookDirRelativePath);
  }

  Future<void> createBookDir(String relativePath) async {
    if (await checkBookDirExist(relativePath)) {
      return;
    }
    final bookDirRelativePath = getBookDirRelativePath(relativePath);
    await FSUtils.createDir(rootPath, bookDirRelativePath);
  }

  String getCoverRelativePath(String relativePath, String extension) {
    final bookDirRelativePath = getBookDirRelativePath(relativePath);
    return '$bookDirRelativePath/cover.$extension';
  }

  String getDescRelativePath(String relativePath) {
    final bookDirRelativePath = getBookDirRelativePath(relativePath);
    return '$bookDirRelativePath/desc.txt';
  }

  ExtendedBookInfo extendBookInfo(BookInfo bookInfo) {
    String? coverRelativePath;
    String? descRelativePath;

    if (bookInfo.coverExtension != null) {
      coverRelativePath =
          getCoverRelativePath(bookInfo.relativePath, bookInfo.coverExtension!);
    }

    descRelativePath = getDescRelativePath(bookInfo.relativePath);

    return ExtendedBookInfo(
      coverRelativePath: coverRelativePath,
      descRelativePath: descRelativePath,
      titles: bookInfo.titles,
      authors: bookInfo.authors,
      relativePath: bookInfo.relativePath,
      coverExtension: bookInfo.coverExtension,
      categoryId: bookInfo.categoryId,
      lastReadTime: bookInfo.lastReadTime,
      lastReadLocation: bookInfo.lastReadLocation,
      lastReadTitle: bookInfo.lastReadTitle,
    );
  }

  Future<String> getDesc(String relativePath) async {
    final bookDirRelativePath = getBookDirRelativePath(relativePath);
    final descPath = '$bookDirRelativePath/desc.txt';
    final descBytes =
        await FSUtils.readFileBytesFromJoinPath(rootPath, descPath);
    return utf8.decode(descBytes);
  }

  Future<String> saveDesc(String relativePath, String desc) async {
    await createBookDir(relativePath);
    final bookDirRelativePath = getBookDirRelativePath(relativePath);
    final descBytes = utf8.encode(desc);
    await FSUtils.writeToFile(
        rootPath, bookDirRelativePath, 'desc.txt', 'text/plain', descBytes);

    return "$bookDirRelativePath/desc.txt";
  }

  Future<String> saveCover(
    String relativePath,
    String extension,
    String mime,
    Uint8List bytes,
  ) async {
    await createBookDir(relativePath);
    final bookDirRelativePath = getBookDirRelativePath(relativePath);
    await FSUtils.writeToFile(
        rootPath, bookDirRelativePath, "cover.$extension", mime, bytes);

    return "$bookDirRelativePath/cover.$extension";
  }
}
