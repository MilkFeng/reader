import 'package:flutter/foundation.dart';

import '../../../epub/epub.dart';
import 'service.dart';

class EpubService extends Service {
  final Epub epub;

  EpubService(this.epub);

  @override
  String get part => 'epub';

  @override
  Future<Uint8List> request(String path) async {
    final asset = await epub.manifest.accessByHref(path);
    return await asset.bytes;
  }
}