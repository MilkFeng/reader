import 'dart:ui';

import 'package:flutter/foundation.dart';
import 'package:flutter/widgets.dart';
import 'package:quiver/core.dart';
import 'package:reader/common/fs_utils.dart';

class CustomImage extends ImageProvider<CustomImage> {
  final String rootPath;
  final String relativePath;
  final double scale;

  const CustomImage(this.rootPath, this.relativePath, {this.scale = 1.0});

  @override
  ImageStreamCompleter loadImage(CustomImage key, ImageDecoderCallback decode) {
    return MultiFrameImageStreamCompleter(
      codec: _loadAsync(key, decode: decode),
      scale: scale,
      debugLabel: relativePath,
      informationCollector: () => <DiagnosticsNode>[
        ErrorDescription('Path: $rootPath, $relativePath'),
      ],
    );
  }

  Future<Codec> _loadAsync(
    CustomImage key, {
    required ImageDecoderCallback decode,
  }) async {
    final bytes =
        await FSUtils.readFileBytesFromJoinPath(rootPath, relativePath);
    return decode(await ImmutableBuffer.fromUint8List(bytes));
  }

  @override
  Future<CustomImage> obtainKey(ImageConfiguration configuration) {
    return SynchronousFuture<CustomImage>(this);
  }

  @override
  bool operator ==(Object other) =>
      other is CustomImage &&
      relativePath == other.relativePath &&
      scale == other.scale;

  @override
  int get hashCode => hash2(relativePath, scale);
}

class CustomImageWidget extends Image {
  const CustomImageWidget({
    super.key,
    required super.image,
    super.frameBuilder,
    super.loadingBuilder,
    super.errorBuilder,
    super.semanticLabel,
    super.excludeFromSemantics,
    super.width,
    super.height,
    super.color,
    super.opacity,
    super.colorBlendMode,
    super.fit,
    super.alignment,
    super.repeat,
    super.centerSlice,
    super.matchTextDirection,
    super.gaplessPlayback,
    super.isAntiAlias,
    super.filterQuality,
  });

  CustomImageWidget.custom(
    String rootPath,
    String path, {
    super.key,
    double scale = 1.0,
    super.frameBuilder,
    super.loadingBuilder,
    super.errorBuilder,
    super.semanticLabel,
    super.excludeFromSemantics,
    super.width,
    super.height,
    super.color,
    super.opacity,
    super.colorBlendMode,
    super.fit,
    super.alignment,
    super.repeat,
    super.centerSlice,
    super.matchTextDirection,
    super.gaplessPlayback,
    super.isAntiAlias,
    super.filterQuality,
    int? cacheWidth,
    int? cacheHeight,
  }) : super(
          image: ResizeImage.resizeIfNeeded(
              cacheWidth, cacheHeight, CustomImage(rootPath, path, scale: scale)),
        );
}
