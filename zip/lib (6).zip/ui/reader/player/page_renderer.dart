import 'package:flutter/material.dart';
import 'package:flutter_inappwebview/flutter_inappwebview.dart';

import '../../../epub/epub.dart';
import '../../../managers/meta/models.dart';
import '../server/server.dart';

class PageReadyDetail {
  PageReadyDetail({
    required this.id,
    required this.pageCount,
  });

  final int id;
  final int pageCount;
}

class PageRendererController extends ChangeNotifier {
  PageRendererController({
    this.pageLocation,
  });

  PageLocation? pageLocation;

  void load(PageLocation? pageLocation) {
    this.pageLocation = pageLocation;
    notifyListeners();
  }
}

class PageRenderer extends StatefulWidget {
  const PageRenderer({
    super.key,
    required this.server,
    required this.navigation,
    required this.onPageReady,
    required this.controller,
    required this.id,
  });

  final Server server;
  final Navigation navigation;
  final int id;

  final Function(int, PageReadyDetail) onPageReady;

  final PageRendererController controller;

  @override
  State<StatefulWidget> createState() => PageRendererState();
}

class PageRendererState extends State<PageRenderer> {
  InAppWebViewController? _webViewController;

  String? _currentPageUrl;
  int? _currentPageIndex;

  @override
  void initState() {
    super.initState();

    widget.controller.addListener(() {
      load(widget.controller.pageLocation);
    });
  }

  String getUrl(PageLocation pageLocation) {
    final href =
        widget.navigation.getHrefByLocation(pageLocation.contentLocation);
    return "http://reader/epub/$href";
  }

  Future<void> load(PageLocation? pageLocation) async {
    if (pageLocation == null) {
      return;
    }

    final url = getUrl(pageLocation);
    final index = pageLocation.pageIndex;

    if (url == _currentPageUrl) {
      _currentPageIndex = index;
      await pageTo(_webViewController!, index);
      await Future.delayed(const Duration(milliseconds: 10));
      widget.onPageReady(
        widget.id,
        PageReadyDetail(
          id: widget.id,
          pageCount: await pageCount(_webViewController!),
        ),
      );
      return;
    }

    _currentPageUrl = url;

    final urlRequest = URLRequest(url: WebUri.uri(Uri.parse(url)));
    _webViewController?.loadUrl(urlRequest: urlRequest);

    setState(() {});
  }

  Future<void> pageTo(InAppWebViewController controller, int index) async {
    await controller.evaluateJavascript(
      source: 'window.pageTo($index)',
    );
  }

  Future<int> pageCount(InAppWebViewController controller) async {
    return await controller.evaluateJavascript(
      source: 'window.pageCount()',
    );
  }

  static const _userAgent =
      "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.3";

  @override
  Widget build(BuildContext context) {
    URLRequest? initialUrlRequest;
    if (widget.controller.pageLocation != null) {
      final url = getUrl(widget.controller.pageLocation!);
      initialUrlRequest = URLRequest(url: WebUri.uri(Uri.parse(url)));
    }

    return InAppWebView(
      initialUrlRequest: initialUrlRequest,
      onWebViewCreated: (controller) {
        _webViewController = controller;
      },
      shouldInterceptRequest: (controller, request) async {
        return await widget.server.handleRequest(request);
      },
      initialSettings: InAppWebViewSettings(
        disableVerticalScroll: true,
        disableHorizontalScroll: true,
        disallowOverScroll: true,
        supportZoom: false,
        useHybridComposition: false,
        verticalScrollBarEnabled: false,
        horizontalScrollBarEnabled: false,
        transparentBackground: true,
        isInspectable: false,
        supportMultipleWindows: false,
        allowsLinkPreview: false,
        userAgent: _userAgent,
      ),
      onLoadStop: (controller, url) async {
        if (widget.controller.pageLocation != null) {
          final index = widget.controller.pageLocation!.pageIndex;
          _currentPageIndex = index;
          await pageTo(controller, index);
          await Future.delayed(const Duration(milliseconds: 10));
          setState(() {});
        }

        widget.onPageReady(
          widget.id,
          PageReadyDetail(
            id: widget.id,
            pageCount: await pageCount(controller),
          ),
        );
      },
    );
  }
}
