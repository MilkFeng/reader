import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../global_state/books_state.dart';
import 'player/epub_player.dart';
import 'reader_screen_state.dart';

class ReaderScreen extends StatefulWidget {
  const ReaderScreen({super.key, required this.relativePath});

  final String relativePath;

  @override
  State<StatefulWidget> createState() => _ReaderScreenState();
}

class _ReaderScreenState extends State<ReaderScreen> {

  BooksState? booksState;

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    booksState = context.read<BooksState>();
  }

  @override
  void dispose() {
    booksState?.save();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return ChangeNotifierProxyProvider<BooksState, ReaderScreenState?>(
      create: (context) => null,
      update: (context, booksState, state) {
        if (state == null) {
          return ReaderScreenState(
            booksState: booksState,
            relativePath: widget.relativePath,
          )..init();
        } else {
          state.booksState = booksState;
          state.relativePath = widget.relativePath;
          return state;
        }
      },
      child: Consumer<ReaderScreenState?>(builder: (context, state, _) {
        if (state == null) {
          return const Scaffold();
        }
        if (state.server == null || state.epub == null || state.initialLocation == null) {
          return const Scaffold(
            body: Center(
              child: Text('正在加载中...'),
            ),
          );
        }

        return Scaffold(
          body: EpubPlayer(
            server: state.server!,
            relativePath: widget.relativePath,
            epub: state.epub!,
            initialLocation: state.initialLocation!,
          ),
        );
      }),
    );
  }
}
