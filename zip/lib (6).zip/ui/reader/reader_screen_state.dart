import 'package:flutter/material.dart';
import 'package:reader/managers/meta/models.dart';

import '../../epub/epub.dart';
import '../../global_state/books_state.dart';
import 'server/asset_service.dart';
import 'server/epub_service.dart';
import 'server/server.dart';

class ReaderScreenState extends ChangeNotifier {
  Server? _server;
  Epub? _epub;
  PageLocation? _initialLocation;

  BooksState booksState;
  String relativePath;

  ReaderScreenState({
    required this.booksState,
    required this.relativePath,
  });

  Future<void> init() async {
    _server = Server();

    _epub = await booksState.openEpub(relativePath);
    _server!.registerService(EpubService(_epub!));
    _server!.registerService(AssetService());

    final bookInfo = booksState.getBookInfo(relativePath);
    _initialLocation = bookInfo.lastReadLocation;

    notifyListeners();
  }

  Server? get server => _server;
  Epub? get epub => _epub;
  PageLocation? get initialLocation => _initialLocation;
}
