import 'dart:convert';
import 'dart:typed_data';

import 'package:html/dom.dart';
import 'package:html/parser.dart';

import '../../../epub/epub.dart';
import 'service.dart';

class EpubService extends Service {
  final Epub epub;
  final Map<String, Uint8List> htmlCache = {};

  EpubService(this.epub);

  @override
  String get part => 'epub';

  @override
  Future<Uint8List> request(String path) async {
    if (htmlCache.containsKey(path)) {
      return htmlCache[path]!;
    }

    final Uint8List bytes;
    final bool isHtml;
    if (epub.manifest.containsHref(path)) {
      final asset = await epub.manifest.accessByHref(path);

      bytes = await asset.bytes;
      isHtml = MIMEUtils.isHTML(asset.mediaType);
    } else {
      final file = await epub.manifest.accessFileOutsideManifest(path);
      if (file == null) {
        throw Exception('File not found: $path');
      }
      bytes = await file.bytes;
      isHtml = MIMEUtils.isHTMLByExtension(file.path);
    }

    if (isHtml) {
      Document html = parse(utf8.decode(bytes));
      html = injectScript(html);
      html = injectStyle(html);
      html = injectMeta(html);

      final htmlBytes = utf8.encode(html.outerHtml);
      htmlCache[path] = htmlBytes;

      return htmlBytes;
    } else {
      return bytes;
    }
  }

  static const String _script = '''
    function clamp(x, l, r) {
      return Math.min(Math.max(x, l), r);
    }
    function pageWidth() {
      return document.body.getBoundingClientRect().width;
    }
    function pageOffset() {
      return window.pageXOffset;
    }
    function scrollWidth() {
      var range = document.createRange()
      range.selectNode(document.body)
      return range.getBoundingClientRect().width;
    }
    function pageCount() {
    console.log(scrollWidth(), pageWidth())
      return Math.round(scrollWidth() / pageWidth());
    }
    function pageTo(index) {
      index = clamp(index, 0, pageCount() - 1);
      window.scrollTo({ left: index * pageWidth(), top: 0, behavior: "instant" });
    }
    function currentPageIndex() {
      return Math.round(pageOffset() / pageWidth());
    }

    window.onresize = function(e) {
      pageTo(currentPageIndex())
    }

    window.pageTo = pageTo;
    window.pageCount = pageCount;
  ''';

  static const String _style = '''
    ::-webkit-scrollbar {
      display: none;
    }
    html {
      height: 100% !important;
      width: 100% !important;
      margin: 0 !important;
      padding: 0 !important;
      background-color: transparent !important;
    }
    body {
      overflow-x: auto !important;
      overflow-y: hidden !important;
      column-width: 100vw !important;
      column-gap: 0 !important;
      height: 100vh !important;
      width: 100vw !important;
      margin: 0 !important;
      padding: 0 !important;
      background-color: transparent !important;
      white-space: normal !important;
    }
    * {
      max-width: 100vw !important;
      max-height: 100vh !important;
    }
  ''';

  Document injectScript(Document html) {
    final script = Element.tag('script');
    script.text = _script;
    html.head!.append(script);
    return html;
  }

  Document injectStyle(Document html) {
    final style = Element.tag('style');
    style.text = _style;
    html.head!.append(style);
    return html;
  }

  Document injectMeta(Document html) {
    final meta = Element.tag('meta');
    meta.attributes['name'] = 'viewport';
    meta.attributes['content'] =
        'width=device-width, height=device-height, user-scalable=no, initial-scale=1.0';
    html.head!.append(meta);
    return html;
  }
}
