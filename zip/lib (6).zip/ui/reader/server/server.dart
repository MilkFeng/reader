import 'package:flutter_inappwebview/flutter_inappwebview.dart';

import 'service.dart';

class Server {
  static const String _customHost = 'reader';

  final Map<String, Service> services = {};

  Future<WebResourceResponse?> handleRequest(WebResourceRequest request) async {
    final uri = request.url;
    if (uri.host != _customHost) {
      return null;
    }

    final segments = uri.pathSegments;
    final part = segments[0];
    final pathWithoutPart = uri.pathSegments.skip(1).join('/');

    try {
      final service = services[part]!;
      final bytes = await service.request(pathWithoutPart);
      return WebResourceResponse(
        statusCode: 200,
        data: bytes.buffer.asUint8List(),
      );
    } catch (e) {
      return WebResourceResponse(
        statusCode: 404,
      );
    }
  }

  void registerService(Service service) {
    services[service.part] = service;
  }
}
