import 'package:flutter/material.dart';

import '../../../epub/epub.dart';

class PanelController extends ChangeNotifier {
  PanelController({
    required this.onOpenDrawer,
  });

  bool showPanel = false;
  Function() onOpenDrawer;

  void togglePanel() {
    showPanel = !showPanel;
    notifyListeners();
  }

  void openPanel() {
    showPanel = true;
    notifyListeners();
  }

  void closePanel() {
    showPanel = false;
    notifyListeners();
  }
}

class Panel extends StatefulWidget {
  const Panel({
    super.key,
    required this.metadata,
    required this.controller,
  });

  final Metadata metadata;
  final PanelController controller;

  @override
  State<Panel> createState() => _PanelState();
}

class _PanelState extends State<Panel> {
  bool showDrawer = false;

  @override
  void initState() {
    super.initState();

    widget.controller.addListener(() {
      setState(() {});
    });
  }

  Metadata get metadata => widget.metadata;

  @override
  Widget build(BuildContext context) {
    final top = MediaQuery.of(context).viewPadding.top;
    final bottom = MediaQuery.of(context).viewPadding.bottom;
    final backgroundColor = Theme.of(context).colorScheme.surfaceContainer;

    final topBarHeight = kToolbarHeight;
    final bottomBarHeight = kBottomNavigationBarHeight + 30;

    return Stack(
      children: [
        Container(color: Colors.transparent),
        Column(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            AnimatedContainer(
              curve: Curves.easeInOut,
              duration: Duration(milliseconds: 300),
              transform: Matrix4.translationValues(0,
                  widget.controller.showPanel ? 0 : -(top + topBarHeight), 0),
              child: AppBar(
                toolbarHeight: topBarHeight,
                title: Text(metadata.titles.first),
                backgroundColor: backgroundColor,
                leading: IconButton(
                  icon: const Icon(Icons.arrow_back),
                  onPressed: () {
                    Navigator.pop(context);
                  },
                ),
                primary: true,
              ),
            ),
            AnimatedContainer(
              curve: Curves.easeInOut,
              duration: Duration(milliseconds: 300),
              transform: Matrix4.translationValues(
                  0,
                  widget.controller.showPanel ? 0 : (bottom + bottomBarHeight),
                  0),
              child: Builder(builder: (context) {
                return Container(
                  height: bottomBarHeight,
                  color: backgroundColor,
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceAround,
                    children: [
                      IconButton(
                        icon: const Icon(Icons.list),
                        onPressed: () {
                          widget.controller.onOpenDrawer();
                          Scaffold.of(context).openDrawer();
                        },
                      ),
                      IconButton(
                        icon: const Icon(Icons.style),
                        onPressed: () {},
                      ),
                      IconButton(
                        icon: const Icon(Icons.settings),
                        onPressed: () {},
                      ),
                      IconButton(
                        icon: const Icon(Icons.more_horiz),
                        onPressed: () {},
                      ),
                    ],
                  ),
                );
              }),
            ),
          ],
        ),
      ],
    );
  }
}
