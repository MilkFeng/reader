import 'dart:convert';
import 'dart:isolate';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import '../../common/fs_utils.dart';
import '../../epub/epub.dart';
import '../../global_state/books_state.dart';
import '../../managers/meta/models.dart';
import 'server/epub_service.dart';
import 'server/server.dart';

class _BackendServerParams {
  final SendPort sendPort;
  final Uint8List epubBytes;
  final String epubBundleJsonString;
  final String style;
  final String script;

  _BackendServerParams({
    required this.sendPort,
    required this.epubBytes,
    required this.epubBundleJsonString,
    required this.style,
    required this.script,
  });
}

class ReaderScreenState extends ChangeNotifier {
  Isolate? _serverIsolate;
  ReceivePort? _receivePort;
  int? _serverPort;

  PageLocation? _initialLocation;
  EpubBundle? _epubBundle;
  ExtendedBookInfo? _bookInfo;
  Navigation? _navigation;
  Metadata? _metadata;

  BooksState booksState;
  String relativePath;

  ReaderScreenState({
    required this.booksState,
    required this.relativePath,
  });

  Future<void> init() async {
    final epubBytes = await booksState.openEpubBytes(relativePath);
    _bookInfo = booksState.getBookInfo(relativePath);

    final epubBundleBytes = await FSUtils.readFileBytesFromJoinPath(
        booksState.rootPath, _bookInfo!.epubBundleRelativePath);
    final epubBundleJsonString = utf8.decode(epubBundleBytes);

    final style = await rootBundle.loadString('assets/webview/style.css');
    final script = await rootBundle.loadString('assets/webview/javascript.js');

    _receivePort = ReceivePort();
    _serverIsolate = await Isolate.spawn<_BackendServerParams>(
      _startBackendServer,
      _BackendServerParams(
        sendPort: _receivePort!.sendPort,
        epubBytes: epubBytes,
        epubBundleJsonString: epubBundleJsonString,
        style: style,
        script: script,
      ),
    );
    _serverPort = await _receivePort!.first as int;

    _epubBundle = EpubBundle.fromJson(jsonDecode(epubBundleJsonString));
    _metadata = _epubBundle!.metadata.toMetadata();
    _navigation = _epubBundle!.navigation.toNavigation();

    _initialLocation = _bookInfo!.lastReadLocation;

    notifyListeners();
  }

  @override
  void dispose() {
    super.dispose();

    booksState.save();

    _serverIsolate?.kill();
    _serverIsolate = null;
  }

  static Future<void> _startBackendServer(_BackendServerParams params) async {
    final server = Server();
    final port = await server.startServer();

    params.sendPort.send(port);

    final epubBundle =
        EpubBundle.fromJson(jsonDecode(params.epubBundleJsonString));
    final epub =
        await EpubOpener.openBytesWithBundle(params.epubBytes, epubBundle);

    server.registerService(
        EpubService(epub, style: params.style, script: params.script));
  }

  bool isReady() {
    return _serverPort != null &&
        _epubBundle != null &&
        _bookInfo != null &&
        _navigation != null &&
        _metadata != null &&
        _initialLocation != null;
  }

  int get serverPort => _serverPort!;
  EpubBundle get epubBundle => _epubBundle!;
  Navigation get navigation => _navigation!;
  Metadata get metadata => _metadata!;
  ExtendedBookInfo get bookInfo => _bookInfo!;
  PageLocation get initialLocation => _initialLocation!;
}
