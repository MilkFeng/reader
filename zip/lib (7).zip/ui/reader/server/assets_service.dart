import 'package:flutter/services.dart';
import 'package:flutter_inappwebview/flutter_inappwebview.dart';
import '../../../epub/epub.dart';

import 'service.dart';

class AssetsService extends Service {
  AssetsService();

  final Map<String, (Uint8List, String)> cache = {};

  @override
  String get part => 'assets';

  @override
  Future<WebResourceResponse> request(String path, WebUri fullUrl) async {
    if (path.startsWith('/')) {
      path = path.substring(1);
    }

    if (cache.containsKey(path)) {
      final bytes = cache[path]!.$1;
      final mimeType = cache[path]!.$2;
      return WebResourceResponse(
        statusCode: 200,
        data: bytes,
        contentType: mimeType,
      );
    }

    final byteData = await rootBundle.load("assets/$path");
    final bytes = byteData.buffer.asUint8List();
    final mimeType = MIMEUtils.gaussMIMEFromName(path);
    cache[path] = (bytes, mimeType);
    return WebResourceResponse(
      statusCode: 200,
      data: bytes,
      contentType: mimeType,
    );
  }
}
