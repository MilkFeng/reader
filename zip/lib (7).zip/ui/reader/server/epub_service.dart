import 'dart:convert';
import 'dart:typed_data';

import 'package:flutter_inappwebview/flutter_inappwebview.dart';
import 'package:html/dom.dart';
import 'package:html/parser.dart';

import '../../../epub/epub.dart';
import 'service.dart';

class EpubService extends Service {
  final Epub epub;

  final String style;
  final String script;

  final Map<String, Uint8List> htmlCache = {};

  EpubService(this.epub, {required this.style, required this.script});

  @override
  String get part => 'epub';

  @override
  Future<WebResourceResponse> request(String path, WebUri fullUrl) async {
    if (htmlCache.containsKey(path)) {
      return WebResourceResponse(
        statusCode: 200,
        data: htmlCache[path]!,
        contentType: 'text/html',
      );
    }

    final Uint8List bytes;
    final bool isHtml;
    final String mime;
    if (epub.manifest.containsHref(path)) {
      final asset = await epub.manifest.accessByHref(path);

      bytes = await asset.bytes;
      mime = asset.mediaType;
      isHtml = MIMEUtils.isHTML(asset.mediaType);
    } else {
      final file = await epub.manifest.accessFileOutsideManifest(path);
      if (file == null) {
        throw Exception('File not found: $path');
      }
      bytes = await file.bytes;
      mime = MIMEUtils.gaussMIMEFromName(file.path);
      isHtml = MIMEUtils.isHTMLByExtension(file.path);
    }

    if (isHtml) {
      Document html = parse(utf8.decode(bytes));

      // final jsUrl = "http://reader/assets/webview/javascript.js";
      // final cssUrl = "http://reader/assets/webview/style.css";

      html = injectScript(html);
      html = injectStyle(html);
      html = injectMeta(html);

      final htmlBytes = utf8.encode(html.outerHtml);
      htmlCache[path] = htmlBytes;

      return WebResourceResponse(
        statusCode: 200,
        data: htmlBytes,
        contentType: MIMEUtils.html,
      );
    } else {
      return WebResourceResponse(
        statusCode: 200,
        data: bytes,
        contentType: mime,
      );
    }
  }

  static const String _scriptId = "___epub_script";
  static const String _styleId = "___epub_style";

  Document injectScript(Document html) {
    final script = Element.tag('script');
    script.id = _scriptId;
    script.text = this.script;
    html.head!.append(script);
    return html;
  }

  Document injectStyle(Document html) {
    // final style = Element.tag('link');
    // style.id = _styleId;
    // style.attributes['rel'] = 'stylesheet';
    // style.attributes['type'] = 'text/css';
    // style.attributes['href'] = cssUrl;
    final style = Element.tag('style');
    style.id = _styleId;
    style.text = this.style;
    html.head!.append(style);
    return html;
  }

  Document injectMeta(Document html) {
    final meta = Element.tag('meta');
    meta.attributes['name'] = 'viewport';
    meta.attributes['content'] =
        'width=device-width, height=device-height, user-scalable=no, initial-scale=1.0';
    html.head!.append(meta);
    return html;
  }
}
