import 'dart:convert';
import 'dart:io';

import 'package:flutter_inappwebview/flutter_inappwebview.dart';

import 'service.dart';

class Server {
  final Map<String, Service> services = {};

  HttpServer? _server;

  Future<WebResourceResponse> handleRequest(WebResourceRequest request) async {
    final uri = request.url;

    final segments = uri.pathSegments;
    final part = segments[0];
    final pathWithoutPart = uri.pathSegments.skip(1).join('/');

    try {
      final service = services[part]!;
      return await service.request(pathWithoutPart, uri);
    } catch (e) {
      return WebResourceResponse(
        statusCode: 404,
      );
    }
  }

  void registerService(Service service) {
    services[service.part] = service;
  }

  Future<int> startServer() async {
    _server = await HttpServer.bind(InternetAddress.loopbackIPv4, 0);
    _server!.listen((request) async {
      final response = await handleRequest(WebResourceRequest(
        url: WebUri.uri(request.requestedUri),
      ));

      if (response.statusCode != null) {
        request.response.statusCode = response.statusCode!;
      }

      if (response.reasonPhrase != null) {
        request.response.reasonPhrase = response.reasonPhrase!;
      }

      if (response.contentType != null && response.contentType!.isNotEmpty) {
        request.response.headers.contentType =
            ContentType.parse(response.contentType!);
      } else {
        request.response.headers.contentType = ContentType.binary;
      }

      response.headers?.forEach((key, value) {
        request.response.headers.set(key, value);
      });

      if (response.data != null) {
        request.response.add(response.data!.toList());
      }

      request.response.close();
    });

    return _server!.port;
  }

  void stopServer() {
    _server?.close();
  }
}
