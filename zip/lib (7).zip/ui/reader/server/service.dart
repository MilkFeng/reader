import 'package:flutter_inappwebview/flutter_inappwebview.dart';

abstract class Service {
  String get part;
  Future<WebResourceResponse> request(String path, WebUri fullUrl);
}