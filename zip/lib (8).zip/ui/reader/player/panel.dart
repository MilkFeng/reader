import 'package:flutter/material.dart';

import '../../../epub/epub.dart';

class PanelController extends ChangeNotifier {
  PanelController({
    required this.onOpenDrawer,
  });

  bool showPanel = false;
  Function() onOpenDrawer;

  void togglePanel() {
    showPanel = !showPanel;
    notifyListeners();
  }

  void openPanel() {
    if (!showPanel) {
      showPanel = true;
      notifyListeners();
    }
  }

  void closePanel() {
    if (showPanel) {
      showPanel = false;
      notifyListeners();
    }
  }
}

class Panel extends StatefulWidget {
  const Panel({
    super.key,
    required this.metadata,
    required this.controller,
  });

  final Metadata metadata;
  final PanelController controller;

  @override
  State<Panel> createState() => _PanelState();
}

class _PanelState extends State<Panel> {
  bool showDrawer = false;

  @override
  void initState() {
    super.initState();

    widget.controller.addListener(() {
      setState(() {});
    });
  }

  Metadata get metadata => widget.metadata;

  @override
  Widget build(BuildContext context) {
    final top = MediaQuery.of(context).viewPadding.top;
    final bottom = MediaQuery.of(context).viewPadding.bottom;
    final backgroundColor = Theme.of(context).colorScheme.surfaceContainer;

    final topBarHeight = kToolbarHeight;
    final bottomBarHeight = kBottomNavigationBarHeight;

    return Stack(
      children: [
        Container(color: Colors.transparent),
        Column(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            AnimatedContainer(
              curve: Curves.easeInOut,
              duration: Duration(milliseconds: 300),
              transform: Matrix4.translationValues(0,
                  widget.controller.showPanel ? 0 : -(top + topBarHeight), 0),
              child: AppBar(
                toolbarHeight: topBarHeight,
                title: Text(metadata.titles.first),
                backgroundColor: backgroundColor,
                leading: IconButton(
                  icon: const Icon(Icons.arrow_back),
                  onPressed: () {
                    Navigator.pop(context);
                  },
                ),
                primary: true,
              ),
            ),
            AnimatedContainer(
              curve: Curves.easeInOut,
              duration: Duration(milliseconds: 300),
              transform: Matrix4.translationValues(
                  0,
                  widget.controller.showPanel ? 0 : (bottom + bottomBarHeight),
                  0),
              child: Builder(builder: (context) {
                return Container(
                  height: bottom + bottomBarHeight,
                  color: backgroundColor,
                  child: Padding(
                    padding: EdgeInsets.only(bottom: bottom),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.start,
                      mainAxisSize: MainAxisSize.max,
                      children: [
                        Expanded(
                          child: SizedBox(
                            height: bottomBarHeight,
                            child: InkWell(
                              onTap: () {
                                widget.controller.onOpenDrawer();
                                Scaffold.of(context).openDrawer();
                              },
                              child: const Icon(Icons.menu),
                            ),
                          ),
                        ),
                        Expanded(
                          child: SizedBox(
                            height: bottomBarHeight,
                            child: InkWell(
                              onTap: () {},
                              child: const Icon(Icons.style),
                            ),
                          ),
                        ),
                        Expanded(
                          child: SizedBox(
                            height: bottomBarHeight,
                            child: InkWell(
                              onTap: () {},
                              child: const Icon(Icons.settings),
                            ),
                          ),
                        ),
                        Expanded(
                          child: SizedBox(
                            height: bottomBarHeight,
                            child: InkWell(
                              onTap: () {},
                              child: const Icon(Icons.more_horiz),
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                );
              }),
            ),
          ],
        ),
      ],
    );
  }
}
