import '../../accessor/accessor.dart';
import '../epub.dart';
import 'manifest_bundle.dart';
import 'metadata_bundle.dart';
import 'navigation_bundle.dart';

class EpubBundle {
  final MetadataBundle metadata;
  final ManifestBundle manifest;
  final NavigationBundle navigation;

  EpubBundle({
    required this.metadata,
    required this.manifest,
    required this.navigation,
  });

  factory EpubBundle.fromEpub(Epub epub) {
    return EpubBundle(
      metadata: MetadataBundle.fromMetadata(epub.metadata),
      manifest: ManifestBundle.fromManifest(epub.manifest),
      navigation: NavigationBundle.fromNavigation(epub.navigation),
    );
  }

  Epub toEpub(Accessor accessor) {
    return Epub(
      metadata: metadata.toMetadata(),
      manifest: manifest.toManifest(accessor),
      navigation: navigation.toNavigation(),
    );
  }

  factory EpubBundle.fromJson(Map<String, dynamic> json) {
    return EpubBundle(
      metadata: MetadataBundle.fromJson(json['metadata']),
      manifest: ManifestBundle.fromJson(json['manifest']),
      navigation: NavigationBundle.fromJson(json['navigation']),
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'metadata': metadata.toJson(),
      'manifest': manifest.toJson(),
      'navigation': navigation.toJson(),
    };
  }
}

extension EpubBundleExtension on Epub {
  EpubBundle toBundle() => EpubBundle.fromEpub(this);

  Epub fromBundle(Accessor accessor, EpubBundle bundle) =>
      bundle.toEpub(accessor);
}
