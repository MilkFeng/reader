import 'dart:math';

import 'package:flutter/material.dart';
import 'package:flutter/physics.dart';

import '../../../epub/model/navigation.dart';
import '../../../managers/meta/models.dart';
import 'page_renderer.dart';

class PagesRendererController extends ChangeNotifier {
  PagesRendererController({
    required this.onPageChanged,
    required PageLocation initialLocation,
  }) : _initialLocation = initialLocation;

  Function(DragStartDetails)? _onHorizontalDragStart;
  Function(DragUpdateDetails)? _onHorizontalDragUpdate;
  Function(DragEndDetails)? _onHorizontalDragEnd;
  Function(DragDownDetails)? _onHorizontalDragDown;
  Function()? _onHorizontalDragCancel;

  Function()? _onTapToNext;
  Function()? _onTapToPrevious;

  bool Function()? _onGetHasPreviousPage;
  bool Function()? _onGetHasNextPage;

  final Function(PageLocation) onPageChanged;

  PageLocation _initialLocation;

  void onHorizontalDragStart(DragStartDetails details) {
    if (_onHorizontalDragStart != null) {
      _onHorizontalDragStart!(details);
    }
  }

  void onHorizontalDragUpdate(DragUpdateDetails details) {
    if (_onHorizontalDragUpdate != null) {
      _onHorizontalDragUpdate!(details);
    }
  }

  void onHorizontalDragEnd(DragEndDetails details) {
    if (_onHorizontalDragEnd != null) {
      _onHorizontalDragEnd!(details);
    }
  }

  void onHorizontalDragCancel() {
    if (_onHorizontalDragCancel != null) {
      _onHorizontalDragCancel!();
    }
  }

  void onHorizontalDragDown(DragDownDetails details) {
    if (_onHorizontalDragDown != null) {
      _onHorizontalDragDown!(details);
    }
  }

  void _registerHorizontalDragHandlers({
    Function(DragStartDetails)? onStart,
    Function(DragUpdateDetails)? onUpdate,
    Function(DragEndDetails)? onEnd,
    Function(DragDownDetails)? onDown,
    Function()? onCancel,
  }) {
    _onHorizontalDragStart = onStart;
    _onHorizontalDragUpdate = onUpdate;
    _onHorizontalDragEnd = onEnd;
    _onHorizontalDragDown = onDown;
    _onHorizontalDragCancel = onCancel;
  }

  bool? get hasPreviousPage {
    if (_onGetHasPreviousPage != null) {
      return _onGetHasPreviousPage!();
    }
    return null;
  }

  bool? get hasNextPage {
    if (_onGetHasNextPage != null) {
      return _onGetHasNextPage!();
    }
    return null;
  }

  void onTapToNext() {
    if (_onTapToNext != null) {
      _onTapToNext!();
    }
  }

  void onTapToPrevious() {
    if (_onTapToPrevious != null) {
      _onTapToPrevious!();
    }
  }

  void _registerTapHandlers({
    bool Function()? onGetHasPreviousPage,
    bool Function()? onGetHasNextPage,
    Function()? onTapToNext,
    Function()? onTapToPrevious,
  }) {
    _onGetHasPreviousPage = onGetHasPreviousPage;
    _onGetHasNextPage = onGetHasNextPage;
    _onTapToNext = onTapToNext;
    _onTapToPrevious = onTapToPrevious;
  }

  void resetInitialLocation(PageLocation location) {
    _initialLocation = location;
    notifyListeners();
  }

  PageLocation get initialLocation => _initialLocation;
}

enum _FlingDirection {
  previous,
  current,
  next,
  none,
}

class PagesRenderer extends StatefulWidget {
  const PagesRenderer({
    super.key,
    required this.serverPort,
    required this.navigation,
    required this.controller,
  });

  final int serverPort;
  final Navigation navigation;
  final PagesRendererController controller;

  @override
  State<PagesRenderer> createState() => _PagesRendererState();
}

class _PagesRendererState extends State<PagesRenderer>
    with TickerProviderStateMixin {
  static const previousPageIndex = 2;
  static const currentPageIndex = 1;
  static const nextPageIndex = 0;
  static final springDescription = SpringDescription.withDampingRatio(
    mass: 1,
    stiffness: 200,
    ratio: 1.0,
  );

  late List<Widget> pages;
  late List<int> pageCounts;
  late List<PageRendererController> controllers;
  late List<int> realPageIndexes;
  late List<bool> pageReady;

  late bool isDragging;
  late final ValueNotifier<double> dragProgress;

  late AnimationController animationController;
  late _FlingDirection flingDirection;

  @override
  void initState() {
    super.initState();
    pageCounts = List.generate(3, (i) => 0);
    controllers = List.generate(3, (i) => PageRendererController());
    realPageIndexes = List.generate(3, (i) => i);
    pages = List.generate(3, buildPage);
    pageReady = List.generate(3, (i) => false);

    isDragging = false;
    dragProgress = ValueNotifier(0.0);

    animationController = AnimationController(
      vsync: this,
      duration: Duration(milliseconds: 300),
    );
    flingDirection = _FlingDirection.none;

    widget.controller._registerHorizontalDragHandlers(
      onStart: onHorizontalDragStart,
      onUpdate: onHorizontalDragUpdate,
      onEnd: onHorizontalDragEnd,
      onDown: onHorizontalDragDown,
      onCancel: onHorizontalDragCancel,
    );

    widget.controller._registerTapHandlers(
      onTapToNext: tapToNext,
      onTapToPrevious: tapToPrevious,
    );

    widget.controller.addListener(() {
      loadPage(widget.controller.initialLocation);
      setState(() {});
    });

    loadPage(widget.controller.initialLocation);
  }

  void loadPage(PageLocation location) {
    loadLocationForPage(previousPageIndex, getPreviousPageLocation(location));
    loadLocationForPage(currentPageIndex, location);
  }

  void loadLocationForPage(int index, PageLocation? location) {
    controllers[index].load(location);
    pageReady[index] = false;
  }

  Widget buildPage(int index) {
    return PageRenderer(
      key: ValueKey(realPageIndexes[index]),
      id: index,
      serverPort: widget.serverPort,
      navigation: widget.navigation,
      onPageReady: (id, detail) {
        final index = realPageIndexes.indexOf(id);
        onPageCountLoaded(index, detail.pageCount);
        pageReady[index] = true;
      },
      controller: controllers[index],
    );
  }

  void onPageCountLoaded(int index, int pageCount) {
    pageCounts[index] = pageCount;
    // 如果 location 的页数超过总页数，需要重新计算 location
    if (controllers[index].pageLocation != null &&
        controllers[index].pageLocation!.pageIndex >= pageCount) {
      final newLocation = PageLocation(
        contentLocation: controllers[index].pageLocation!.contentLocation,
        pageIndex: pageCount - 1,
      );
      loadLocationForPage(index, newLocation);
    }

    if (index == currentPageIndex && controllers[index].pageLocation != null) {
      // 如果是当前页，可以获得下一页的 location
      // 上一页不需要在这里更新
      final nextPageLocation = getNextPageLocation(
        controllers[index].pageLocation!,
        pageCount,
      );
      if (nextPageLocation != null) {
        loadLocationForPage(nextPageIndex, nextPageLocation);
      }
    }
    setState(() {});
  }

  bool isFirstPage(PageLocation pageLocation) {
    return pageLocation.pageIndex == 0 &&
        widget.navigation.firstLocation == pageLocation.contentLocation;
  }

  bool isLastPage(PageLocation pageLocation, int pageCount) {
    return pageLocation.pageIndex == pageCount - 1 &&
        widget.navigation.lastLocation == pageLocation.contentLocation;
  }

  PageLocation? getNextPageLocation(PageLocation pageLocation, int pageCount) {
    if (pageLocation.pageIndex + 1 < pageCount) {
      return PageLocation(
        contentLocation: pageLocation.contentLocation,
        pageIndex: pageLocation.pageIndex + 1,
      );
    } else {
      final nextContentLocation = widget.navigation
          .getNextContentLocation(pageLocation.contentLocation);
      if (nextContentLocation != null) {
        return PageLocation(
          contentLocation: nextContentLocation,
          pageIndex: 0,
        );
      }
    }
    return null;
  }

  PageLocation? getPreviousPageLocation(PageLocation pageLocation) {
    if (pageLocation.pageIndex > 0) {
      return PageLocation(
        contentLocation: pageLocation.contentLocation.clone(),
        pageIndex: pageLocation.pageIndex - 1,
      );
    } else {
      final previousContentLocation = widget.navigation
          .getPreviousContentLocation(pageLocation.contentLocation);
      if (previousContentLocation != null) {
        return PageLocation(
          contentLocation: previousContentLocation,
          pageIndex: 100000000,
        );
      }
    }
    return null;
  }

  void _cycleLeft<T>(List<T> list, int i, int j, int k) {
    final temp = list[i];
    list[i] = list[j];
    list[j] = list[k];
    list[k] = temp;
  }

  void _cycleRight<T>(List<T> list, int i, int j, int k) {
    final temp = list[k];
    list[k] = list[j];
    list[j] = list[i];
    list[i] = temp;
  }

  void cycleLeft() {
    // previous current next   ->   current next previous
    _cycleLeft(controllers, previousPageIndex, currentPageIndex, nextPageIndex);
    _cycleLeft(pages, previousPageIndex, currentPageIndex, nextPageIndex);
    _cycleLeft(pageCounts, previousPageIndex, currentPageIndex, nextPageIndex);
    _cycleLeft(
        realPageIndexes, previousPageIndex, currentPageIndex, nextPageIndex);
    _cycleLeft(pageReady, previousPageIndex, currentPageIndex, nextPageIndex);
  }

  void cycleRight() {
    // previous current next   ->   next previous current
    _cycleRight(
        controllers, previousPageIndex, currentPageIndex, nextPageIndex);
    _cycleRight(pages, previousPageIndex, currentPageIndex, nextPageIndex);
    _cycleRight(pageCounts, previousPageIndex, currentPageIndex, nextPageIndex);
    _cycleRight(
        realPageIndexes, previousPageIndex, currentPageIndex, nextPageIndex);
    _cycleRight(pageReady, previousPageIndex, currentPageIndex, nextPageIndex);
  }

  void paginateToNext() {
    cycleLeft();
    final nextPageLocation = getNextPageLocation(
      controllers[currentPageIndex].pageLocation!,
      pageCounts[currentPageIndex],
    );
    loadLocationForPage(nextPageIndex, nextPageLocation);
    widget.controller.onPageChanged(
      controllers[currentPageIndex].pageLocation!,
    );
    setState(() {});
  }

  void paginateToPrevious() {
    cycleRight();
    final previousPageLocation = getPreviousPageLocation(
      controllers[currentPageIndex].pageLocation!,
    );
    loadLocationForPage(previousPageIndex, previousPageLocation);
    widget.controller.onPageChanged(
      controllers[currentPageIndex].pageLocation!,
    );
    setState(() {});
  }

  void removeAllAnimationListeners() {
    animationController
        .removeListener(_changeDragProgressForAnimatedPaginateToNext);
    animationController
        .removeListener(_changeDragProgressForAnimatedPaginateToPrevious);
    animationController
        .removeListener(_changeDragProgressForAnimatedToCurrentPage);
  }

  void _changeDragProgressForAnimatedPaginateToNext() {
    dragProgress.value = -animationController.value;
  }

  void animatedPaginateToNext(double velocity) async {
    // dragProgress 从当前值到 -1
    flingDirection = _FlingDirection.next;
    final spring =
        SpringSimulation(springDescription, -dragProgress.value, 1, -velocity);

    animationController.reset();
    removeAllAnimationListeners();
    animationController
        .addListener(_changeDragProgressForAnimatedPaginateToNext);
    await animationController.animateWith(spring);
    dragProgress.value = 0.0;
    paginateToNext();

    flingDirection = _FlingDirection.none;
  }

  void _changeDragProgressForAnimatedPaginateToPrevious() {
    dragProgress.value = animationController.value;
  }

  void animatedPaginateToPrevious(double velocity) async {
    flingDirection = _FlingDirection.previous;
    // dragProgress 从当前值到 1
    final spring =
        SpringSimulation(springDescription, dragProgress.value, 1, velocity);

    animationController.reset();
    removeAllAnimationListeners();
    animationController
        .addListener(_changeDragProgressForAnimatedPaginateToPrevious);
    await animationController.animateWith(spring);

    dragProgress.value = 0.0;
    paginateToPrevious();

    flingDirection = _FlingDirection.none;
  }

  void _changeDragProgressForAnimatedToCurrentPage() {
    dragProgress.value = animationController.value * 2 - 1;
  }

  void animatedPaginateToCurrent(double velocity) async {
    flingDirection = _FlingDirection.current;
    // dragProgress 从当前值到 0
    final spring = SpringSimulation(
        springDescription, dragProgress.value / 2 + 0.5, 0.5, velocity);

    animationController.reset();
    removeAllAnimationListeners();
    animationController
        .addListener(_changeDragProgressForAnimatedToCurrentPage);
    await animationController.animateWith(spring);

    dragProgress.value = 0.0;
    flingDirection = _FlingDirection.none;
  }

  bool get hasPreviousPage =>
      controllers[previousPageIndex].pageLocation != null;

  bool get hasNextPage => controllers[nextPageIndex].pageLocation != null;

  void forceFlingToNext() {
    animationController.stop();
    removeAllAnimationListeners();
    dragProgress.value = 0.0;
    paginateToNext();

    flingDirection = _FlingDirection.none;
  }

  void forceFlingToPrevious() {
    animationController.stop();
    removeAllAnimationListeners();
    dragProgress.value = 0.0;
    paginateToPrevious();

    flingDirection = _FlingDirection.none;
  }

  void forceFlingToCurrent() {
    animationController.stop();
    removeAllAnimationListeners();
    dragProgress.value = 0.0;

    flingDirection = _FlingDirection.none;
  }

  void forceFling() {
    if (flingDirection == _FlingDirection.next) {
      forceFlingToNext();
    } else if (flingDirection == _FlingDirection.previous) {
      forceFlingToPrevious();
    } else if (flingDirection == _FlingDirection.current) {
      forceFlingToCurrent();
    }
  }

  void tapToNext() {
    if (hasNextPage) {
      forceFling();
      animatedPaginateToNext(0);
    }
  }

  void tapToPrevious() {
    if (hasPreviousPage) {
      forceFling();
      animatedPaginateToPrevious(0);
    }
  }

  void onHorizontalDragStart(DragStartDetails details) {
    forceFling();
    isDragging = true;
    dragProgress.value = 0;
  }

  void onHorizontalDragUpdate(DragUpdateDetails details) {
    final width = MediaQuery.of(context).size.width;
    if (!isDragging || flingDirection != _FlingDirection.none) {
      return;
    }

    var delta = details.primaryDelta! / width;
    if (delta.abs() > 0.3) {
      delta = delta.sign * 0.3;
    }
    dragProgress.value += delta;

    if (!hasPreviousPage && dragProgress.value > 0) {
      dragProgress.value = 0;
    } else if (!hasNextPage && dragProgress.value < 0) {
      dragProgress.value = 0;
    }
  }

  void onHorizontalDragEnd(DragEndDetails details) {
    final width = MediaQuery.of(context).size.width;
    final velocity = details.primaryVelocity! / width;

    if (!isDragging || flingDirection != _FlingDirection.none) {
      return;
    }

    isDragging = false;

    if (hasPreviousPage &&
        ((dragProgress.value > 1 / 2 && velocity > -0.2) ||
            (dragProgress.value > 0 && velocity > 0.2))) {
      animatedPaginateToPrevious(velocity);
    } else if (hasNextPage &&
        ((dragProgress.value < -1 / 2 && velocity < 0.2) ||
            (dragProgress.value < 0 && velocity < -0.2))) {
      animatedPaginateToNext(velocity);
    } else {
      if (dragProgress.value < 0) {
        if (hasPreviousPage) {
          animatedPaginateToCurrent(max(velocity, 0));
        } else {
          dragProgress.value = 0;
        }
      } else {
        if (hasNextPage) {
          animatedPaginateToCurrent(min(velocity, 0));
        } else {
          dragProgress.value = 0;
        }
      }
    }
  }

  void onHorizontalDragDown(DragDownDetails details) {}

  void onHorizontalDragCancel() {
    isDragging = false;
    forceFling();
  }

  @override
  Widget build(BuildContext context) {
    MediaQuery.of(context).gestureSettings;

    final width = MediaQuery.of(context).size.width;
    final height = MediaQuery.of(context).size.height;

    final top = MediaQuery.of(context).viewPadding.top;
    final bottom = MediaQuery.of(context).viewPadding.bottom;
    final padding = 16.0;

    print('PagesRenderer build');

    return ClipRect(
      child: Stack(
        clipBehavior: Clip.hardEdge,
        children: List.generate(3, (index) {
          return ValueListenableBuilder<double>(
            key: ValueKey(realPageIndexes[index]),
            valueListenable: dragProgress,
            builder: (context, value, child) {
              final double left;
              if (index == currentPageIndex) {
                if (value < 0) {
                  // 向左翻页时，current page 会向左移动
                  left = value * width;
                } else {
                  // 向右翻页时，current page 不移动
                  left = 0;
                }
              } else if (index == nextPageIndex) {
                left = 0;
              } else {
                if (value < 0) {
                  // 向左翻页时，previous page 不移动
                  left = -width;
                } else {
                  // 向右翻页时，previous page 会向右移动
                  left = value * width - width;
                }
              }

              return Transform.translate(
                offset: Offset(left, 0),
                child: Container(
                  decoration: BoxDecoration(
                    color: Theme.of(context).colorScheme.surface,
                    boxShadow: [
                      BoxShadow(
                        color: Colors.black.withValues(alpha: 0.1),
                        offset: Offset(0, 0),
                        blurRadius: 10,
                      ),
                    ],
                  ),
                  child: Stack(
                    key: ValueKey(realPageIndexes[index]),
                    children: [
                      Padding(
                        padding: EdgeInsets.only(
                          left: padding,
                          right: padding,
                          top: top + padding,
                          bottom: bottom + padding,
                        ),
                        child: pages[index],
                      ),
                      if (!pageReady[index])
                        Positioned(
                          top: 0,
                          left: 0,
                          right: 0,
                          bottom: 0,
                          child: Container(
                            color: Theme.of(context).colorScheme.surface,
                            child: Center(
                              child: Text('正在加载中...'),
                            ),
                          ),
                        ),
                    ],
                  ),
                ),
              );
            },
          );
        }).toList(),
      ),
    );
  }
}
