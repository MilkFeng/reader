import 'package:flutter/material.dart';
import 'package:reader/epub/epub.dart';
import 'package:reader/managers/managers.dart';

class BooksState extends ChangeNotifier {
  final String rootPath;

  late final MetaManager _metaManager;
  late final EpubManager _epubManager;
  late final List<ExtendedBookInfo> _books;

  List<ExtendedBookInfo> get books => _books;

  BooksState({required this.rootPath}) {
    _metaManager = MetaManager(rootPath: rootPath);
    _epubManager = EpubManager(rootPath: rootPath);

    _books = [];
    updateBookInfos();
  }

  ExtendedBookInfo getBookInfo(String relativePath) {
    return _books.firstWhere((element) => element.relativePath == relativePath);
  }

  Future<void> updateBookInfos() async {
    _books.clear();
    if (await _metaManager.checkBookInfosFileExist()) {
      _books.addAll(await _metaManager.getBookInfos());
    }
    notifyListeners();
  }

  Future<void> addBookInfo(ExtendedBookInfo bookInfo) async {
    await _metaManager.addBookInfo(bookInfo);
    _books.add(bookInfo);
    notifyListeners();
  }

  Future<void> removeBookInfo(String relativePath) async {
    await _metaManager.removeBookInfo(relativePath);
    _books.removeWhere((element) => element.relativePath == relativePath);
    notifyListeners();
  }

  Future<void> clearBookInfos() async {
    if (await _metaManager.checkBookInfosFileExist()) {
      await _metaManager.saveBookInfos([]);
      _books.clear();
    }
    notifyListeners();
  }

  Future<Epub> openEpub(String relativePath) async {
    return await _epubManager.openEpub(relativePath);
  }

  Future<String?> saveCover(Epub epub, String relativePath) async {
    final coverAsset = await epub.coverAsset;
    if (coverAsset != null) {
      final coverExtension = coverAsset.extension;
      final coverBytes = await coverAsset.bytes;
      return await _metaManager.saveCover(
        relativePath,
        coverExtension,
        coverAsset.mediaType,
        coverBytes,
      );
    }
    return null;
  }

  Future<String?> saveDesc(String relativePath, String description) async {
    return await _metaManager.saveDesc(relativePath, description);
  }

  Future<String?> getCoverPath(String relativePath) async {
    final bookInfo = getBookInfo(relativePath);
    if (bookInfo.coverExtension == null) {
      return null;
    }
    return await _metaManager.getCoverRelativePath(
        relativePath, bookInfo.coverExtension!);
  }

  Future<String> getDesc(String relativePath) async {
    return await _metaManager.getDesc(relativePath);
  }

  Future<ExtendedBookInfo> uploadBook(String relativePath) async {
    final epub = await openEpub(relativePath);
    final bookInfo =
        await _metaManager.createBookInfoFromEpub(epub, relativePath);
    final coverPath = await saveCover(epub, relativePath);
    final descPath = await saveDesc(relativePath, epub.metadata.description ?? '');

    final extendedBookInfo = ExtendedBookInfo(
      coverRelativePath: coverPath,
      descRelativePath: descPath,
      titles: bookInfo.titles,
      authors: bookInfo.authors,
      relativePath: bookInfo.relativePath,
      coverExtension: bookInfo.coverExtension,
      category: bookInfo.category,
    );

    await addBookInfo(extendedBookInfo);
    return extendedBookInfo;
  }
}
