import 'dart:convert';

class BookInfo {
  final List<String> titles;
  final List<String> authors;
  final String relativePath;
  final String? coverExtension;
  final String category;

  BookInfo({
    required this.titles,
    required this.authors,
    required this.relativePath,
    required this.coverExtension,
    required this.category,
  });

  factory BookInfo.fromJson(Map<String, dynamic> json) {
    return BookInfo(
      titles: (json['titles'] as List<dynamic>).map((e) => e as String).toList(),
      authors: (json['authors'] as List<dynamic>).map((e) => e as String).toList(),
      relativePath: json['relative_path'],
      coverExtension: json['cover_extension'],
      category: json['category'],
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'titles': titles,
      'authors': authors,
      'relative_path': relativePath,
      'cover_extension': coverExtension,
      'category': category,
    };
  }

  static List<BookInfo> listFromJson(String jsonStr) {
    final List<dynamic> jsonList = json.decode(jsonStr);
    return jsonList.map((json) => BookInfo.fromJson(json)).toList();
  }

  static String listToJson(List<BookInfo> bookInfos) {
    final List<Map<String, dynamic>> jsonList =
        bookInfos.map((bookInfo) => bookInfo.toJson()).toList();
    return json.encode(jsonList);
  }
}


class ExtendedBookInfo extends BookInfo {
  final String? coverRelativePath;
  final String? descRelativePath;

  ExtendedBookInfo({
    required this.coverRelativePath,
    required this.descRelativePath,
    required super.titles,
    required super.authors,
    required super.relativePath,
    required super.coverExtension,
    required super.category,
  });
}