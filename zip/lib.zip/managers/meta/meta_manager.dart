import 'dart:convert';
import 'dart:typed_data';

import 'package:crypto/crypto.dart';
import 'package:reader/epub/epub.dart';

import '../../common/fs_utils.dart';
import 'book_info.dart';

class MetaManager {
  MetaManager({required this.rootPath});

  final String rootPath;

  static const String metaDirName = '.meta';

  static const String bookInfosFileName = 'book_infos.json';
  static const String bookInfosFileRelativePath =
      '$metaDirName/$bookInfosFileName';
  static const String bookInfosFileMIME = 'application/json';

  Future<void> createDirs() async {
    if (!await checkMetaDirExist()) {
      await createMetaDir();
    }
  }

  /// 判断 meta 目录是否存在
  Future<bool> checkMetaDirExist() async {
    return await FSUtils.checkFileOrDirExist(rootPath, metaDirName);
  }

  /// 创建 .meta 目录
  Future<void> createMetaDir() async {
    await FSUtils.createDir(rootPath, metaDirName);
  }

  /// 判断 book_infos.json 文件是否存在
  Future<bool> checkBookInfosFileExist() async {
    return await FSUtils.checkFileOrDirExist(
        rootPath, bookInfosFileRelativePath);
  }

  /// 读取 book_infos.json 文件并返回 BookInfo 列表
  Future<List<ExtendedBookInfo>> getBookInfos() async {
    final time = DateTime.now().millisecondsSinceEpoch;
    await createDirs();
    if (!await checkBookInfosFileExist()) {
      return [];
    }
    final jsonBytes = await FSUtils.readFileBytesFromJoinPath(
        rootPath, bookInfosFileRelativePath);
    final jsonStr = utf8.decode(jsonBytes);
    final bookInfos = BookInfo.listFromJson(jsonStr);
    final extendedBookInfos = <ExtendedBookInfo>[];

    print('getBookInfos: ${DateTime.now().millisecondsSinceEpoch - time}ms');

    for (final bookInfo in bookInfos) {
      String? coverRelativePath;
      String? descRelativePath;
      if (bookInfo.coverExtension != null) {
        coverRelativePath =
            getCoverRelativePath(bookInfo.relativePath, bookInfo.coverExtension!);
      }
      descRelativePath = getDescRelativePath(bookInfo.relativePath);
      extendedBookInfos.add(ExtendedBookInfo(
        coverRelativePath: coverRelativePath,
        descRelativePath: descRelativePath,
        titles: bookInfo.titles,
        authors: bookInfo.authors,
        relativePath: bookInfo.relativePath,
        coverExtension: bookInfo.coverExtension,
        category: bookInfo.category,
      ));
    }

    print('getBookInfos: ${DateTime.now().millisecondsSinceEpoch - time}ms');

    return extendedBookInfos;
  }

  /// 保存 BookInfo 列表到 book_infos.json 文件
  Future<void> saveBookInfos(List<BookInfo> bookInfos) async {
    await createDirs();
    final jsonStr = BookInfo.listToJson(bookInfos);
    final jsonBytes = utf8.encode(jsonStr);
    if (!await checkMetaDirExist()) {
      await createMetaDir();
    }
    await FSUtils.writeToFile(
        rootPath, metaDirName, bookInfosFileName, bookInfosFileMIME, jsonBytes);
  }

  Future<void> addBookInfo(ExtendedBookInfo bookInfo) async {
    final bookInfos = await getBookInfos();
    bookInfos.add(bookInfo);
    await saveBookInfos(bookInfos);
  }

  Future<void> removeBookInfo(String relativePath) async {
    final bookInfos = await getBookInfos();
    bookInfos.removeWhere((element) => element.relativePath == relativePath);
    await saveBookInfos(bookInfos);
  }

  Future<void> updateBookInfo(ExtendedBookInfo bookInfo) async {
    final bookInfos = await getBookInfos();
    final index = bookInfos
        .indexWhere((element) => element.relativePath == bookInfo.relativePath);
    if (index != -1) {
      bookInfos[index] = bookInfo;
      await saveBookInfos(bookInfos);
    }
  }

  Future<BookInfo?> getBookInfo(String relativePath) async {
    final bookInfos = await getBookInfos();
    final index =
        bookInfos.indexWhere((element) => element.relativePath == relativePath);
    if (index != -1) {
      return bookInfos[index];
    }
    return null;
  }

  String getBookDirName(String relativePath) {
    final bytes = utf8.encode(relativePath);
    final md5Digest = md5.convert(bytes);
    return md5Digest.toString();
  }

  String getBookDirRelativePath(String relativePath) {
    return '$metaDirName/${getBookDirName(relativePath)}';
  }

  Future<bool> checkBookDirExist(String relativePath) async {
    final bookDirRelativePath = getBookDirRelativePath(relativePath);
    return await FSUtils.checkFileOrDirExist(rootPath, bookDirRelativePath);
  }

  Future<void> createBookDir(String relativePath) async {
    if (await checkBookDirExist(relativePath)) {
      return;
    }
    final bookDirRelativePath = getBookDirRelativePath(relativePath);
    await FSUtils.createDir(rootPath, bookDirRelativePath);
  }

  String getCoverRelativePath(String relativePath, String extension) {
    final bookDirRelativePath = getBookDirRelativePath(relativePath);
    return '$bookDirRelativePath/cover.$extension';
  }

  Future<String> getDesc(String relativePath) async {
    final bookDirRelativePath = getBookDirRelativePath(relativePath);
    final descPath = '$bookDirRelativePath/desc.txt';
    final descBytes =
        await FSUtils.readFileBytesFromJoinPath(rootPath, descPath);
    return utf8.decode(descBytes);
  }

  String getDescRelativePath(String relativePath) {
    final bookDirRelativePath = getBookDirRelativePath(relativePath);
    return '$bookDirRelativePath/desc.txt';
  }

  /// 保存描述文件
  Future<String> saveDesc(String relativePath, String desc) async {
    await createDirs();
    await createBookDir(relativePath);
    final bookDirRelativePath = getBookDirRelativePath(relativePath);
    final descBytes = utf8.encode(desc);
    await FSUtils.writeToFile(
        rootPath, bookDirRelativePath, 'desc.txt', 'text/plain', descBytes);

    return "$bookDirRelativePath/desc.txt";
  }

  /// 保存封面图片
  Future<String> saveCover(
    String relativePath,
    String extension,
    String mime,
    Uint8List bytes,
  ) async {
    await createDirs();
    await createBookDir(relativePath);
    final bookDirRelativePath = getBookDirRelativePath(relativePath);
    await FSUtils.writeToFile(
        rootPath, bookDirRelativePath, "cover.$extension", mime, bytes);

    return "$bookDirRelativePath/cover.$extension";
  }

  Future<BookInfo> createBookInfoFromEpub(
    Epub epub,
    String relativePath, {
    String category = '',
  }) async {
    final titles = epub.metadata.titles;
    final authors = epub.metadata.authors;
    final coverExtension = (await epub.coverAsset)?.extension;
    return BookInfo(
      titles: titles,
      authors: authors,
      relativePath: relativePath,
      coverExtension: coverExtension,
      category: category,
    );
  }
}
