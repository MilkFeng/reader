// import 'package:flutter/material.dart';
// import 'package:provider/provider.dart';
// import 'package:reader/global_state/global_state.dart';
//
// class DetailScreen extends StatelessWidget {
//   const DetailScreen({
//     super.key,
//     required this.relativePath,
//   });
//
//   final String relativePath;
//
//   @override
//   Widget build(BuildContext context) {
//     return Consumer<BooksState>(
//       builder: (context, booksState, child) {
//       final bookInfo = booksState.getBookInfo(relativePath);
//     });
//   }
// }
