import 'package:animated_flip_counter/animated_flip_counter.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../../../global_state/books_state.dart';
import '../../../managers/managers.dart';
import '../../common/dialog.dart';
import '../../main/shelf/book_tile.dart';

class ShelfPage extends StatefulWidget {
  ShelfPage({
    super.key,
    required this.allBooks,
  }) {
    categoryToBooks = {"未分类": []};
    for (final book in allBooks) {
      String category = book.category;
      if (category.isEmpty) {
        category = "未分类";
      }
      if (categoryToBooks.containsKey(category)) {
        categoryToBooks[category]!.add(book);
      } else {
        categoryToBooks[category] = [book];
      }
    }
  }

  static NavigationDestination get destination => NavigationDestination(
        selectedIcon: Icon(Icons.local_library),
        icon: Icon(Icons.local_library_outlined),
        label: '书架',
      );

  final List<ExtendedBookInfo> allBooks;
  late final Map<String, List<ExtendedBookInfo>> categoryToBooks;

  @override
  State<ShelfPage> createState() => _ShelfPageState();
}

class _ShelfPageState extends State<ShelfPage>
    with TickerProviderStateMixin, AutomaticKeepAliveClientMixin {
  Map<String, List<BookInfo>> books = {};
  late TabController tabController;

  @override
  void initState() {
    super.initState();
    tabController = TabController(
      length: widget.categoryToBooks.keys.length,
      vsync: this,
    );
  }

  @override
  void didUpdateWidget(covariant ShelfPage oldWidget) {
    super.didUpdateWidget(oldWidget);

    final oldCategoryCount = oldWidget.categoryToBooks.keys.length;
    final newCategoryCount = widget.categoryToBooks.keys.length;

    if (oldCategoryCount != newCategoryCount) {
      final oldIndex = tabController.index;
      final newIndex = oldIndex.clamp(0, newCategoryCount - 1);
      setState(() {
        tabController = TabController(
          length: newCategoryCount,
          vsync: this,
          initialIndex: newIndex,
        );
      });
    }
  }

  Widget _buildDetailBottomSheetItem(
      BuildContext context, String title, String content) {
    final theme = Theme.of(context);
    final textTheme = theme.textTheme;

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      mainAxisAlignment: MainAxisAlignment.start,
      mainAxisSize: MainAxisSize.max,
      children: [
        Row(
          children: [
            Text(title, style: textTheme.titleMedium),
          ],
        ),
        const SizedBox(height: 4),
        Text(content, style: textTheme.bodySmall),
      ],
    );
  }

  void _showDetailBottomSheet(
      BuildContext context, ExtendedBookInfo bookInfo) async {
    final booksState = context.read<BooksState>();

    final List<Widget> children = [];
    if (bookInfo.titles.firstOrNull != null) {
      children.add(
          _buildDetailBottomSheetItem(context, '标题', bookInfo.titles.first));
      children.add(const SizedBox(height: 16));
    }
    if (bookInfo.authors.isNotEmpty) {
      children.add(_buildDetailBottomSheetItem(
          context, '作者', bookInfo.authors.join(' ')));
      children.add(const SizedBox(height: 16));
    }
    {
      children.add(_buildDetailBottomSheetItem(
          context, '文件相对路径', bookInfo.relativePath));
      children.add(const SizedBox(height: 16));
    }

    final desc = await booksState.getDesc(bookInfo.relativePath);
    {
      children.add(_buildDetailBottomSheetItem(context, '描述', desc));
      children.add(const SizedBox(height: 16));
    }

    showCustomModalBottomSheet(
      context: context,
      showDragHandle: true,
      builder: (context) {
        return Container(
          padding: const EdgeInsets.symmetric(horizontal: 16),
          child: SingleChildScrollView(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              mainAxisAlignment: MainAxisAlignment.start,
              mainAxisSize: MainAxisSize.max,
              children: children,
            ),
          ),
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    super.build(context);
    final tabHeight = 46.0;
    return Scaffold(
      appBar: AppBar(
        title: Row(
          children: [
            Text('书架 '),
            AnimatedFlipCounter(value: widget.allBooks.length),
          ],
        ),
        actions: [
          IconButton(icon: Icon(Icons.more_vert), onPressed: () {}),
        ],
        bottom: TabBar(
          controller: tabController,
          isScrollable: true,
          tabAlignment: TabAlignment.start,
          tabs: widget.categoryToBooks.keys
              .map((e) => SizedBox(
                    height: tabHeight,
                    child: Row(
                      children: [
                        Text('$e '),
                        AnimatedFlipCounter(
                            value: widget.categoryToBooks[e]!.length),
                      ],
                    ),
                  ))
              .toList(),
        ),
      ),
      body: TabBarView(
        controller: tabController,
        physics: const NeverScrollableScrollPhysics(),
        children: widget.categoryToBooks.keys.map((category) {
          final books = widget.categoryToBooks[category]!;
          return ListView.builder(
            itemCount: books.length,
            itemBuilder: (context, index) {
              return BookTile(
                book: books[index],
                onRead: (bookInfo) {
                  Navigator.of(context).pushNamed(
                    '/reader',
                    arguments: bookInfo.relativePath,
                  );
                },
                onDetail: (bookInfo) {
                  _showDetailBottomSheet(context, bookInfo);
                },
              );
            },
          );
        }).toList(),
      ),
    );
  }

  @override
  bool get wantKeepAlive => true;
}
