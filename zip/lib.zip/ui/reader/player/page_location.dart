import 'package:quiver/core.dart';

import '../../../epub/epub.dart';

class PageLocation {
  final ContentLocation contentLocation;
  final int pageIndex;

  PageLocation({
    required this.contentLocation,
    required this.pageIndex,
  });

  @override
  String toString() => '$contentLocation#$pageIndex';

  @override
  bool operator ==(Object other) {
    if (other is PageLocation) {
      return contentLocation == other.contentLocation &&
          pageIndex == other.pageIndex;
    }
    return false;
  }

  @override
  int get hashCode => hash2(contentLocation.hashCode, pageIndex.hashCode);

  PointLocation get pointLocation => contentLocation.pointLocation;


  factory PageLocation.firstPageOf(ContentLocation contentLocation) {
    return PageLocation(
      contentLocation: contentLocation,
      pageIndex: 0,
    );
  }

  PageLocation clone() {
    return PageLocation(
      contentLocation: contentLocation.clone(),
      pageIndex: pageIndex,
    );
  }
}
