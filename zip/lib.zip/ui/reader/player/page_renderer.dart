import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:flutter_inappwebview/flutter_inappwebview.dart';
import 'package:reader/epub/epub.dart';
import 'package:reader/ui/reader/player/page_location.dart';

import '../server/server.dart';

class PageRendererController extends ChangeNotifier {
  PageRendererController({
    this.pageLocation,
  });

  PageLocation? pageLocation;

  void load(PageLocation? pageLocation) {
    this.pageLocation = pageLocation;
    notifyListeners();
  }
}

class PageRenderer extends StatefulWidget {
  const PageRenderer({
    super.key,
    required this.server,
    required this.navigation,
    required this.onPageCountLoaded,
    required this.controller,
    required this.id,
  });

  final Server server;
  final Navigation navigation;
  final int id;

  final Function(int, int) onPageCountLoaded;

  final PageRendererController controller;

  @override
  State<StatefulWidget> createState() => PageRendererState();
}

class PageRendererState extends State<PageRenderer> {
  InAppWebViewController? _webViewController;

  String? _currentPageUrl;
  int? _currentPageIndex;

  @override
  void initState() {
    super.initState();

    widget.controller.addListener(() {
      load(widget.controller.pageLocation);
    });
  }

  void load(PageLocation? pageLocation) {
    if (pageLocation == null) {
      return;
    }

    final href =
        widget.navigation.getHrefByLocation(pageLocation.contentLocation);
    final url = "http://reader/epub/$href";
    final index = pageLocation.pageIndex;

    if (url == _currentPageUrl && index == _currentPageIndex) {
      return;
    }

    _currentPageUrl = url;
    _currentPageIndex = index;

    _webViewController?.evaluateJavascript(source: '''
      window.page('$url', $index);
    ''');

    setState(() {});
  }

  @override
  Widget build(BuildContext context) {
    final width = MediaQuery.of(context).size.width;
    final height = MediaQuery.of(context).size.height;

    return InAppWebView(
      initialUrlRequest: URLRequest(
        url: WebUri.uri(Uri.parse("http://reader/asset/index.html")),
      ),
      onWebViewCreated: (controller) {
        _webViewController = controller;

        controller.addJavaScriptHandler(
          handlerName: "ready",
          callback: (args) async {
            final innerPage = args[0] as int;
            final innerPages = args[1] as int;

            widget.onPageCountLoaded(widget.id, innerPages);
          },
        );
      },
      shouldInterceptRequest: (controller, request) async {
        return await widget.server.handleRequest(request);
      },
      initialSettings: InAppWebViewSettings(
        disableVerticalScroll: true,
        disableHorizontalScroll: true,
        disallowOverScroll: true,
        supportZoom: false,
        useHybridComposition: false,
        verticalScrollBarEnabled: false,
        horizontalScrollBarEnabled: false,
        transparentBackground: true,
        isInspectable: false,
        supportMultipleWindows: false,
        allowsLinkPreview: false,
      ),
      onLoadStop: (controller, url) async {
        load(widget.controller.pageLocation);
      },
    );
  }
}
