import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../global_state/global_state.dart';
import 'player/epub_player.dart';
import 'reader_screen_state.dart';

class ReaderScreen extends StatefulWidget {
  const ReaderScreen({super.key, required this.relativePath});

  final String relativePath;

  @override
  State<StatefulWidget> createState() => _ReaderScreenState();
}

class _ReaderScreenState extends State<ReaderScreen> {
  @override
  Widget build(BuildContext context) {
    return ChangeNotifierProxyProvider<BooksState, ReaderScreenState?>(
      create: (context) => null,
      update: (context, booksState, state) {
        return ReaderScreenState(
          booksState: booksState,
          relativePath: widget.relativePath,
        )..init();
      },
      child: Consumer<ReaderScreenState>(builder: (context, state, _) {
        if (state.server == null || state.epub == null) {
          return const Scaffold();
        }

        return Scaffold(
          body:  EpubPlayer(
            server: state.server!,
            epub: state.epub!,
          ),
        );
      }),
    );
  }
}
