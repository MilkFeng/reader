import 'package:flutter/material.dart';

import '../../epub/epub.dart';
import '../../global_state/global_state.dart';
import 'server/asset_service.dart';
import 'server/epub_service.dart';
import 'server/server.dart';

class ReaderScreenState extends ChangeNotifier {
  Server? _server;
  Epub? _epub;

  final BooksState booksState;
  final String relativePath;

  ReaderScreenState({
    required this.booksState,
    required this.relativePath,
  });

  Future<void> init() async {
    _server = Server();

    _epub = await booksState.openEpub(relativePath);
    _server!.registerService(EpubService(_epub!));
    _server!.registerService(AssetService());

    notifyListeners();
  }

  Server? get server => _server;
  Epub? get epub => _epub;
}
